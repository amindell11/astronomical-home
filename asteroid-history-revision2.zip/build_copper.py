"""Build Copper revision 2 in this folder. No tracked assets are modified.
Exit 0 writes the editable blockout and two flat-material review renders.
"""
import bpy,bmesh,math,sys
from pathlib import Path
from mathutils import Vector

WORK=Path(__file__).resolve().parent
OUT=WORK/'copper'
OUT.mkdir(parents=True,exist_ok=True)
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.context.preferences.filepaths.save_version=0

def material(name,color):
    mat=bpy.data.materials.new(name)
    mat.diffuse_color=(*color,1)
    mat.use_nodes=True
    shader=mat.node_tree.nodes.get('Principled BSDF')
    shader.inputs['Base Color'].default_value=(*color,1)
    shader.inputs['Roughness'].default_value=.94
    shader.inputs['Specular IOR Level'].default_value=.04
    return mat

materials=[material('Iron host',(.10,.115,.16)),material('Copper mineral',(.50,.19,.065)),material('Oxidized cleavage',(.065,.30,.29)),material('Fresh iron fracture',(.16,.175,.22)),material('Copper folded end',(.36,.105,.035))]
profile=[(-.80,-.61),(-1.04,-.29),(-1.09,.02),(-.84,.13),(-.57,.27),(-.17,.20),(-.04,-.09),(.14,-.06),(.28,.55),(.36,.66),(.89,.76),(1.07,.42),(.90,-.36),(.12,-.74)]
stations=[(-2.05,.54,.68,-.05),(-1.66,.91,1.10,.05),(-.97,1.06,1.0,.08),(-.12,1.00,.93,.01),(.82,.92,.90,-.06),(1.56,.77,.91,.08),(1.93,.45,.56,-.03)]
top_profiles=[
    [(-.75,.34),(-.50,.42),(-.16,.43),(.02,.46),(.18,.50),(.30,.54),(.50,.56),(.80,.50)],
    [(-.85,.39),(-.55,.64),(-.25,.62),(-.05,.60),(.14,.65),(.28,.72),(.45,.74),(.86,.79)],
    [(-.99,-.04),(-.91,.02),(-.84,.09),(-.73,.10),(-.60,.11),(-.48,.50),(-.40,.68),(.82,.81)],
    [(-.85,.10),(-.65,.17),(-.35,.20),(-.20,.21),(-.02,.22),(.10,.50),(.24,.62),(.84,.65)],
    [(-.84,.36),(-.50,.46),(.25,.50),(.40,.47),(.53,.44),(.70,.43),(.80,.42),(.89,.38)],
    [(-.80,.38),(-.40,.56),(.15,.62),(.36,.61),(.50,.57),(.69,.43),(.79,.34),(.86,.24)],
    [(-.80,.13),(-.45,.26),(-.10,.30),(.13,.33),(.32,.33),(.52,.31),(.72,.26),(.89,.22)]
]
vertices=[]
for i,(x,wide,tall,lift) in enumerate(stations):
    for j,(y,z) in enumerate(profile):
        if 3<=j<=10:y,z=top_profiles[i][j-3]
        if i==2 and j==2:y,z=-1.02,-.12
        dy=.17*x+.025*math.sin(i*2.1+j*.71)
        dz=lift-.08*x+(.10 if j in (9,10) and i==1 else 0)
        dx=.10*math.sin(j*1.04+i*.7)+(.14*y if j>=8 else 0)
        vertices.append((x+dx,y*wide+dy,z*tall+dz))

faces=[]
indices=[]
width=len(profile)
for i in range(len(stations)-1):
    for j in range(width):
        corners=(i*width+j,(i+1)*width+j,(i+1)*width+(j+1)%width,i*width+(j+1)%width)
        mat=0
        if j in (3,4,8,9):mat=1
        if i in (0,1) and j in (5,6,7):mat=1
        if i in (4,5) and j in (5,6):mat=1
        if j in (0,11,12,13):mat=3 if (i+j)%4==0 else 0
        if (i,j) in ((0,3),(0,4),(5,8),(5,9)):mat=3
        if (i,j) in ((1,2),(4,5)):mat=4
        if (i,j) in ((1,8),(3,8),(3,6),(2,5),(4,5)):mat=2
        if (i,j) in ((1,3),(2,3),(4,8),(4,9),(5,8)):mat=3
        if (i,j) in ((0,7),(4,7)):mat=3
        faces.append(corners)
        indices.append(mat)
faces.extend([tuple(range(width-1,-1,-1)),tuple((len(stations)-1)*width+j for j in range(width))])
indices.extend([0,3])
mesh=bpy.data.meshes.new('CopperGeologyMesh')
mesh.from_pydata(vertices,[],faces)
mesh.update()
body=bpy.data.objects.new('CopperGeology',mesh)
bpy.context.scene.collection.objects.link(body)
for mat in materials:mesh.materials.append(mat)
for face,mat in zip(mesh.polygons,indices):face.material_index=mat
bm=bmesh.new()
bm.from_mesh(mesh)
bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces))
bm.to_mesh(mesh)
bm.free()

def cut(name,points):
    cutter_mesh=bpy.data.meshes.new(name+'Mesh')
    cutter_mesh.from_pydata(points,[],[])
    bm=bmesh.new()
    bm.from_mesh(cutter_mesh)
    bmesh.ops.convex_hull(bm,input=list(bm.verts))
    bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces))
    bm.to_mesh(cutter_mesh)
    bm.free()
    cutter=bpy.data.objects.new(name,cutter_mesh)
    bpy.context.scene.collection.objects.link(cutter)
    cutter_mesh.materials.append(materials[3])
    bpy.context.view_layer.objects.active=body
    body.select_set(True)
    mod=body.modifiers.new(name,'BOOLEAN')
    mod.operation='DIFFERENCE'
    mod.solver='EXACT'
    mod.object=cutter
    bpy.ops.object.modifier_apply(modifier=mod.name)
    bpy.data.objects.remove(cutter,do_unlink=True)

cut('Front angular chip',[(-1.18,-1.55,.35),(-.63,-1.40,.51),(-.85,-.61,.20),(-1.04,-1.30,-.38)])
cut('Broken lower tip',[(1.34,-.80,.52),(2.17,-.73,.44),(1.63,-.22,.19),(1.84,-.90,-.35)])
cut('Rear ridge flake',[(.63,1.57,.91),(1.32,1.59,.80),(.94,.74,.51),(.68,1.39,.14)])
cut('High cleavage flake',[(-1.35,-.77,1.18),(-.72,-.70,1.14),(-.88,-.30,.52),(-1.22,-.94,.35)])
cut('Left broad split',[(-2.3,-.25,.82),(-1.64,-.40,1.1),(-1.59,-.07,.40),(-2.15,.15,.35)])

body['art_proof']=True
body['locale']=1
body['revision']=2
body['mineral_assignment']='Copper follows exposed sloping planes; patina follows selected cleavage lips.'
uv=body.data.uv_layers.new(name='ExportUV')
bpy.context.view_layer.objects.active=body
bpy.ops.object.mode_set(mode='EDIT')
bpy.ops.mesh.select_all(action='SELECT')
bpy.ops.uv.smart_project(angle_limit=1.1,island_margin=.03,scale_to_bounds=True)
bpy.ops.object.mode_set(mode='OBJECT')

def contour(surface):
    obj=surface.copy()
    obj.data=surface.data.copy()
    obj.name='CopperPreviewContour'
    obj['preview_only']=True
    del obj['art_proof']
    bpy.context.scene.collection.objects.link(obj)
    for vertex in obj.data.vertices:vertex.co+=vertex.normal*.016
    bm=bmesh.new()
    bm.from_mesh(obj.data)
    bmesh.ops.reverse_faces(bm,faces=list(bm.faces))
    bm.to_mesh(obj.data)
    bm.free()
    mat=bpy.data.materials.new('Preview contour')
    mat.use_nodes=True
    tree=mat.node_tree
    tree.nodes.clear()
    output=tree.nodes.new('ShaderNodeOutputMaterial')
    geo=tree.nodes.new('ShaderNodeNewGeometry')
    black=tree.nodes.new('ShaderNodeEmission')
    black.inputs[0].default_value=(.008,.010,.016,1)
    transparent=tree.nodes.new('ShaderNodeBsdfTransparent')
    mix=tree.nodes.new('ShaderNodeMixShader')
    tree.links.new(geo.outputs['Backfacing'],mix.inputs[0])
    tree.links.new(black.outputs[0],mix.inputs[1])
    tree.links.new(transparent.outputs[0],mix.inputs[2])
    tree.links.new(mix.outputs[0],output.inputs[0])
    obj.data.materials.clear()
    obj.data.materials.append(mat)
    for face in obj.data.polygons:face.material_index=0
    obj.visible_shadow=False
    obj.visible_diffuse=False
    obj.visible_glossy=False
    return obj

scene=bpy.context.scene
scene.render.engine='CYCLES'
scene.cycles.samples=48
scene.cycles.use_denoising=True
scene.cycles.transparent_max_bounces=16
scene.render.resolution_x=900
scene.render.resolution_y=700
scene.render.resolution_percentage=100
scene.render.film_transparent=True
scene.render.image_settings.file_format='PNG'
scene.render.image_settings.color_mode='RGBA'
scene.world=bpy.data.worlds.new('Neutral review world')
scene.world.use_nodes=True
scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.25,.28,.35,1)
scene.world.node_tree.nodes['Background'].inputs[1].default_value=.50
scene.view_settings.view_transform='AgX'
scene.view_settings.look='AgX - Medium High Contrast'
for name,position,energy,size,color in [('Key',(-3,-4,7),950,3,(1,.98,.94)),('Fill',(4,1,4),400,4,(.88,.93,1))]:
    bpy.ops.object.light_add(type='AREA',location=position)
    light=bpy.context.object
    light.name='Preview'+name
    light.data.energy=energy
    light.data.shape='DISK'
    light.data.size=size
    light.data.color=color
    light.rotation_euler=(-light.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add(location=(2,-8,5.8))
camera=bpy.context.object
camera.name='PreviewCamera'
camera.data.type='ORTHO'
camera.data.ortho_scale=5.0
camera.rotation_euler=(-camera.location).to_track_quat('-Z','Y').to_euler()
scene.camera=camera
contour(body)
scene['proof_stage']='Copper revision 2 geometry and mineral zones. Flat materials before brush texture.'
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'copper-flat.blend'))
for label,position in [('hero',(2,-8,5.8)),('reverse',(-3,7,5.2))]:
    camera.location=position
    camera.rotation_euler=(-camera.location).to_track_quat('-Z','Y').to_euler()
    scene.render.filepath=str(OUT/('copper-flat-'+label+'.png'))
    bpy.ops.render.render(write_still=True)
print('COPPER_DRAFT='+str(OUT),flush=True)
