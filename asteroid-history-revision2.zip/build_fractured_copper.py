"""Build a new blunt Copper host by plane intersections and a carved oblique step.
Reads the prior review scene for lighting only. Writes copper-fractured/ previews
and editable source; exit 0 means both review views completed.
"""
import bpy,bmesh,itertools,math
import numpy as np
from pathlib import Path
from mathutils import Vector
from mathutils.geometry import tessellate_polygon

WORK=Path(__file__).resolve().parent
OUT=WORK/'copper-fractured'
OUT.mkdir(parents=True,exist_ok=True)
bpy.ops.wm.open_mainfile(filepath=str(WORK/'copper/copper-flat.blend'))
bpy.context.preferences.filepaths.save_version=0
contour_mat=bpy.data.objects['CopperPreviewContour'].data.materials[0]
for obj in list(bpy.context.scene.objects):
    if obj.type=='MESH':bpy.data.objects.remove(obj,do_unlink=True)
scene=bpy.context.scene
scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.28,.30,.35,1)
scene.world.node_tree.nodes['Background'].inputs[1].default_value=.65
bpy.data.objects['PreviewFill'].data.energy=500
bpy.data.objects['PreviewFill'].data.color=(.92,.95,1)
scene.view_settings.exposure=-.20

def material(name,color):
    mat=bpy.data.materials.new(name)
    mat.diffuse_color=(*color,1)
    mat.use_nodes=True
    shader=mat.node_tree.nodes.get('Principled BSDF')
    shader.inputs['Base Color'].default_value=(*color,1)
    shader.inputs['Roughness'].default_value=.95
    shader.inputs['Specular IOR Level'].default_value=.04
    return mat

materials=[material('Fractured iron host',(.07,.082,.105)),material('Copper mineral planes',(.32,.115,.045)),material('Cleavage patina',(.055,.24,.22)),material('Fresh iron cleavage',(.105,.12,.15)),material('Oxide end fracture',(.23,.075,.028))]

def polyhedron(name,planes):
    normals=np.array([p[:3] for p in planes],dtype=float)
    limits=np.array([p[3] for p in planes],dtype=float)
    points=[]
    keys=set()
    for indices in itertools.combinations(range(len(planes)),3):
        matrix=normals[list(indices)]
        if abs(np.linalg.det(matrix))<1e-7:continue
        point=np.linalg.solve(matrix,limits[list(indices)])
        if np.all(normals@point<=limits+1e-6):
            key=tuple(np.round(point,6))
            if key not in keys:keys.add(key);points.append(point)
    faces=[]
    source_planes=[]
    for index,(normal,limit) in enumerate(zip(normals,limits)):
        ids=[i for i,p in enumerate(points) if abs(normal@p-limit)<1e-5]
        if len(ids)<3:continue
        n=Vector(normal).normalized()
        u=n.cross(Vector((0,0,1)))
        if u.length<.01:u=n.cross(Vector((0,1,0)))
        u.normalize()
        v=n.cross(u)
        center=sum((Vector(points[i]) for i in ids),Vector())/len(ids)
        ids.sort(key=lambda i:math.atan2((Vector(points[i])-center).dot(v),(Vector(points[i])-center).dot(u)))
        faces.append(ids)
        source_planes.append(index)
    mesh=bpy.data.meshes.new(name+'Mesh')
    mesh.from_pydata(points,[],faces)
    mesh.update()
    obj=bpy.data.objects.new(name,mesh)
    bpy.context.scene.collection.objects.link(obj)
    for mat in materials:mesh.materials.append(mat)
    return obj,source_planes

planes=[(1,0,0,1.78),(-1,0,0,1.65),(0,1,0,1.18),(0,-1,0,1.20),(0,0,1,1.03),(0,0,-1,.91)]
for row,elevation in enumerate((-62,-32,0,32,62)):
    count=10 if abs(elevation)>40 else 14
    for i in range(count):
        angle=math.tau*(i+.27*(row%2))/count+.06*math.sin(i*2.3+row)
        elev=math.radians(elevation+3*math.sin(i*1.7+row))
        n=Vector((math.cos(elev)*math.cos(angle),math.cos(elev)*math.sin(angle),math.sin(elev)))
        a,b,c=1.72,1.16,.96
        rounded=math.sqrt((a*n.x)**2+(b*n.y)**2+(c*n.z)**2)
        box=a*abs(n.x)+b*abs(n.y)+c*abs(n.z)
        support=(.76*rounded+.24*box)*(.965+.04*math.sin(i*2.17+row*2.83))
        planes.append((*n,support))
planes.extend([(-1,-.75,.20,1.79),(1,-.40,.55,1.95),(.40,1,.60,1.63),(-.28,.12,1,.98)])
body,_=polyhedron('CopperFracturedHost',planes)
for face in body.data.polygons:
    face.material_index=1 if face.normal.z>.58 and face.center.z>.42 else 0
    if face.normal.z<-.35 or face.center.y>.73:face.material_index=3 if face.index%4==0 else 0
    if face.normal.x<-.45 and face.normal.z>.12 and face.center.z>.25:face.material_index=4

cut_planes=[(1,0,0,4),(-1,0,0,4),(0,1,0,4),(0,-1,0,4),(0,0,1,4),(0,0,-1,4),(-1,-.55,-.12,.45),(-.22,1,-.20,.27),(-.52,1,-.07,.39),(.08,1,-.30,.26),(-1,-.20,-.35,.40),(.12,.08,-1,-.05),(.27,.12,-1,.03),(-.10,.25,-1,.02)]
cutter,source_planes=polyhedron('Oblique stepped cleavage',cut_planes)
for face,index in zip(cutter.data.polygons,source_planes):face.material_index=1 if index>=11 else 3
bpy.context.view_layer.objects.active=body
body.select_set(True)
mod=body.modifiers.new('Open stepped fracture','BOOLEAN')
mod.operation='DIFFERENCE'
mod.solver='EXACT'
mod.object=cutter
bpy.ops.object.modifier_apply(modifier=mod.name)
bpy.data.objects.remove(cutter,do_unlink=True)

body.data.update()

old=body.data
vertices=[v.co.copy() for v in old.vertices]
edge_faces={}
for face in old.polygons:
    for a,b in zip(face.vertices,tuple(face.vertices[1:])+tuple(face.vertices[:1])):
        edge_faces.setdefault(tuple(sorted((a,b))),[]).append(face)
midpoints={}
for index,(edge,faces) in enumerate(edge_faces.items()):
    a,b=(vertices[i] for i in edge)
    if (b-a).length<.65:continue
    t=.42+.13*math.sin(index*2.37)
    point=a.lerp(b,t)
    normal=sum((f.normal for f in faces),Vector()).normalized()
    point+=normal*(-.035-.045*(.5+.5*math.sin(index*3.1)))
    midpoints[edge]=len(vertices)
    vertices.append(point)
faces_out=[]
slots=[]
for face in old.polygons:
    boundary=[]
    original=list(face.vertices)
    for a,b in zip(original,original[1:]+original[:1]):
        boundary.append(a)
        key=tuple(sorted((a,b)))
        if key in midpoints:boundary.append(midpoints[key])
    lookup={tuple(vertices[i]):i for i in boundary}
    triangles=[tuple(lookup[tuple(p)] for p in tri) for tri in tessellate_polygon([[vertices[i] for i in boundary]])]
    target=max(len(triangles),round(face.area/(.14 if face.normal.z>.5 else .11)))
    def area(tri):
        a,b,c=(vertices[i] for i in tri)
        return (b-a).cross(c-a).length/2
    while len(triangles)<target:
        tri=max(triangles,key=area)
        triangles.remove(tri)
        a,b,c=(vertices[i] for i in tri)
        point=a*.27+b*.35+c*.38
        point-=face.normal*((point-face.center).dot(face.normal))
        relief=.075 if face.normal.z>.5 else .125
        offset=relief*(.65*math.sin(face.index*2.13+len(triangles)*1.31)+.35*math.sin(point.x*4.2+point.z*5.7))
        point+=face.normal*offset
        center_index=len(vertices)
        vertices.append(point)
        triangles.extend([(tri[0],tri[1],center_index),(tri[1],tri[2],center_index),(tri[2],tri[0],center_index)])
    faces_out.extend(triangles)
    slots.extend([face.material_index]*len(triangles))
for point in vertices:point.x*=1.1
mesh=bpy.data.meshes.new('CopperFracturedPlanes')
mesh.from_pydata(vertices,[],faces_out)
mesh.update()
for mat in materials:mesh.materials.append(mat)
for face,slot in zip(mesh.polygons,slots):face.material_index=slot
body.data=mesh

body['art_proof']=True
body['locale']=1
body['revision']=2
body['construction']='Blunt multi-plane host with an open oblique stepped fracture.'
uv=body.data.uv_layers.new(name='ExportUV')
bpy.ops.object.mode_set(mode='EDIT')
bpy.ops.mesh.select_all(action='SELECT')
bpy.ops.uv.smart_project(angle_limit=.85,island_margin=.035,scale_to_bounds=True)
bpy.ops.object.mode_set(mode='OBJECT')
contour=body.copy()
contour.data=body.data.copy()
contour.name='CopperPreviewContour'
contour['preview_only']=True
del contour['art_proof']
bpy.context.scene.collection.objects.link(contour)
for vertex in contour.data.vertices:vertex.co+=vertex.normal*.013
bm=bmesh.new()
bm.from_mesh(contour.data)
bmesh.ops.reverse_faces(bm,faces=list(bm.faces))
bm.to_mesh(contour.data)
bm.free()
contour.data.materials.clear()
contour.data.materials.append(contour_mat)
for face in contour.data.polygons:face.material_index=0
contour.visible_shadow=False
contour.visible_diffuse=False
contour.visible_glossy=False
scene.render.resolution_x=900
scene.render.resolution_y=700
scene.cycles.samples=48
scene.camera.data.ortho_scale=4.9
scene.camera.location=(3,-7,5.4)
scene.camera.rotation_euler=(-scene.camera.location).to_track_quat('-Z','Y').to_euler()
scene['proof_stage']='New Copper host, flat mineral assignments before patina and painting.'
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'copper-flat.blend'))
for label,position in [('hero',(3,-7,5.4)),('reverse',(-3,7,5.2))]:
    scene.camera.location=position
    scene.camera.rotation_euler=(-scene.camera.location).to_track_quat('-Z','Y').to_euler()
    scene.render.filepath=str(OUT/('copper-flat-'+label+'.png'))
    bpy.ops.render.render(write_still=True)
print('FRACTURED_COPPER='+str(OUT),flush=True)
