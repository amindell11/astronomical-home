"""Export an already inspected selected BLEND without changing its artwork.
Required --family NAME. Exit 0 writes FBX and GLB containing only art meshes.
"""
import bpy,sys
from pathlib import Path
args=sys.argv[sys.argv.index('--')+1:]
family=args[args.index('--family')+1]
dest=Path(__file__).resolve().parent/(family+'-selected')
bpy.ops.wm.open_mainfile(filepath=str(dest/(family+'.blend')))
for obj in bpy.context.selected_objects:obj.select_set(False)
models=[obj for obj in bpy.context.scene.objects if obj.type=='MESH' and obj.get('art_proof')]
for obj in models:obj.select_set(True)
bpy.context.view_layer.objects.active=models[0]
bpy.ops.export_scene.fbx(filepath=str(dest/(family+'.fbx')),use_selection=True,object_types={'MESH'},bake_anim=False,path_mode='COPY',embed_textures=True,axis_forward='-Z',axis_up='Y')
bpy.ops.export_scene.gltf(filepath=str(dest/(family+'.glb')),export_format='GLB',use_selection=True,export_yup=True)
print('EXPORTED='+family,flush=True)
