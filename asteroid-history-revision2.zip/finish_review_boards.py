"""Compose existing proof images and copy the selected painting provenance.
No artwork pixels or mesh assets are modified.
"""
import hashlib,json,shutil
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont

ROOT=Path(__file__).resolve().parent/'deliverables'
REFERENCE=Path('D:/amind/scratch/asteroid-locale-concepts-20261106')
FAMILIES=[('copper','1 Copper',(400,138,733,301)),('violet','2 Violet',(400,311,705,481)),('chalk','3 Chalk',(390,490,733,649)),('verdant','6 Verdant',(400,660,714,820)),('ice','7 Ice',(376,833,734,1000))]
BG=(30,38,50,255)
FG=(231,232,225,255)
MUTED=(174,184,196,255)
FONT='C:/Windows/Fonts/segoeui.ttf'

def label(canvas,xy,value,size=22,color=FG):
    ImageDraw.Draw(canvas).text(xy,value,font=ImageFont.truetype(FONT,size),fill=color)

def subject(path):
    image=Image.open(path).convert('RGBA')
    return image.crop(image.getchannel('A').getbbox())

def fit(canvas,image,box):
    x,y,w,h=box
    scale=min(w/image.width,h/image.height)
    resized=image.resize((round(image.width*scale),round(image.height*scale)),Image.Resampling.LANCZOS)
    canvas.alpha_composite(resized,(x+(w-resized.width)//2,y+(h-resized.height)//2))

concept=Image.open(REFERENCE/'asteroids-by-locale.png').convert('RGBA')
board=Image.new('RGBA',(1450,1210),BG)
label(board,(26,18),'Locale asteroids: concept to mesh',32)
label(board,(27,61),'Blender art previews',20,MUTED)
for x,title in ((150,'Approved concept'),(514,'Previous 3D'),(878,'Revised 3D'),(1254,'128 px')):
    label(board,(x,104),title,23)
for row,(family,title,crop) in enumerate(FAMILIES):
    top=145+row*208
    label(board,(26,top+87),title,22)
    fit(board,concept.crop(crop),(145,top+8,340,184))
    fit(board,subject(REFERENCE/'art-proof'/family/(family+'-hero.png')),(509,top+8,340,184))
    fit(board,subject(ROOT/family/(family+'-hero.png')),(873,top+8,340,184))
    thumb=Image.open(ROOT/family/(family+'-game-128.png')).convert('RGBA')
    assert thumb.width==128
    board.alpha_composite(thumb,(1260,top+(208-thumb.height)//2))
    ImageDraw.Draw(board).line((24,top+205,1424,top+205),fill=(66,76,90,255))
board.convert('RGB').save(ROOT/'asteroid-before-after.png')

checks=Image.new('RGBA',(1260,1200),BG)
label(checks,(26,18),'Export appearance checks',32)
label(checks,(27,61),'Blender art previews under matched scene lighting',20,MUTED)
for x,title in ((145,'Packed BLEND'),(514,'GLB reimport'),(885,'FBX reimport')):
    label(checks,(x,104),title,23)
for row,(family,title,_) in enumerate(FAMILIES):
    top=145+row*208
    label(checks,(26,top+87),title,22)
    paths=[ROOT/family/(family+'-hero.png')]+[ROOT/'reimport-checks'/(family+'-'+ext+'.png') for ext in ('glb','fbx')]
    for col,path in enumerate(paths):fit(checks,subject(path),(140+col*370,top+8,340,184))
checks.convert('RGB').save(ROOT/'asteroid-reimport-checks.png')

chains={
    'copper':['copper-selected-prompt.txt','copper-padding-prompt.txt'],
    'violet':['violet-paint-prompt.txt','violet-deeper-prompt.txt'],
    'chalk':['chalk-paint-prompt.txt'],
    'verdant':['verdant-paint-prompt.txt','verdant-deeper-prompt.txt'],
    'ice':['ice-paint-prompt.txt'],
}
originals={'copper':'copper-selected-padded.png','violet':'violet-painted-deeper.png','chalk':'chalk-painted-uv.png','verdant':'verdant-painted-deeper.png','ice':'ice-painted-uv.png'}
provenance={'method':'Geometry-aware unlit color guides and packed UV layouts, painted with built-in Imagegen. Final PNGs are unchanged generated outputs. No lighting, AO or specular bake is used.','families':[]}
for family,_,_ in FAMILIES:
    folder=ROOT/family
    prompts=folder/'prompts'
    prompts.mkdir(exist_ok=True)
    for name in chains[family]:shutil.copy2(REFERENCE/'revision2'/name,prompts/name)
    actual=folder/(family+'-albedo.png')
    original=REFERENCE/'revision2'/originals[family]
    digest=hashlib.sha256(actual.read_bytes()).hexdigest()
    assert digest==hashlib.sha256(original.read_bytes()).hexdigest(),family
    item={'family':family,'generator':'built-in Imagegen','albedo':family+'/'+actual.name,'albedo_size':[1254,1254],'sha256':digest,'unlit_region_guide':family+'/'+family+'-eroded-color.png','uv_layout':family+'/'+family+'-uv-layout.png','prompts':[family+'/prompts/'+name for name in chains[family]]}
    if family=='violet':item['uv_note']='New lip-chip faces reuse a quiet host paint region; existing UVs were preserved.'
    provenance['families'].append(item)
(ROOT/'texture-provenance.json').write_text(json.dumps(provenance,indent=2))
print('BEFORE_AFTER='+str(ROOT/'asteroid-before-after.png'))
print('REIMPORT_BOARD='+str(ROOT/'asteroid-reimport-checks.png'))
