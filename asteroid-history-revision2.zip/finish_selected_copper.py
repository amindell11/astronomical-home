"""Apply the supplied painted map to frozen Copper UVs and rebuild preview outline.
Writes copper.blend and three current renders; original painting remains unchanged.
"""
import bpy,bmesh,shutil
from pathlib import Path

OUT=Path(__file__).resolve().parent/'copper-selected'
bpy.ops.wm.open_mainfile(filepath=str(OUT/'copper-flat.blend'))
bpy.context.preferences.filepaths.save_version=0
body=bpy.data.objects['CopperSurface']
old_contours=[obj for obj in bpy.context.scene.objects if obj.get('preview_only')]
outline=old_contours[0].data.materials[0]
for obj in old_contours:bpy.data.objects.remove(obj,do_unlink=True)
contour=body.copy()
contour.data=body.data.copy()
contour.name='CopperPreviewContour'
del contour['art_proof']
contour['preview_only']=True
bpy.context.scene.collection.objects.link(contour)
for vertex in contour.data.vertices:vertex.co*=1.005
bm=bmesh.new()
bm.from_mesh(contour.data)
bmesh.ops.reverse_faces(bm,faces=list(bm.faces))
bm.to_mesh(contour.data)
bm.free()
contour.data.materials.clear()
contour.data.materials.append(outline)
for face in contour.data.polygons:face.material_index=0
contour.visible_shadow=False
contour.visible_diffuse=False
contour.visible_glossy=False
dest=OUT/'copper-painted-albedo.png'
shutil.copy2(Path(r'D:/amind/scratch/asteroid-locale-concepts-20261106/revision2/copper-selected-painted.png'),dest)
image=bpy.data.images.load(str(dest),check_existing=False)
image.name='CopperPaintedAlbedo'
image.pack()
image.filepath='//'+dest.name
mat=body.data.materials[0]
next(node for node in mat.node_tree.nodes if node.type=='TEX_IMAGE').image=image
scene=bpy.context.scene
scene['proof_stage']='Copper revision 2, UV-painted geological mineral zones on unequal sloping fractured slabs.'
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'copper.blend'))
for label,position in [('hero',(2,-8,6.8)),('reverse',(-3,7,5.8)),('side',(4,-8,2.7))]:
    scene.camera.location=position
    scene.camera.rotation_euler=(-scene.camera.location).to_track_quat('-Z','Y').to_euler()
    scene.render.filepath=str(OUT/('copper-'+label+'.png'))
    bpy.ops.render.render(write_still=True)
print('COPPER_PAINT_REVIEW='+str(OUT),flush=True)
