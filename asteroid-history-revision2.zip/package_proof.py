"""Collect the five selected proofs and compose existing renders for review.
Writes revision2/deliverables; source textures are copied without modification.
"""
import json,shutil
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont

WORK=Path(__file__).resolve().parent
OUT=WORK/'deliverables'
FAMILIES=[('copper','1  Copper ore'),('violet','2  Violet crystal host'),('chalk','3  Layered chalk'),('verdant','6  Verdant nodule'),('ice','7  Dirty ring ice')]
BG=(30,38,50,255)
FONT='C:/Windows/Fonts/segoeui.ttf'

def text(image,xy,label,size=22,color=(231,232,225,255)):
    ImageDraw.Draw(image).text(xy,label,font=ImageFont.truetype(FONT,size),fill=color)

def subject(path,width):
    image=Image.open(path).convert('RGBA')
    image=image.crop(image.getchannel('A').getbbox())
    return image.resize((width,round(image.height*width/image.width)),Image.Resampling.LANCZOS)

for family,title in FAMILIES:
    dest=OUT/family
    dest.mkdir(parents=True,exist_ok=True)
    source=WORK/(family+'-selected')
    files=[family+'.'+extension for extension in ('blend','fbx','glb')]+[family+'-'+suffix+'.png' for suffix in ('albedo','eroded-color','uv-layout','hero','reverse','side')]
    for name in files:shutil.copy2(source/name,dest/name)
    for width in (128,96):
        thumb=subject(dest/(family+'-hero.png'),width)
        image=Image.new('RGBA',thumb.size,BG)
        image.alpha_composite(thumb)
        image.convert('RGB').save(dest/(family+f'-game-{width}.png'))

sheet=Image.new('RGBA',(1580,1060),BG)
text(sheet,(28,20),'Locale asteroid meshes',34)
text(sheet,(29,67),'Revision 2  |  UV-painted mineral regions  |  Blender art proof',20,(174,184,196,255))
for index,(family,title) in enumerate(FAMILIES):
    left=22+index*312
    text(sheet,(left+8,118),title,22)
    hero=subject(OUT/family/(family+'-hero.png'),292)
    sheet.alpha_composite(hero,(left+4,170+(300-hero.height)//2))
    for column,view in enumerate(('reverse','side')):
        image=subject(OUT/family/(family+'-'+view+'.png'),140)
        sheet.alpha_composite(image,(left+column*154,508+(150-image.height)//2))
        text(sheet,(left+column*154+4,674),view.capitalize(),17,(174,184,196,255))
    text(sheet,(left+6,730),'128 px',18,(174,184,196,255))
    text(sheet,(left+171,730),'96 px',18,(174,184,196,255))
    for width,x in ((128,left+3),(96,left+168)):
        image=subject(OUT/family/(family+'-hero.png'),width)
        sheet.alpha_composite(image,(x,775+(130-image.height)//2))
text(sheet,(30,957),'Current field asteroid under the same lighting',20,(174,184,196,255))
base=subject(OUT/'baseline/baseline-hero.png',128)
sheet.alpha_composite(base,(535,938))
text(sheet,(705,962),'Top: close view. Middle: reverse and low side view.',19,(174,184,196,255))
text(sheet,(705,996),'No runtime integration or gameplay collision data.',19,(174,184,196,255))
sheet.convert('RGB').save(OUT/'asteroid-mesh-proof-sheet.png')
game=Image.new('RGBA',(1000,320),BG)
text(game,(24,15),'Game-size comparison',25)
for index,(family,title) in enumerate(FAMILIES):
    x=20+index*196
    text(game,(x,65),title,17)
    thumb=subject(OUT/family/(family+'-hero.png'),128)
    game.alpha_composite(thumb,(x+20,110+(140-thumb.height)//2))
    text(game,(x+30,266),'128 px wide',17,(174,184,196,255))
game.convert('RGB').save(OUT/'asteroid-game-scale.png')
print('COMPARISON='+str(OUT/'asteroid-mesh-proof-sheet.png'))
