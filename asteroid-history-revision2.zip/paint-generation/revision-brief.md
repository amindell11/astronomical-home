## What did the owner reject in the first 3D pass?

On 2026-11-06 the owner asked for another art pass because the textures did not fit the meshes and the result fell short of the approved concepts. The concepts remain the target. The first proof is not approved.

The large recolored patches in the source maps land independently of the actual plates and fractures. The slab geometry is too regular, and the reused rounded hosts lose the specific mineral structure in the concepts.

## What changes in the revision?

Rebuild copper first around actual fractured planes. Place copper, iron-grey host and sparse turquoise patina by the rock's structure, then add brush texture within those regions. Bake the material color into a packed UV map for ordinary mesh exports. Check the result against the approved concept at close view, game size and from behind before applying the approach to the other four families.

The five approved locales and asteroid-only scope stay the same. Production spawning and physics bakes remain after art acceptance.
