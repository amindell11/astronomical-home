"""Bake flat mineral zones and geometry-guided brush color on Copper's packed UVs.
Reads copper-flat.blend and the supplied pigment atlas. Exit 0 writes maps,
editable source, FBX/GLB and three textured review views in copper/.
"""
import bpy,bmesh,json,math,shutil
from pathlib import Path
from mathutils import Vector

WORK=Path(__file__).resolve().parent
OUT=WORK/'copper'
bpy.ops.wm.open_mainfile(filepath=str(OUT/'copper-flat.blend'))
bpy.context.preferences.filepaths.save_version=0
scene=bpy.context.scene
scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.25,.28,.35,1)
scene.world.node_tree.nodes['Background'].inputs[1].default_value=.50
bpy.data.objects['PreviewFill'].data.energy=400
bpy.data.objects['PreviewFill'].data.color=(.88,.93,1)
body=bpy.data.objects['CopperGeology']
for obj in bpy.context.selected_objects:obj.select_set(False)
body.select_set(True)
bpy.context.view_layer.objects.active=body

def bake(name):
    image=bpy.data.images.new(name,width=2048,height=2048,alpha=False)
    image.colorspace_settings.name='sRGB'
    outputs=[]
    for mat in body.data.materials:
        tree=mat.node_tree
        shader=tree.nodes.get('Principled BSDF')
        emission=tree.nodes.new('ShaderNodeEmission')
        color=shader.inputs['Base Color']
        if color.is_linked:tree.links.new(color.links[0].from_socket,emission.inputs[0])
        else:emission.inputs[0].default_value=color.default_value
        output=next(node for node in tree.nodes if node.type=='OUTPUT_MATERIAL')
        tree.links.new(emission.outputs[0],output.inputs[0])
        target=tree.nodes.new('ShaderNodeTexImage')
        target.image=image
        tree.nodes.active=target
        outputs.append((tree,shader,output,emission,target))
    scene.cycles.samples=1
    bpy.ops.object.bake(type='EMIT',margin=20,use_clear=True)
    for tree,shader,output,emission,target in outputs:
        tree.links.new(shader.outputs[0],output.inputs[0])
        tree.nodes.remove(emission)
        tree.nodes.remove(target)
    image.filepath_raw=str(OUT/(name+'.png'))
    image.file_format='PNG'
    image.save()
    image.pack()
    scene.cycles.samples=48
    return image

flat=bake('copper-flat-color')
flat.use_fake_user=True
uv=body.data.uv_layers['ExportUV']
(OUT/'copper-uv-layout.json').write_text(json.dumps([[list(uv.data[i].uv) for i in p.loop_indices] for p in body.data.polygons]))

boundaries={index:[] for index in range(len(body.data.materials))}
bm=bmesh.new()
bm.from_mesh(body.data)
for edge in bm.edges:
    slots={face.material_index for face in edge.link_faces}
    if len(slots)>1:
        for slot in slots:boundaries[slot].append(tuple(v.co.copy() for v in edge.verts))
bmesh.ops.triangulate(bm,faces=list(bm.faces))
bmesh.ops.subdivide_edges(bm,edges=list(bm.edges),cuts=3,use_grid_fill=True)
bm.to_mesh(body.data)
bm.free()
body.data.update()

def distance(point,a,b):
    edge=b-a
    t=max(0,min(1,(point-a).dot(edge)/edge.length_squared))
    return (point-a-edge*t).length

interior=body.data.attributes.new('MineralInterior','FLOAT','CORNER')
brush=body.data.uv_layers.new(name='BrushSourceUV')
for face in body.data.polygons:
    edges=boundaries[face.material_index]
    for loop in face.loop_indices:
        co=body.data.vertices[body.data.loops[loop].vertex_index].co
        interior.data[loop].value=min((distance(co,a,b) for a,b in edges),default=1)
        v=(co.y+.1*co.x+1.6)/3.2 if abs(face.normal.z)>.5 else (co.z+.9)/2.2
        brush.data[loop].uv=((co.x+2.2)/4.4,max(.02,min(.98,v)))
body.data.uv_layers.active_index=body.data.uv_layers.find('ExportUV')
body.data.uv_layers.active.active_render=True

atlas_path=OUT/'copper-pigment-source.png'
shutil.copy2(Path(r'D:/amind/scratch/asteroid-locale-concepts-20261106/revision2/copper-pigment-weathered.png'),atlas_path)
atlas=bpy.data.images.load(str(atlas_path),check_existing=False)
atlas.name='CopperPigmentSource'
atlas.pack()
atlas.use_fake_user=True

for index,mat in enumerate(body.data.materials):
    tree=mat.node_tree
    shader=tree.nodes['Principled BSDF']
    uvnode=tree.nodes.new('ShaderNodeUVMap')
    uvnode.uv_map='BrushSourceUV'
    separate=tree.nodes.new('ShaderNodeSeparateXYZ')
    tree.links.new(uvnode.outputs[0],separate.inputs[0])
    def sample(strip):
        scale=tree.nodes.new('ShaderNodeMath')
        scale.operation='MULTIPLY_ADD'
        scale.inputs[1].default_value=.24
        scale.inputs[2].default_value={'rust':.71,'iron':.38,'patina':.045}[strip]
        tree.links.new(separate.outputs['Y'],scale.inputs[0])
        combine=tree.nodes.new('ShaderNodeCombineXYZ')
        tree.links.new(separate.outputs['X'],combine.inputs['X'])
        tree.links.new(scale.outputs[0],combine.inputs['Y'])
        tex=tree.nodes.new('ShaderNodeTexImage')
        tex.image=atlas
        tree.links.new(combine.outputs[0],tex.inputs[0])
        return tex.outputs['Color']
    host=sample('iron')
    pigment=sample('patina' if index==2 else 'rust') if index in (1,2,4) else host
    color=pigment
    coordinates=tree.nodes.new('ShaderNodeTexCoord')
    vector=tree.nodes.new('ShaderNodeVectorMath')
    vector.operation='MULTIPLY'
    vector.inputs[1].default_value=(4,22,12)
    tree.links.new(coordinates.outputs['Object'],vector.inputs[0])
    noise=tree.nodes.new('ShaderNodeTexNoise')
    noise.inputs['Scale'].default_value=1
    noise.inputs['Detail'].default_value=2
    noise.inputs['Roughness'].default_value=.7
    tree.links.new(vector.outputs[0],noise.inputs[0])
    if index in (1,2,4):
        attr=tree.nodes.new('ShaderNodeAttribute')
        attr.attribute_name='MineralInterior'
        threshold=tree.nodes.new('ShaderNodeMath')
        threshold.operation='MULTIPLY_ADD'
        threshold.inputs[1].default_value=.055 if index==2 else .14
        threshold.inputs[2].default_value=.002 if index==2 else .015
        tree.links.new(noise.outputs['Fac'],threshold.inputs[0])
        delta=tree.nodes.new('ShaderNodeMath')
        delta.operation='SUBTRACT'
        tree.links.new(attr.outputs['Fac'],delta.inputs[0])
        tree.links.new(threshold.outputs[0],delta.inputs[1])
        ramp=tree.nodes.new('ShaderNodeMapRange')
        ramp.clamp=True
        ramp.inputs['From Min'].default_value=-.015
        ramp.inputs['From Max'].default_value=.012
        tree.links.new(delta.outputs[0],ramp.inputs['Value'])
        mix=tree.nodes.new('ShaderNodeMixRGB')
        tree.links.new(ramp.outputs[0],mix.inputs[0])
        tree.links.new(host,mix.inputs[1])
        tree.links.new(pigment,mix.inputs[2])
        color=mix.outputs[0]
    broad=tree.nodes.new('ShaderNodeTexNoise')
    broad.inputs['Scale'].default_value=1.1
    broad.inputs['Detail'].default_value=0
    tree.links.new(coordinates.outputs['Object'],broad.inputs[0])
    values=tree.nodes.new('ShaderNodeMapRange')
    values.inputs['To Min'].default_value=.78 if index!=3 else .97
    values.inputs['To Max'].default_value=1.25 if index!=3 else 1.35
    tree.links.new(broad.outputs['Fac'],values.inputs['Value'])
    multiply=tree.nodes.new('ShaderNodeMixRGB')
    multiply.blend_type='MULTIPLY'
    multiply.inputs[0].default_value=1
    tree.links.new(color,multiply.inputs[1])
    tree.links.new(values.outputs[0],multiply.inputs[2])
    tree.links.new(multiply.outputs[0],shader.inputs['Base Color'])

bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'copper-paint-source.blend'))
albedo=bake('copper-albedo')
export_mat=bpy.data.materials.new('Copper painted mineral')
export_mat.use_nodes=True
shader=export_mat.node_tree.nodes.get('Principled BSDF')
shader.inputs['Roughness'].default_value=.94
shader.inputs['Specular IOR Level'].default_value=.04
texture=export_mat.node_tree.nodes.new('ShaderNodeTexImage')
texture.image=albedo
export_mat.node_tree.links.new(texture.outputs['Color'],shader.inputs['Base Color'])
body.data.materials.clear()
body.data.materials.append(export_mat)
for face in body.data.polygons:face.material_index=0
body.data.uv_layers.remove(body.data.uv_layers['BrushSourceUV'])
body.data.attributes.remove(body.data.attributes['MineralInterior'])
for image in (atlas,flat,albedo):image.filepath='//'+Path(image.filepath).name
scene['proof_stage']='Copper revision 2, geological mineral zones and directional brush pigment baked without lighting.'
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'copper.blend'))
bpy.ops.export_scene.fbx(filepath=str(OUT/'copper.fbx'),use_selection=True,object_types={'MESH'},bake_anim=False,path_mode='COPY',embed_textures=True,axis_forward='-Z',axis_up='Y')
bpy.ops.export_scene.gltf(filepath=str(OUT/'copper.glb'),export_format='GLB',use_selection=True,export_yup=True)
for label,position in [('hero',(2,-8,5.8)),('reverse',(-3,7,5.2)),('side',(5,-7,2.5))]:
    scene.camera.location=position
    scene.camera.rotation_euler=(-scene.camera.location).to_track_quat('-Z','Y').to_euler()
    scene.render.filepath=str(OUT/('copper-'+label+'.png'))
    bpy.ops.render.render(write_still=True)
print('COPPER_TEXTURED='+str(OUT),flush=True)
