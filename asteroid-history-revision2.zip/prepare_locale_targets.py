"""Prepare four geometry-aware UV painting targets, with neutral host gutters.
Run with --family chalk|ice|verdant|violet, or omit for the four-family batch.
Exit 0 writes a flat BLEND, unlit PNG, UV layout JSON and two review views.
"""
import bpy,bmesh,math,json,sys
from pathlib import Path
from mathutils import Vector,Matrix
from mathutils.noise import noise

WORK=Path(__file__).resolve().parent
V1=WORK.parent/'deliverables'
argv=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
FAMILIES=[argv[argv.index('--family')+1]] if '--family' in argv else ['chalk','ice','verdant','violet']
HOST={'chalk':(.14,.17,.22),'ice':(.22,.33,.43),'verdant':(.15,.19,.14),'violet':(.14,.11,.20)}

def material(name,color):
    mat=bpy.data.materials.new(name)
    mat.diffuse_color=(*color,1)
    mat.use_nodes=True
    shader=mat.node_tree.nodes['Principled BSDF']
    shader.inputs['Base Color'].default_value=(*color,1)
    shader.inputs['Roughness'].default_value=.95
    shader.inputs['Specular IOR Level'].default_value=.04
    return mat

def append_objects(path,names):
    with bpy.data.libraries.load(str(path),link=False) as (old,new):new.objects=names
    for obj in new.objects:bpy.context.scene.collection.objects.link(obj)
    return new.objects

def outline(surface,mat):
    obj=surface.copy()
    obj.data=surface.data.copy()
    obj.name=surface.name+'PreviewContour'
    obj['preview_only']=True
    if 'art_proof' in obj:del obj['art_proof']
    bpy.context.scene.collection.objects.link(obj)
    for vertex in obj.data.vertices:vertex.co*=1.004
    bm=bmesh.new()
    bm.from_mesh(obj.data)
    bmesh.ops.reverse_faces(bm,faces=list(bm.faces))
    bm.to_mesh(obj.data)
    bm.free()
    obj.data.materials.clear()
    obj.data.materials.append(mat)
    for face in obj.data.polygons:face.material_index=0
    obj.visible_shadow=False
    obj.visible_diffuse=False
    obj.visible_glossy=False

def crystal(name,position,radius,height,angle,mats):
    verts=[]
    sides=5
    for level,z in enumerate((0,height)):
        for i in range(sides):
            a=angle+i*math.tau/sides+.10*math.sin(i*2.1+angle)
            r=radius*(1+.14*math.sin(i*2.8+angle))*(.85 if level else 1)
            verts.append((position[0]+r*math.cos(a)+level*.12,position[1]+r*math.sin(a)-level*.05,position[2]+z+(.045*math.sin(a) if level else 0)))
    verts.append((position[0]+.08,position[1]-.04,position[2]+height+.11))
    faces=[tuple(range(sides-1,-1,-1))]+[(i,(i+1)%sides,(i+1)%sides+sides,i+sides) for i in range(sides)]+[(sides+i,sides+(i+1)%sides,2*sides) for i in range(sides)]
    mesh=bpy.data.meshes.new(name+'Mesh')
    mesh.from_pydata(verts,[],faces)
    mesh.update()
    obj=bpy.data.objects.new(name,mesh)
    bpy.context.scene.collection.objects.link(obj)
    for mat in mats:mesh.materials.append(mat)
    for face in mesh.polygons:face.material_index=(face.index+int(angle*3))%len(mats)
    return obj

def prepare(family):
    dest=WORK/(family+'-selected')
    dest.mkdir(parents=True,exist_ok=True)
    bpy.ops.wm.open_mainfile(filepath=str(WORK/'copper-selected/copper-flat.blend'))
    bpy.context.preferences.filepaths.save_version=0
    contour_material=next(obj for obj in bpy.context.scene.objects if obj.get('preview_only')).data.materials[0]
    for obj in list(bpy.context.scene.objects):
        if obj.type=='MESH':bpy.data.objects.remove(obj,do_unlink=True)
    if family=='violet':
        body=append_objects(WORK/'copper-fractured/copper-flat.blend',['CopperFracturedHost'])[0]
        bm=bmesh.new()
        bm.from_mesh(body.data)
        large=[face for face in bm.faces if face.calc_area()>.18]
        result=bmesh.ops.poke(bm,faces=large,offset=.065,center_mode='MEAN_WEIGHTED',use_relative_offset=False)
        for index,vertex in enumerate(result['verts']):vertex.co+=vertex.normal*(.045*math.sin(index*2.7))
        bm.to_mesh(body.data)
        bm.free()
        body.data.update()
        host_materials=[material('VioletHost',HOST[family]),material('VioletFracture',(.22,.18,.28)),material('WarmMineralLip',(.28,.23,.19))]
        body.data.materials.clear()
        for mat in host_materials:body.data.materials.append(mat)
        for face in body.data.polygons:
            face.material_index=1 if face.normal.z>.55 else 0
            if face.normal.z>.3 and face.center.x<-.8 and face.center.y<.1:face.material_index=2
        gems=[material('Amethyst'+str(i),c) for i,c in enumerate(((.24,.09,.36),(.36,.18,.49),(.49,.29,.60),(.29,.13,.42)))]
        models=[body,crystal('AmethystFace1',(.22,-.19,.02),.34,.46,.2,gems),crystal('AmethystFace2',(.72,.02,.10),.28,.31,1.3,gems),crystal('AmethystFace3',(.87,-.38,.10),.24,.22,2.4,gems)]
        rotation=Matrix.Rotation(.70,4,'X')
        for obj in models:
            for vertex in obj.data.vertices:
                co=vertex.co.copy()
                co.x*=1.12
                co.y*=.90
                co.z*=.94
                vertex.co=rotation@co
            obj.data.update()
    else:
        names=[family.title()+'Surface']+(['EmbeddedStone1','EmbeddedStone2','EmbeddedStone3'] if family=='ice' else [])
        models=append_objects(V1/family/(family+'.blend'),names)
        body=models[0]
        if family=='ice':
            for index,obj in enumerate(models[1:]):
                center=sum((v.co for v in obj.data.vertices),Vector())/len(obj.data.vertices)
                for vertex in obj.data.vertices:vertex.co=center+(vertex.co-center)*(1.7 if index!=1 else 1.35)
            for vertex in body.data.vertices:
                if vertex.co.x>1.48 and vertex.co.y>.12:vertex.co.x-=.24;vertex.co.y+=.10
        if family=='verdant':
            bpy.context.view_layer.objects.active=body
            mod=body.modifiers.new('Broad mineral surface','SMOOTH')
            mod.factor=.65
            mod.iterations=3
            bpy.ops.object.modifier_apply(modifier=mod.name)
            for vertex in body.data.vertices:
                x,y,z=vertex.co
                vertex.co.z-=.34*math.exp(-((x-.12)**2/.95**2+(y+.05)**2/.67**2))*max(0,min(1,(z+.20)/.85))
            body.data.update()
    for obj in bpy.context.selected_objects:obj.select_set(False)
    for obj in models:
        obj.select_set(True)
        group=obj.vertex_groups.new(name=obj.name)
        group.add(list(range(len(obj.data.vertices))),1,'REPLACE')
    bpy.context.view_layer.objects.active=body
    bpy.ops.object.join()
    body.name=family.title()+'Surface'
    body['art_proof']=True
    body['locale']={'chalk':3,'ice':7,'verdant':6,'violet':2}[family]
    body['revision']=2
    for layer in list(body.data.uv_layers):body.data.uv_layers.remove(layer)
    body.data.uv_layers.new(name='ExportUV')
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.uv.smart_project(angle_limit=1.05,island_margin=.035,scale_to_bounds=True)
    bpy.ops.object.mode_set(mode='OBJECT')
    uv=body.data.uv_layers.active
    (dest/(family+'-uv-layout.json')).write_text(json.dumps([[list(uv.data[i].uv) for i in face.loop_indices] for face in body.data.polygons]))
    original=body.data.copy()
    source_materials=list(body.data.materials)
    bm=bmesh.new()
    bm.from_mesh(body.data)
    bmesh.ops.triangulate(bm,faces=list(bm.faces))
    bmesh.ops.subdivide_edges(bm,edges=list(bm.edges),cuts=3 if family!='verdant' else 1,use_grid_fill=True)
    bm.to_mesh(body.data)
    bm.free()
    body.data.update()
    colors=body.data.color_attributes.new(name='GeologicalColor',type='FLOAT_COLOR',domain='CORNER')
    def color(co,normal,slot):
        x,y,z=co
        irregular=noise(Vector((x*6,y*13,z*9)))*.055
        if family=='violet':return tuple(source_materials[slot].diffuse_color[:3])
        if family=='ice':
            if source_materials[slot].name.startswith('EmbeddedSlate'):return (.11,.13,.17)
            if normal.z>.50:
                q=y-.22*x+irregular
                return (.50,.61,.67) if q>-.20 else (.34,.46,.55)
            return (.22,.33,.43) if normal.z>-.2 else (.17,.24,.31)
        if family=='chalk':
            band=z+.06*x-.13*y+irregular
            if normal.z>.5:
                return (.48,.44,.35) if band>.24 or band<-.10 else (.20,.24,.30)
            return (.37,.33,.25) if -.02<band<.10 else (.15,.19,.25)
        r=math.sqrt((x-.12)**2/1.35+(y+.05)**2/.64)
        r+=.04*math.sin(math.atan2(y+.05,x-.12)*5)+irregular*.55
        if z>-.03 and normal.z>-.15 and r<1.04:
            if r<.28:return (.045,.13,.075)
            if r<.46:return (.11,.29,.16)
            if r<.62:return (.27,.38,.20)
            if r<.78:return (.075,.22,.115)
            return (.22,.33,.19)
        if z>.10 and 1.03<r<1.15 and (x<-.55 or x>.80):return (.42,.31,.075)
        if z>.30 and normal.z>.30 and (x<-.70 or x>.92) and noise(Vector((x*1.8,y*2.3,z)))>-.1:return (.46,.43,.32)
        return (.15,.19,.14) if z>-.45 else (.10,.13,.12)
    for face in body.data.polygons:
        for loop in face.loop_indices:
            co=body.data.vertices[body.data.loops[loop].vertex_index].co
            colors.data[loop].color=(*color(co,face.normal,face.material_index),1)
    paint=material(family.title()+'GeologicalRegions',HOST[family])
    tree=paint.node_tree
    attr=tree.nodes.new('ShaderNodeVertexColor')
    attr.layer_name=colors.name
    tree.links.new(attr.outputs[0],tree.nodes['Principled BSDF'].inputs['Base Color'])
    body.data.materials.clear()
    body.data.materials.append(paint)
    for face in body.data.polygons:face.material_index=0
    image=bpy.data.images.new(family.title()+'ErodedColor',width=2048,height=2048,alpha=False)
    image.colorspace_settings.name='sRGB'
    image.generated_color=(*HOST[family],1)
    target=tree.nodes.new('ShaderNodeTexImage')
    target.image=image
    tree.nodes.active=target
    emission=tree.nodes.new('ShaderNodeEmission')
    tree.links.new(attr.outputs[0],emission.inputs[0])
    tree.links.new(emission.outputs[0],tree.nodes.get('Material Output').inputs[0])
    scene=bpy.context.scene
    scene.cycles.samples=1
    bpy.ops.object.bake(type='EMIT',margin=20,use_clear=False)
    image.filepath_raw=str(dest/(family+'-eroded-color.png'))
    image.file_format='PNG'
    image.save()
    image.pack()
    image.filepath='//'+family+'-eroded-color.png'
    body.data=original
    body.data.materials.clear()
    final=material(family.title()+'ReviewPaint',HOST[family])
    tex=final.node_tree.nodes.new('ShaderNodeTexImage')
    tex.image=image
    final.node_tree.links.new(tex.outputs[0],final.node_tree.nodes['Principled BSDF'].inputs['Base Color'])
    body.data.materials.append(final)
    for face in body.data.polygons:face.material_index=0
    outline(body,contour_material)
    scene.cycles.samples=32
    scene.camera.data.ortho_scale=5.0
    scene.camera.location=(2,-8,7.0)
    scene.camera.rotation_euler=(-scene.camera.location).to_track_quat('-Z','Y').to_euler()
    scene['proof_stage']=family.title()+' revision 2, unlit geological color target before UV painting.'
    bpy.ops.wm.save_as_mainfile(filepath=str(dest/(family+'-flat.blend')))
    for label,position in [('hero',(2,-8,7.0)),('reverse',(-3,7,5.8))]:
        scene.camera.location=position
        scene.camera.rotation_euler=(-scene.camera.location).to_track_quat('-Z','Y').to_euler()
        scene.render.filepath=str(dest/(family+'-eroded-'+label+'.png'))
        bpy.ops.render.render(write_still=True)
    print('PAINT_TARGET='+str(dest/(family+'-eroded-color.png')),flush=True)

for family in FAMILIES:prepare(family)
