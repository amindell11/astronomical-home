"""Prepare v1's useful Copper slabs with new mesh-aware mineral color and packed UVs.
Writes an eroded, unlit painting target and review renders in copper-selected/.
The rejected v1 and other revision-2 experiments remain unchanged.
"""
import bpy,bmesh,json,math
from pathlib import Path
from mathutils import Vector

WORK=Path(__file__).resolve().parent
OUT=WORK/'copper-selected'
OUT.mkdir(parents=True,exist_ok=True)
bpy.ops.wm.open_mainfile(filepath=str(WORK.parent/'deliverables/copper/copper.blend'))
bpy.context.preferences.filepaths.save_version=0
body=bpy.data.objects['CopperSurface']
contour=next(o for o in bpy.context.scene.objects if o.get('preview_only'))
for obj in list(bpy.context.scene.objects):
    if obj.type=='MESH' and obj not in (body,contour):bpy.data.objects.remove(obj,do_unlink=True)
for obj in (body,contour):
    for vertex in obj.data.vertices:vertex.co.y*=1.12
    obj.data.update()
contour['preview_only']=True
if 'art_proof' in contour:del contour['art_proof']
for uv in list(body.data.uv_layers):body.data.uv_layers.remove(uv)
body.data.uv_layers.new(name='ExportUV')
for obj in bpy.context.selected_objects:obj.select_set(False)
body.select_set(True)
bpy.context.view_layer.objects.active=body
bpy.ops.object.mode_set(mode='EDIT')
bpy.ops.mesh.select_all(action='SELECT')
bpy.ops.uv.smart_project(angle_limit=.9,island_margin=.035,scale_to_bounds=True)
bpy.ops.object.mode_set(mode='OBJECT')
uv=body.data.uv_layers.active
(OUT/'copper-uv-layout.json').write_text(json.dumps([[list(uv.data[i].uv) for i in face.loop_indices] for face in body.data.polygons]))

colors=[(.065,.075,.10),(.30,.105,.04),(.19,.06,.023)]
materials=[]
body.data.materials.clear()
for name,color in zip(('Iron host','Exposed copper plane','Copper fracture end'),colors):
    mat=bpy.data.materials.new(name)
    mat.use_nodes=True
    shader=mat.node_tree.nodes.get('Principled BSDF')
    shader.inputs['Base Color'].default_value=(*color,1)
    shader.inputs['Roughness'].default_value=.95
    shader.inputs['Specular IOR Level'].default_value=.04
    materials.append(mat)
    body.data.materials.append(mat)
for face in body.data.polygons:
    face.material_index=1 if face.normal.z>.58 and face.center.z>-.05 else 0
    if abs(face.normal.x)>.65 and face.center.z>.08:face.material_index=2

boundaries=[]
patina_edges=[]
bm=bmesh.new()
bm.from_mesh(body.data)
for edge in bm.edges:
    slots={face.material_index for face in edge.link_faces}
    if len(slots)>1:
        points=tuple(vertex.co.copy() for vertex in edge.verts)
        boundaries.append(points)
        mid=(points[0]+points[1])/2
        selected=(-1.45<mid.x<-.64 or .05<mid.x<.72 or 1.12<mid.x<1.65)
        if selected and -.30<mid.y<.43 and mid.z>-.07:patina_edges.append(points)
final_mesh=body.data.copy()
bmesh.ops.triangulate(bm,faces=list(bm.faces))
bmesh.ops.subdivide_edges(bm,edges=list(bm.edges),cuts=3,use_grid_fill=True)
bm.to_mesh(body.data)
bm.free()
body.data.update()

def distance(point,a,b):
    edge=b-a
    return (point-a-edge*max(0,min(1,(point-a).dot(edge)/edge.length_squared))).length

interior=body.data.attributes.new('MineralInterior','FLOAT','CORNER')
patina=body.data.attributes.new('PatinaExposure','FLOAT','CORNER')
for face in body.data.polygons:
    for loop in face.loop_indices:
        co=body.data.vertices[body.data.loops[loop].vertex_index].co
        interior.data[loop].value=min((distance(co,a,b) for a,b in boundaries),default=1)
        d=min((distance(co,a,b) for a,b in patina_edges),default=2)
        patina.data[loop].value=max(0,min(1,(.19-d)/.15))

for index,mat in enumerate(materials):
    tree=mat.node_tree
    shader=tree.nodes['Principled BSDF']
    coordinates=tree.nodes.new('ShaderNodeTexCoord')
    stretch=tree.nodes.new('ShaderNodeVectorMath')
    stretch.operation='MULTIPLY'
    stretch.inputs[1].default_value=(5,18,12)
    tree.links.new(coordinates.outputs['Object'],stretch.inputs[0])
    noise=tree.nodes.new('ShaderNodeTexNoise')
    noise.inputs['Scale'].default_value=1
    noise.inputs['Detail'].default_value=1
    tree.links.new(stretch.outputs[0],noise.inputs[0])
    base=tree.nodes.new('ShaderNodeRGB')
    base.outputs[0].default_value=(*colors[index],1)
    output=base.outputs[0]
    if index>0:
        attr=tree.nodes.new('ShaderNodeAttribute')
        attr.attribute_name='MineralInterior'
        threshold=tree.nodes.new('ShaderNodeMath')
        threshold.operation='MULTIPLY_ADD'
        threshold.inputs[1].default_value=.45
        threshold.inputs[2].default_value=-.20
        tree.links.new(noise.outputs['Fac'],threshold.inputs[0])
        subtract=tree.nodes.new('ShaderNodeMath')
        subtract.operation='SUBTRACT'
        tree.links.new(attr.outputs['Fac'],subtract.inputs[0])
        tree.links.new(threshold.outputs[0],subtract.inputs[1])
        ramp=tree.nodes.new('ShaderNodeMapRange')
        ramp.clamp=True
        ramp.inputs['From Min'].default_value=-.01
        ramp.inputs['From Max'].default_value=.012
        tree.links.new(subtract.outputs[0],ramp.inputs[0])
        mix=tree.nodes.new('ShaderNodeMixRGB')
        mix.inputs[1].default_value=(*colors[0],1)
        tree.links.new(ramp.outputs[0],mix.inputs[0])
        tree.links.new(output,mix.inputs[2])
        output=mix.outputs[0]
    attr=tree.nodes.new('ShaderNodeAttribute')
    attr.attribute_name='PatinaExposure'
    subtract=tree.nodes.new('ShaderNodeMath')
    subtract.operation='SUBTRACT'
    tree.links.new(attr.outputs['Fac'],subtract.inputs[0])
    tree.links.new(noise.outputs['Fac'],subtract.inputs[1])
    ramp=tree.nodes.new('ShaderNodeMapRange')
    ramp.clamp=True
    ramp.inputs['From Min'].default_value=-.08
    ramp.inputs['From Max'].default_value=.12
    tree.links.new(subtract.outputs[0],ramp.inputs[0])
    mix=tree.nodes.new('ShaderNodeMixRGB')
    tree.links.new(ramp.outputs[0],mix.inputs[0])
    tree.links.new(output,mix.inputs[1])
    mix.inputs[2].default_value=(.055,.22,.19,1)
    tree.links.new(mix.outputs[0],shader.inputs['Base Color'])

scene=bpy.context.scene
scene.render.resolution_x=900
scene.render.resolution_y=700
scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.28,.30,.35,1)
scene.world.node_tree.nodes['Background'].inputs[1].default_value=.65
bpy.data.objects['PreviewFill'].data.energy=500
bpy.data.objects['PreviewFill'].data.color=(.92,.95,1)
bpy.data.objects['PreviewKey'].data.energy=850
bpy.data.objects['PreviewKey'].data.size=3
scene.view_settings.exposure=-.20
scene.camera.data.ortho_scale=4.9
scene.camera.location=(2,-8,6.8)
scene.camera.rotation_euler=(-scene.camera.location).to_track_quat('-Z','Y').to_euler()
scene['proof_stage']='Copper slabs with eroded, geometry-aware unlit mineral zones. No decorative drawing mesh.'
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'copper-region-source.blend'))

image=bpy.data.images.new('CopperErodedColor',width=2048,height=2048,alpha=False)
image.colorspace_settings.name='sRGB'
for mat in materials:
    tree=mat.node_tree
    shader=tree.nodes['Principled BSDF']
    emission=tree.nodes.new('ShaderNodeEmission')
    tree.links.new(shader.inputs['Base Color'].links[0].from_socket,emission.inputs[0])
    output=next(node for node in tree.nodes if node.type=='OUTPUT_MATERIAL')
    tree.links.new(emission.outputs[0],output.inputs[0])
    target=tree.nodes.new('ShaderNodeTexImage')
    target.image=image
    tree.nodes.active=target
scene.cycles.samples=1
bpy.ops.object.bake(type='EMIT',margin=20,use_clear=True)
image.filepath_raw=str(OUT/'copper-eroded-color.png')
image.file_format='PNG'
image.save()
image.pack()
image.filepath='//copper-eroded-color.png'
body.data=final_mesh
body.data.materials.clear()
mat=bpy.data.materials.new('Copper review paint')
mat.use_nodes=True
shader=mat.node_tree.nodes['Principled BSDF']
shader.inputs['Roughness'].default_value=.95
shader.inputs['Specular IOR Level'].default_value=.04
texture=mat.node_tree.nodes.new('ShaderNodeTexImage')
texture.image=image
mat.node_tree.links.new(texture.outputs['Color'],shader.inputs['Base Color'])
body.data.materials.append(mat)
for face in body.data.polygons:face.material_index=0
scene.cycles.samples=48
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'copper-flat.blend'))
for label,position in [('hero',(2,-8,6.8)),('reverse',(-3,7,5.8))]:
    scene.camera.location=position
    scene.camera.rotation_euler=(-scene.camera.location).to_track_quat('-Z','Y').to_euler()
    scene.render.filepath=str(OUT/('copper-eroded-'+label+'.png'))
    bpy.ops.render.render(write_still=True)
print('COPPER_PAINT_TARGET='+str(OUT/'copper-eroded-color.png'),flush=True)
