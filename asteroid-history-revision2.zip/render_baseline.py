"""Render the current field asteroid under revision 2's review light and camera."""
import bpy,sys
from pathlib import Path

WORK=Path(__file__).resolve().parent
sys.path.insert(0,str(WORK.parent))
import build_asteroids as art
bpy.ops.wm.open_mainfile(filepath=str(WORK/'copper-selected/copper.blend'))
for obj in list(bpy.context.scene.objects):
    if obj.type=='MESH':bpy.data.objects.remove(obj,do_unlink=True)
surface,drawing=art.load_base(4,'baseline')
image=next(i for i in bpy.data.images if i.name.startswith('AsteroidBrushAlbedo'))
normal=next(i for i in bpy.data.images if i.name.startswith('Asteroid4Normal'))
surface.data.materials.clear()
surface.data.materials.append(art.material('Current field paint',(.5,.5,.5),image,normal))
drawing.data.materials.clear()
drawing.data.materials.append(art.material('Current graphite',(.012,.014,.022)))
for face in drawing.data.polygons:face.material_index=0
dest=WORK/'deliverables/baseline'
dest.mkdir(parents=True,exist_ok=True)
bpy.context.scene.render.filepath=str(dest/'baseline-hero.png')
bpy.ops.render.render(write_still=True)
print('BASELINE='+str(dest/'baseline-hero.png'),flush=True)
