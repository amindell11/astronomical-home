"""Apply the supplied painted atlas to frozen Copper UVs and render three views.
Preserves the input image and the earlier procedural proof unchanged.
"""
import bpy,shutil
from pathlib import Path

OUT=Path(__file__).resolve().parent/'copper'
bpy.ops.wm.open_mainfile(filepath=str(OUT/'copper.blend'))
bpy.context.preferences.filepaths.save_version=0
dest=OUT/'copper-painted-uv-source.png'
shutil.copy2(Path(r'D:/amind/scratch/asteroid-locale-concepts-20261106/revision2/copper-painted-uv.png'),dest)
image=bpy.data.images.load(str(dest),check_existing=False)
image.name='CopperPaintedUV'
image.pack()
image.filepath='//'+dest.name
body=bpy.data.objects['CopperGeology']
mat=body.data.materials[0]
texture=next(node for node in mat.node_tree.nodes if node.type=='TEX_IMAGE')
texture.image=image
scene=bpy.context.scene
scene.cycles.samples=48
scene['proof_stage']='Copper revision 2, painted UV-map experiment on the frozen mesh and UV layout.'
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'copper-painted-map.blend'))
for label,position in [('hero',(2,-8,5.8)),('reverse',(-3,7,5.2)),('side',(5,-7,2.5))]:
    scene.camera.location=position
    scene.camera.rotation_euler=(-scene.camera.location).to_track_quat('-Z','Y').to_euler()
    scene.render.filepath=str(OUT/('copper-painted-map-'+label+'.png'))
    bpy.ops.render.render(write_still=True)
print('PAINTED_MAP_REVIEW='+str(OUT),flush=True)
