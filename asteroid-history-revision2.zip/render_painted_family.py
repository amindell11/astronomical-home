"""Apply one approved UV painting without changing UVs, then export and render.
Required arguments: --family NAME --paint PATH. --preview-only skips exports.
Optional --diagnose saves a
shell-free frame before enabling silhouette-only Freestyle for review renders.
Exit 0 writes the current BLEND, FBX, GLB, PNG albedo and three PNG views.
"""
import bpy,bmesh,shutil,sys
from pathlib import Path
from mathutils import Vector,Matrix
from mathutils.bvhtree import BVHTree

args=sys.argv[sys.argv.index('--')+1:]
family=args[args.index('--family')+1]
source=Path(args[args.index('--paint')+1])
OUT=Path(__file__).resolve().parent/(family+'-selected')
bpy.ops.wm.open_mainfile(filepath=str(OUT/(family+'-flat.blend')))
bpy.context.preferences.filepaths.save_version=0
body=next(obj for obj in bpy.context.scene.objects if obj.get('art_proof') and not obj.get('preview_only'))
for obj in list(bpy.context.scene.objects):
    if obj.get('preview_only'):bpy.data.objects.remove(obj,do_unlink=True)
if family=='ice':
    groups={body.vertex_groups['EmbeddedStone1'].index:.22,body.vertex_groups['EmbeddedStone2'].index:.16}
    for vertex in body.data.vertices:
        for membership in vertex.groups:
            if membership.group in groups:vertex.co.z-=groups[membership.group]
    host_group=body.vertex_groups['IceSurface'].index
    host_vertices={v.index for v in body.data.vertices if any(m.group==host_group and m.weight>.5 for m in v.groups)}
    host_faces=[list(face.vertices) for face in body.data.polygons if all(index in host_vertices for index in face.vertices)]
    tree=BVHTree.FromPolygons([v.co for v in body.data.vertices],host_faces)
    front_group=body.vertex_groups['EmbeddedStone3'].index
    front=[v for v in body.data.vertices if any(m.group==front_group and m.weight>.5 for m in v.groups)]
    center=sum((v.co for v in front),Vector())/len(front)
    hit,normal,_,_=tree.ray_cast(Vector((center.x,-3,center.z)),Vector((0,1,0)))
    assert hit is not None,'Front inclusion ray missed the ice host'
    radius=max(abs((v.co-center).dot(normal)) for v in front)*.30
    embedded=hit-normal*(radius*.80)
    for vertex in front:
        delta=vertex.co-center
        along=delta.dot(normal)
        vertex.co=embedded+delta-normal*along+normal*along*.30
    body.data.update()
if family=='violet':
    shifts={body.vertex_groups['AmethystFace1'].index:(0,.300,.062),body.vertex_groups['AmethystFace2'].index:(-.17,.258,-.020),body.vertex_groups['AmethystFace3'].index:(-.15,.387,.075)}
    for vertex in body.data.vertices:
        for membership in vertex.groups:
            if membership.group in shifts:
                shift=shifts[membership.group]
                vertex.co.x+=shift[0]
                vertex.co.y+=shift[1]
                vertex.co.z+=shift[2]
    body.data.update()
    gem_groups={body.vertex_groups[name].index for name in ('AmethystFace1','AmethystFace2','AmethystFace3')}
    for obj in bpy.context.selected_objects:obj.select_set(False)
    body.select_set(True)
    bpy.context.view_layer.objects.active=body
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='DESELECT')
    bpy.ops.object.mode_set(mode='OBJECT')
    for vertex in body.data.vertices:vertex.select=any(m.group in gem_groups and m.weight>.5 for m in vertex.groups)
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.separate(type='SELECTED')
    bpy.ops.object.mode_set(mode='OBJECT')
    gems=next(obj for obj in bpy.context.scene.objects if obj.type=='MESH' and obj!=body)
    gems.name='Embedded amethyst exposure'
    for obj in bpy.context.selected_objects:obj.select_set(False)
    body.select_set(True)
    bpy.context.view_layer.objects.active=body
    chip_mat=body.data.materials[0].copy()
    chip_mat.name='Violet chip assignment'
    body.data.materials.append(chip_mat)
    rotation=Matrix.Rotation(.70,4,'X')
    cutters=[
        [(-.38,.18,.38),(-.38,.78,1.25),(-.38,.10,1.25),(.18,.23,.44),(.18,.83,1.28),(.18,.12,1.28)],
        [(.65,.40,.50),(.65,.98,1.30),(.65,.20,1.30),(1.05,.44,.56),(1.05,1.02,1.32),(1.05,.22,1.32)],
        [(-1.05,.10,1.20),(-.20,.10,1.20),(-.45,-.70,.40),(-.65,.00,.30)]
    ]
    for index,points in enumerate(cutters):
        mesh=bpy.data.meshes.new('Violet rim chip')
        vertices=[rotation@Vector((x*1.12,y*.90,z*.94)) for x,y,z in points]
        mesh.from_pydata(vertices,[],[])
        bm=bmesh.new()
        bm.from_mesh(mesh)
        bmesh.ops.convex_hull(bm,input=list(bm.verts))
        bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces))
        bm.to_mesh(mesh)
        bm.free()
        mesh.materials.append(body.data.materials[0])
        mesh.materials.append(chip_mat)
        for face in mesh.polygons:face.material_index=1
        cutter=bpy.data.objects.new('Violet rim chip '+str(index),mesh)
        bpy.context.scene.collection.objects.link(cutter)
        bpy.context.view_layer.objects.active=body
        mod=body.modifiers.new('Broken exposed rim','BOOLEAN')
        mod.operation='DIFFERENCE'
        mod.solver='EXACT'
        mod.object=cutter
        bpy.ops.object.modifier_apply(modifier=mod.name)
        bpy.data.objects.remove(cutter,do_unlink=True)
    uv=body.data.uv_layers.active
    for face in body.data.polygons:
        if face.material_index!=1:continue
        axis=max(range(3),key=lambda i:abs(face.normal[i]))
        axes=[i for i in range(3) if i!=axis]
        points=[body.data.vertices[body.data.loops[loop].vertex_index].co for loop in face.loop_indices]
        low=[min(p[a] for p in points) for a in axes]
        high=[max(p[a] for p in points) for a in axes]
        for loop,point in zip(face.loop_indices,points):
            uv.data[loop].uv=(.18+.10*(point[axes[0]]-low[0])/(high[0]-low[0]),.21+.10*(point[axes[1]]-low[1])/(high[1]-low[1]))
        face.material_index=0
    body.data.materials.pop(index=1)
    gems.select_set(True)
    body.select_set(True)
    bpy.context.view_layer.objects.active=body
    bpy.ops.object.join()
    body.data.name='VioletSurfaceMesh'
for attr in list(body.data.color_attributes):body.data.color_attributes.remove(attr)
dest=OUT/(family+'-albedo.png')
shutil.copy2(source,dest)
image=bpy.data.images.load(str(dest),check_existing=False)
image.name=family.title()+'PaintedAlbedo'
image.pack()
image.filepath='//'+dest.name
mat=body.data.materials[0]
tex=next(node for node in mat.node_tree.nodes if node.type=='TEX_IMAGE')
tex.image=image
for material in list(bpy.data.materials):
    if material!=mat:bpy.data.materials.remove(material,do_unlink=True)
for old_image in list(bpy.data.images):
    if old_image!=image and old_image.source=='FILE':bpy.data.images.remove(old_image,do_unlink=True)
for mesh in list(bpy.data.meshes):
    if mesh.users==0:bpy.data.meshes.remove(mesh)
scene=bpy.context.scene
scene.cycles.samples=48
scene.render.resolution_x=900
scene.render.resolution_y=700
scene.camera.data.ortho_scale=5.0
hero=(3,-8,8.8) if family!='violet' else (2,-8,6.3)
scene.camera.location=hero
scene.camera.rotation_euler=(-scene.camera.location).to_track_quat('-Z','Y').to_euler()
scene.render.use_freestyle=False
if '--diagnose' in args:
    scene.render.filepath=str(OUT/(family+'-no-outline.png'))
    bpy.ops.render.render(write_still=True)
scene.render.use_freestyle=True
settings=bpy.context.view_layer.freestyle_settings
for line_set in list(settings.linesets):settings.linesets.remove(line_set)
line_set=settings.linesets.new('Visible outer silhouette')
line_set.select_silhouette=False
line_set.select_border=False
line_set.select_crease=False
line_set.select_edge_mark=False
line_set.select_material_boundary=False
line_set.select_contour=False
line_set.select_external_contour=True
line_set.select_suggestive_contour=False
line_set.select_ridge_valley=False
line_set.linestyle.color=(.008,.009,.013)
line_set.linestyle.thickness=1.6
scene['proof_stage']='Locale asteroid art proof with UV-painted geological color. Silhouette ink is preview-only Freestyle.'
scene.render.filepath='//'+family+'-hero.png'
for obj in bpy.context.selected_objects:obj.select_set(False)
body.select_set(True)
bpy.context.view_layer.objects.active=body
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/(family+'.blend')))
if '--preview-only' not in args:
    bpy.ops.export_scene.fbx(filepath=str(OUT/(family+'.fbx')),use_selection=True,object_types={'MESH'},bake_anim=False,path_mode='COPY',embed_textures=True,axis_forward='-Z',axis_up='Y')
    bpy.ops.export_scene.gltf(filepath=str(OUT/(family+'.glb')),export_format='GLB',use_selection=True,export_yup=True)
for label,position in [('hero',hero),('reverse',(-4,7,6.2)),('side',(5,-8,3))]:
    scene.camera.location=position
    scene.camera.rotation_euler=(-scene.camera.location).to_track_quat('-Z','Y').to_euler()
    scene.render.filepath=str(OUT/(family+'-'+label+'.png'))
    bpy.ops.render.render(write_still=True)
print('PAINTED_FAMILY='+str(OUT),flush=True)
