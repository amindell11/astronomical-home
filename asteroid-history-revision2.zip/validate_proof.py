"""Reopen selected sources, inspect embedded exports and render every reimport.
Optional --family NAME limits a pass; validation.json reports PASS only when all
five current source/albedo hashes have verified records. Any failed check exits 1.
"""
import bpy,json,math,hashlib,struct,sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent/'deliverables'
ALL=('copper','violet','chalk','verdant','ice')
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
families=[args[args.index('--family')+1]] if '--family' in args else ALL
report_path=ROOT/'validation.json'
previous=json.loads(report_path.read_text()) if report_path.exists() else {'families':[]}
records={item['family']:item for item in previous['families']}
checks=ROOT/'reimport-checks'
checks.mkdir(exist_ok=True)

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def inspect_mesh(obj):
    assert obj.type=='MESH'
    mesh=obj.data
    assert len(mesh.vertices)>0 and len(mesh.polygons)>0,obj.name
    assert all(math.isfinite(c) for vertex in mesh.vertices for c in vertex.co),obj.name
    assert len(mesh.uv_layers)==1,obj.name
    uv=mesh.uv_layers.active
    assert all(math.isfinite(c) for item in uv.data for c in item.uv),obj.name
    assert max(item.uv.x for item in uv.data)-min(item.uv.x for item in uv.data)>.5,obj.name
    assert not mesh.color_attributes,obj.name
    mesh.calc_loop_triangles()
    return {'object':obj.name,'vertices':len(mesh.vertices),'triangles':len(mesh.loop_triangles),'materials':len(mesh.materials),'uv_layers':len(mesh.uv_layers),'dimensions':list(obj.dimensions)}

def direct_color(obj):
    assert len(obj.data.materials)==1,obj.name
    mat=obj.data.materials[0]
    shader=mat.node_tree.nodes.get('Principled BSDF')
    assert shader and shader.inputs['Base Color'].is_linked,mat.name
    texture=shader.inputs['Base Color'].links[0].from_node
    assert texture.type=='TEX_IMAGE' and texture.image,mat.name
    assert texture.image.size[0]>0,texture.image.name
    return texture.image

def glb_data(path):
    raw=path.read_bytes()
    assert raw[:4]==b'glTF'
    count=struct.unpack('<I',raw[12:16])[0]
    return json.loads(raw[20:20+count])

for family in families:
    folder=ROOT/family
    source=folder/(family+'.blend')
    albedo=folder/(family+'-albedo.png')
    bpy.ops.wm.open_mainfile(filepath=str(source))
    models=[obj for obj in bpy.context.scene.objects if obj.type=='MESH']
    assert len(models)==1,(family,[obj.name for obj in models])
    body=models[0]
    assert body.get('art_proof') and not body.get('preview_only')
    stats=inspect_mesh(body)
    image=direct_color(body)
    assert image.packed_file and image.filepath=='//'+albedo.name,image.filepath
    assert Path(bpy.path.abspath(image.filepath)).is_file()
    assert len([i for i in bpy.data.images if i.source=='FILE'])==1
    image_size=list(image.size)
    components={group.name:sum(any(m.group==group.index and m.weight>.5 for m in vertex.groups) for vertex in body.data.vertices) for group in body.vertex_groups}
    for required in (('EmbeddedStone1','EmbeddedStone2','EmbeddedStone3') if family=='ice' else ('AmethystFace1','AmethystFace2','AmethystFace3') if family=='violet' else ()):
        assert components[required]>0,(family,required)
    record={'family':family,'locale':{'copper':1,'violet':2,'chalk':3,'verdant':6,'ice':7}[family],'source_reopened':True,'source':stats,'component_vertex_groups':components,'albedo_size':image_size,'packed_albedo':True,'direct_image_material':True,'source_sha256':digest(source),'albedo_sha256':digest(albedo),'exports':{}}
    expected_name=body.name
    for extension in ('glb','fbx'):
        path=folder/(family+'.'+extension)
        assert path.is_file() and path.stat().st_size>0
        if extension=='glb':
            data=glb_data(path)
            assert 'cameras' not in data
            assert 'KHR_lights_punctual' not in data.get('extensions',{})
            assert {node['name'] for node in data['nodes']}=={expected_name}
            assert len(data['images'])==1 and 'bufferView' in data['images'][0]
            assert 'baseColorTexture' in data['materials'][0]['pbrMetallicRoughness']
            for mesh in data['meshes']:
                for primitive in mesh['primitives']:assert 'COLOR_0' not in primitive['attributes']
        bpy.ops.wm.open_mainfile(filepath=str(source))
        for obj in list(bpy.context.scene.objects):
            if obj.type=='MESH':bpy.data.objects.remove(obj,do_unlink=True)
        before=set(bpy.context.scene.objects)
        if extension=='glb':bpy.ops.import_scene.gltf(filepath=str(path))
        else:bpy.ops.import_scene.fbx(filepath=str(path))
        imported=[obj for obj in bpy.context.scene.objects if obj not in before]
        assert len(imported)==1 and imported[0].name==expected_name,(family,extension,[obj.name for obj in imported])
        part=imported[0]
        imported_stats=inspect_mesh(part)
        assert imported_stats['triangles']==stats['triangles'],(family,extension,'triangle count')
        imported_image=direct_color(part)
        assert list(imported_image.size)==image_size,(family,extension,'texture dimensions')
        scene=bpy.context.scene
        scene.render.filepath=str(checks/(family+'-'+extension+'.png'))
        bpy.ops.render.render(write_still=True)
        record['exports'][extension]={'reimported':True,'structure_verified':True,'object_count':1,'triangles':imported_stats['triangles'],'albedo_size':list(imported_image.size),'reimport_render':'reimport-checks/'+family+'-'+extension+'.png','bytes':path.stat().st_size,'sha256':digest(path)}
    (folder/'manifest.json').write_text(json.dumps(record,indent=2))
    records[family]=record
    print('VERIFIED='+family,flush=True)
    current=all(name in records and records[name]['source_sha256']==digest(ROOT/name/(name+'.blend')) and records[name]['albedo_sha256']==digest(ROOT/name/(name+'-albedo.png')) for name in ALL)
    report={'verdict':'PASS' if current else 'IN_PROGRESS','blender':bpy.app.version_string,'families':[records[name] for name in ALL if name in records],'scope':'Blender art proof. No Unity integration, collision, fragmentation, volume or covering-sphere data.','preview':'Silhouette-only Freestyle in BLEND; no contour geometry, cameras or lights in exports.'}
    report_path.write_text(json.dumps(report,indent=2))
print('VALIDATION='+str(report_path),flush=True)
