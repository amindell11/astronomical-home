"""Apply a supplied UV painting and render the reference-layout art proof.
Arguments: --family NAME --source BLEND --paint PNG.
"""
import bpy,bmesh,sys,shutil,math
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree

args=sys.argv[sys.argv.index('--')+1:]
family=args[args.index('--family')+1]
source=Path(args[args.index('--source')+1])
paint=Path(args[args.index('--paint')+1])
out=source.parent
bpy.ops.wm.open_mainfile(filepath=str(source))
bpy.context.preferences.filepaths.save_version=0
body=bpy.data.objects[family.title()+'Surface']
if family=='copper':
    for index,amount in [(19,.06),(33,.26),(47,.18),(35,.15),(49,.09)]:
        body.data.vertices[index].co+=Vector((0,-.8,.6))*amount
    body.data.update()
if family in ('chalk','ice'):
    changes={
        'chalk':{9:(.13,.02,.03),19:(.08,0,.06),20:(-.12,-.03,.04),30:(.06,.04,-.02),49:(-.12,.03,0)},
        'ice':{9:(-.12,-.05,.01),19:(.04,-.03,.03),29:(-.12,.03,-.03),39:(.08,-.03,.02),20:(.08,-.06,.01),30:(-.04,.01,-.02)}
    }[family]
    for index,(x,y,depth) in changes.items():
        shift=Vector((x,0,0))+Vector((0,.6,.8))*y+Vector((0,-.8,.6))*depth
        body.data.vertices[index].co+=shift
        body.data.vertices[index+50].co+=shift*.75
    body.data.update()
if family=='violet':
    shifts={body.vertex_groups['AmethystFace'+str(i)].index:(up,burial) for i,up,burial in [(1,.09,-.02),(2,.15,-.03),(3,.11,-.015),(4,.10,-.02)]}
    for vertex in body.data.vertices:
        for membership in vertex.groups:
            if membership.group in shifts:
                up,burial=shifts[membership.group]
                vertex.co+=Vector((0,.6,.8))*up+Vector((0,-.8,.6))*burial
    body.data.update()
ledge_segments=[]
if family=='chalk':
    old=body.data
    points=[vertex.co.copy() for vertex in old.vertices]
    polygons=[list(face.vertices) for face in old.polygons]
    face_slots=[face.material_index for face in old.polygons]
    old_uv=old.uv_layers.active
    uv_faces=[[old_uv.data[i].uv.copy() for i in face.loop_indices] for face in old.polygons]
    replacements={}
    for index,depth,down in [(24,.25,.07),(25,.32,.08),(26,.20,.06),(27,.28,.07),(28,.16,.04)]:
        replacements[index]=len(points)
        points.append(points[index]+Vector((0,-.8,.6))*depth-Vector((0,.6,.8))*down)
    for index in range(18,36):polygons[index]=[replacements.get(v,v) for v in polygons[index]]
    sampled=uv_faces[46]
    u0,u1,u2=sampled
    wall_uv=[u0*.8+u1*.2,u0*.2+u1*.8,u0*.2+u1*.6+u2*.2,u0*.6+u1*.2+u2*.2]
    for a,b in zip(range(23,29),range(24,30)):
        upper_a,upper_b=replacements.get(a,a),replacements.get(b,b)
        face=[a,upper_a,upper_b,b]
        face=list(dict.fromkeys(face))
        polygons.append(face);face_slots.append(0);uv_faces.append(wall_uv[:len(face)])
        if a in (24,25,27):ledge_segments.append((points[upper_a],points[upper_b]))
    mesh=bpy.data.meshes.new('ChalkSurfaceMesh')
    mesh.from_pydata(points,[],polygons)
    for mat in old.materials:mesh.materials.append(mat)
    mesh.uv_layers.new(name='PaintUV')
    for face,coords,slot in zip(mesh.polygons,uv_faces,face_slots):
        face.material_index=slot
        for loop,uv in zip(face.loop_indices,coords):mesh.uv_layers.active.data[loop].uv=uv
    bm=bmesh.new();bm.from_mesh(mesh);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(mesh);bm.free()
    body.data=mesh
if family=='verdant':
    for top,bottom,dx,dy in [(149,158,-3.6,-13.2),(166,174,-.6,-4.05)]:
        shift=Vector((dx/72.5,0,0))-Vector((0,.6,.8))*(dy/72.5)
        body.data.vertices[top].co+=shift
        body.data.vertices[bottom].co+=shift
    host_faces=[list(face.vertices) for face in body.data.polygons if all(index<142 for index in face.vertices)]
    host=BVHTree.FromPolygons([vertex.co for vertex in body.data.vertices],host_faces)
    direction=Vector((0,-.8,.6))
    for part,(start,count) in enumerate(((142,9),(160,8))):
        group=body.vertex_groups.new(name='CreamRind'+str(part+1))
        group.add(list(range(start,start+2*count)),1,'REPLACE')
        for index in range(count):
            vertex=body.data.vertices[start+index]
            hit,normal,_,_=host.ray_cast(vertex.co+direction*3,-direction)
            vertex.co=hit+direction*.10
            body.data.vertices[start+count+index].co=hit-direction*.045
    body.data.update()
drawing=bpy.data.objects[family.title()+'Drawing']
tree=BVHTree.FromObject(body,bpy.context.evaluated_depsgraph_get())
for start in range(0,len(drawing.data.vertices),30):
    section=list(drawing.data.vertices)[start:start+30]
    if len(section)!=30:raise RuntimeError('Unexpected structural stroke sampling')
    center=(section[0].co+section[1].co+section[-2].co+section[-1].co)*.25
    projected=[]
    for step in range(15):
        point=(section[step*2].co+section[step*2+1].co)*.5
        hit,normal,_,_=tree.find_nearest(center+(point-center)*.82)
        projected.append((hit,normal))
    for step,(hit,normal) in enumerate(projected):
        tangent=(projected[min(step+1,14)][0]-projected[max(step-1,0)][0]).normalized()
        lateral=tangent.cross(normal).normalized()
        width=(.0085*math.sin(math.pi*step/14)**.6+.0008)*.82
        for side,sign in enumerate((-1,1)):
            section[step*2+side].co=hit+normal*.004+lateral*width*sign
drawing.data.update()
if ledge_segments:
    points=[vertex.co.copy() for vertex in drawing.data.vertices]
    faces=[list(face.vertices) for face in drawing.data.polygons]
    for a,b in ledge_segments:
        a,b=a.lerp(b,.12),a.lerp(b,.84)
        tangent=(b-a).normalized()
        start=len(points)
        for step in range(15):
            t=step/14
            hit,normal,_,_=tree.find_nearest(a.lerp(b,t))
            lateral=tangent.cross(normal).normalized()
            width=.0085*math.sin(math.pi*t)**.6+.0008
            points.extend((hit+normal*.004-lateral*width,hit+normal*.004+lateral*width))
            if step:faces.append((start+2*step-2,start+2*step-1,start+2*step+1,start+2*step))
    mesh=bpy.data.meshes.new('ChalkDrawingMesh');mesh.from_pydata(points,[],faces)
    for mat in drawing.data.materials:mesh.materials.append(mat)
    drawing.data=mesh
dest=out/(family+'-albedo.png')
shutil.copy2(paint,dest)
image=bpy.data.images.load(str(dest),check_existing=False)
image.pack()
image.filepath='//'+dest.name
material=bpy.data.materials.new(family.title()+' painted minerals')
material.use_nodes=True
shader=material.node_tree.nodes['Principled BSDF']
shader.inputs['Roughness'].default_value=.97
shader.inputs['Specular IOR Level'].default_value=.02
tex=material.node_tree.nodes.new('ShaderNodeTexImage')
tex.image=image
material.node_tree.links.new(tex.outputs['Color'],shader.inputs['Base Color'])
body.data.materials.clear()
body.data.materials.append(material)
for face in body.data.polygons:face.material_index=0
scene=bpy.context.scene
scene.cycles.samples=48
hero=scene.camera.location.copy()
scene.render.filepath='//'+family+'-painted-hero.png'
bpy.ops.wm.save_as_mainfile(filepath=str(out/(family+'-painted.blend')))
for label,position in [('hero',hero),('reverse',Vector((3,8,5))),('side',Vector((7,-6,4)))]:
    scene.camera.location=position
    scene.camera.rotation_euler=(-scene.camera.location).to_track_quat('-Z','Y').to_euler()
    scene.render.filepath=str(out/(family+'-painted-'+label+'.png'))
    bpy.ops.render.render(write_still=True)
scene.camera.location=hero
scene.camera.rotation_euler=(-scene.camera.location).to_track_quat('-Z','Y').to_euler()
scene.render.resolution_x=160
scene.render.resolution_y=128
scene.camera.data.ortho_scale=5.14
line=bpy.context.view_layer.freestyle_settings.linesets[0]
line.linestyle.thickness=2.5
noise=line.linestyle.thickness_modifiers[0]
noise.amplitude=.45
noise.period=12
scene.render.filepath=str(out/(family+'-painted-native.png'))
bpy.ops.render.render(write_still=True)
print('PAINTED='+str(out),flush=True)
