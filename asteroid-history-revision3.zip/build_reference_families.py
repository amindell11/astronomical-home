"""Build each remaining locale from its own concept fracture layout.
Argument --family selects a single editable geometry proof.
"""
import bpy,bmesh,math,sys
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree

args=sys.argv[sys.argv.index('--')+1:]
family=args[args.index('--family')+1]
OUT=Path(__file__).resolve().parent/(family+'-reference')
OUT.mkdir(parents=True,exist_ok=True)
bpy.ops.wm.open_mainfile(filepath='D:/amind/scratch/asteroid-locale-concepts-20261106/art-proof-revision2/copper/copper.blend')
bpy.context.preferences.filepaths.save_version=0
for obj in list(bpy.context.scene.objects):
    if obj.type=='MESH':bpy.data.objects.remove(obj,do_unlink=True)
D=Vector((0,-.8,.6))
U=Vector((0,.6,.8))
R=Vector((1,0,0))

CONFIG={
'chalk':{
 'center':(560,569),'scale':82,'thickness':.64,
 'rows':[
  [(418,540),(449,523),(486,512),(527,503),(562,507),(594,498),(626,492),(657,494),(687,509),(687,525)],
  [(408,564),(442,549),(478,541),(516,543),(553,530),(594,527),(632,516),(667,522),(702,531),(720,527)],
  [(397,597),(430,579),(469,582),(507,578),(548,573),(585,559),(621,558),(659,549),(696,550),(725,549)],
  [(414,620),(448,606),(488,606),(527,607),(566,598),(602,585),(636,583),(668,572),(699,570),(720,567)],
  [(445,638),(478,642),(518,638),(555,647),(590,641),(624,628),(657,620),(685,601),(702,587),(712,580)]],
 'depth':[
  [0,.03,.12,.08,.04,.11,.13,.08,0,-.04],
  [.23,.35,.45,.44,.37,.30,.36,.42,.13,.01],
  [.12,.35,.38,.40,.36,.34,.30,.25,.15,0],
  [-.10,0,.10,.12,.12,.03,.15,.10,0,-.10],
  [.05,.10,.10,.04,0,0,-.03,-.05,-.10,-.10]],
 'paint':[[2,2,0,1,0,2,2,2,0],[2,2,2,2,0,0,0,1,2],[0,0,1,0,0,0,1,0,0],[0,1,2,2,0,2,2,2,0]],
 'colors':[('Slate',(93,98,116)),('Slate pale',(121,124,135)),('Chalk cream',(197,180,148))],
 'ink':[[10,11,12],[14,15,16],[22,23,24],[25,26,27],[31,32],[34,35],[37,38]],
},
'ice':{
 'center':(555,916),'scale':85,'thickness':.83,
 'rows':[
  [(421,882),(449,870),(485,851),(520,845),(551,845),(578,856),(614,843),(655,838),(692,841),(720,858)],
  [(402,911),(440,892),(477,883),(515,867),(550,868),(585,878),(622,867),(660,866),(694,869),(725,877)],
  [(383,934),(422,924),(463,912),(505,905),(543,899),(584,910),(619,908),(658,901),(685,900),(708,904)],
  [(395,964),(432,965),(468,947),(510,941),(548,947),(581,938),(616,940),(650,929),(679,922),(696,940)],
  [(428,988),(467,995),(504,983),(542,975),(575,976),(609,971),(637,969),(659,969),(679,959),(690,948)]],
 'depth':[
  [.13,.25,.18,.04,.07,-.03,.08,.17,.28,.04],
  [.18,.43,.45,.23,.21,.11,.17,.12,.30,.08],
  [.13,.31,.34,.39,.30,.31,.49,.44,.22,.11],
  [.10,.29,.30,.48,.49,.27,.22,.28,.23,.12],
  [.10,.21,.17,.16,.18,.11,.07,.12,.09,.06]],
 'paint':[[3,4,0,1,0,1,0,3,4],[0,3,1,0,1,0,2,1,0],[1,0,2,0,1,0,3,1,2],[0,1,0,4,0,2,1,0,1]],
 'colors':[('Milky ice',(169,199,220)),('Ice pale',(211,224,228)),('Ice blue',(111,155,188)),('Embedded slate',(85,88,103)),('Embedded stone',(129,119,107))],
 'ink':[[11,21],[13,14],[16,26],[23,33],[28,38],[31,32],[35,36]],
},
'violet':{
 'center':(550,398),'scale':71,'thickness':.86,
 'rows':[
  [(409,398),(423,372),(456,348),(491,331),(523,319),(551,317),(580,331),(612,325),(641,337),(646,359)],
  [(421,412),(447,394),(479,380),(515,374),(540,353),(576,362),(604,350),(634,361),(657,366),(672,384)],
  [(435,433),(459,422),(488,410),(515,395),(548,389),(575,374),(601,381),(629,391),(648,396),(667,402)],
  [(450,462),(476,443),(505,439),(534,426),(563,418),(591,424),(619,416),(647,420),(669,419),(685,425)],
  [(471,479),(502,474),(531,464),(559,461),(586,456),(612,451),(641,445),(659,435),(673,430),(680,425)]],
 'depth':[
  [0,.10,.17,.15,.18,.10,.04,.08,.14,.07],
  [.16,.28,.33,.43,.45,.40,.35,.30,.04,-.22],
  [.18,.28,.10,-.29,-.39,-.35,-.30,-.28,-.12,-.32],
  [.14,.30,.25,-.10,-.24,-.19,-.04,.19,.08,-.12],
  [.12,.24,.28,.33,.29,.28,.22,.19,.14,.10]],
 'paint':[[1,0,0,1,0,0,1,0,0],[0,1,1,0,2,2,2,0,2],[0,0,2,2,2,2,2,0,2],[0,1,0,0,1,0,0,1,0]],
 'colors':[('Violet slate',(86,80,109)),('Slate exposed',(115,103,132)),('Cavity host',(53,46,78)),('Amethyst',(146,84,186)),('Amethyst light',(182,125,222)),('Amethyst dark',(104,63,153)),('Ochre inclusion',(159,133,105))],
 'ink':[[11,12],[13,14,15],[16,17],[22,32],[32,33],[35,36,37],[27,28]],
},
}

def linear(v):return ((v+.055)/1.055)**2.4 if v>.04045 else v/12.92
def make_materials(colors):
    result=[]
    for name,color in colors:
        mat=bpy.data.materials.new(name)
        mat.use_nodes=True
        shader=mat.node_tree.nodes['Principled BSDF']
        shader.inputs['Base Color'].default_value=(*[linear(v/255) for v in color],1)
        shader.inputs['Roughness'].default_value=.97
        shader.inputs['Specular IOR Level'].default_value=.02
        result.append(mat)
    return result

config=CONFIG[family]
center=config['center']
scale=config['scale']
def world(x,y,depth):return R*((x-center[0])/scale)+U*((center[1]-y)/scale)+D*depth
rows=config['rows']
depth=config['depth']
front=[world(x,y,depth[r][c]) for r,row in enumerate(rows) for c,(x,y) in enumerate(row)]
back=[world(center[0]+(x-center[0])*.86,center[1]+(y-center[1])*.86,-config['thickness']+.10*math.sin(c*1.3+r)) for r,row in enumerate(rows) for c,(x,y) in enumerate(row)]
vertices=front+back
faces=[]
slots=[]
cell_vertices={}
for r in range(4):
    for c in range(9):
        a,b,d,e=r*10+c,r*10+c+1,(r+1)*10+c,(r+1)*10+c+1
        faces.extend([(a,d,e),(a,e,b)] if (r+c)%3 else [(a,d,b),(b,d,e)])
        slots.extend([config['paint'][r][c]]*2)
        cell_vertices[(r,c)]=[a,b,d,e]
for r in range(4):
    for c in range(9):
        a,b,d,e=50+r*10+c,50+r*10+c+1,50+(r+1)*10+c,50+(r+1)*10+c+1
        faces.append((a,b,e,d))
        slots.append((r+c)%2)
rim=list(range(10))+[19,29,39,49]+list(range(48,39,-1))+[30,20,10]
mid_start=len(vertices)
for i,a in enumerate(rim):
    p=front[a].lerp(back[a],.48+.08*math.sin(i*1.7))
    p+=R*(.05*math.sin(i*.8))+U*(.06*math.cos(i*1.2))
    vertices.append(p)
for i,(a,b) in enumerate(zip(rim,rim[1:]+rim[:1])):
    m,n=mid_start+i,mid_start+(i+1)%len(rim)
    faces.extend([(a,b,n,m),(m,n,b+50,a+50)])
    slots.extend([(a+b)%2,(a+b+1)%2])
materials=make_materials(config['colors'])
mesh=bpy.data.meshes.new(family.title()+'SurfaceMesh')
mesh.from_pydata(vertices,[],faces)
mesh.update()
body=bpy.data.objects.new(family.title()+'Surface',mesh)
bpy.context.scene.collection.objects.link(body)
for mat in materials:mesh.materials.append(mat)
for face,slot in zip(mesh.polygons,slots):face.material_index=slot
body['art_proof']=True
bm=bmesh.new()
bm.from_mesh(mesh)
bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces))
bm.to_mesh(mesh)
bm.free()
if family=='ice':
    for index,cells in enumerate([[(0,0),(0,1),(1,1)],[(0,7),(0,8)],[(2,6)],[(3,3)]]):
        group=body.vertex_groups.new(name='EmbeddedStone'+str(index+1))
        group.add(sorted({i for cell in cells for i in cell_vertices[cell]}),1,'REPLACE')

gem_edges=[]
if family=='violet':
    pieces=[]
    for index,(cx,cy,rx,ry,near) in enumerate([(544,416,23,19,-.08),(565,399,24,25,-.02),(591,416,21,18,-.06),(607,404,13,13,-.12)]):
        outlines=[ [(-1,-.2),(-.5,-.8),(.5,-1),(.9,.3),(.2,.8),(-.6,.6)], [(-.9,-.35),(-.5,-1),(.45,-.88),(1,-.12),(.66,.75),(-.35,1)], [(-.8,-.6),(.1,-1),(.9,-.4),(1,.4),(.2,.7),(-.7,.9)], [(-.8,-.3),(-.6,-.9),(.3,-.7),(.9,.2),(.6,.7),(-.3,1)] ]
        angle=(-.35,.25,.62,-.4)[index]
        outline=[(x*math.cos(angle)-y*math.sin(angle),x*math.sin(angle)+y*math.cos(angle)) for x,y in outlines[index]]
        cap=[world(cx+x*rx,cy+y*ry,near+.055*math.sin(i*2+index)) for i,(x,y) in enumerate(outline)]
        base=[world(cx+x*rx*.84,cy+y*ry*.84,-.43) for x,y in outline]
        points=cap+base+[world(cx-2,cy-3,near+(.03 if index==1 else .075))]
        f=[(0,1,2,12),(2,3,4,12),(4,5,0,12)]+[(i,(i+1)%6,(i+1)%6+6,i+6) for i in range(6)]+[(11,10,9,8,7,6)]
        m=bpy.data.meshes.new('Amethyst exposure '+str(index+1))
        m.from_pydata(points,[],f)
        m.update()
        o=bpy.data.objects.new(m.name,m)
        bpy.context.scene.collection.objects.link(o)
        for mat in materials:m.materials.append(mat)
        for face in m.polygons:face.material_index=(3,4,5)[face.index%3]
        bm=bmesh.new();bm.from_mesh(m);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(m);bm.free()
        group=o.vertex_groups.new(name='AmethystFace'+str(index+1))
        group.add(list(range(len(points))),1,'REPLACE')
        pieces.append(o)
        gem_edges.extend([(cap[0],cap[1]),(cap[2],cap[3])])
    for obj in bpy.context.selected_objects:obj.select_set(False)
    for obj in pieces+[body]:obj.select_set(True)
    bpy.context.view_layer.objects.active=body
    bpy.ops.object.join()

tree=BVHTree.FromObject(body,bpy.context.evaluated_depsgraph_get())
paths=[[(front[a],front[b]) for a,b in zip(path,path[1:])] for path in config['ink']]
segments=[segment for path in paths for segment in path]+gem_edges
ink_vertices=[]
ink_faces=[]
for index,(a,b) in enumerate(segments):
    a,b=a.lerp(b,.06),a.lerp(b,.92)
    tangent=(b-a).normalized()
    _,normal,_,_=tree.find_nearest(a.lerp(b,.5))
    lateral=tangent.cross(normal).normalized()
    start=len(ink_vertices)
    for step in range(15):
        t=step/14
        q=a.lerp(b,t)+lateral*.0015*math.sin(t*13+index)
        width=.0085*math.sin(math.pi*t)**.6+.0008
        for sign in (-1,1):
            hit,n,_,_=tree.find_nearest(q+lateral*width*sign+normal*.003)
            ink_vertices.append(hit+n*.004)
        if step:ink_faces.append((start+2*step-2,start+2*step-1,start+2*step+1,start+2*step))
ink=bpy.data.meshes.new(family.title()+'DrawingMesh')
ink.from_pydata(ink_vertices,[],ink_faces)
drawing=bpy.data.objects.new(family.title()+'Drawing',ink)
bpy.context.scene.collection.objects.link(drawing)
drawing['art_proof']=True
drawing['drawing_role']='Fitted structural graphite; exported geometry.'
mat=make_materials([('Near-black graphite',(10,12,20))])[0]
ink.materials.append(mat)

scene=bpy.context.scene
scene.cycles.samples=24
scene.camera.data.ortho_scale=5.0
scene.camera.location=D*10
scene.camera.rotation_euler=(-scene.camera.location).to_track_quat('-Z','Y').to_euler()
scene.render.use_freestyle=True
line=bpy.context.view_layer.freestyle_settings.linesets[0]
line.select_external_contour=True
line.select_silhouette=False
line.linestyle.thickness=6
line.linestyle.color=(.003,.004,.009)
line.linestyle.caps='ROUND'
noise=line.linestyle.thickness_modifiers.new('Hand pressure','NOISE')
noise.amplitude=1.3
noise.period=32
noise.seed=7
scene['proof_stage']=family.title()+' reference-layout geometry proof. Structural ink is geometry; outer contour is Freestyle.'
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/(family+'-reference.blend')))
for label,position in [('hero',D*10),('reverse',Vector((3,8,5))),('side',Vector((7,-6,4)))]:
    scene.camera.location=position
    scene.camera.rotation_euler=(-scene.camera.location).to_track_quat('-Z','Y').to_euler()
    scene.render.filepath=str(OUT/(family+'-'+label+'.png'))
    bpy.ops.render.render(write_still=True)
print('REFERENCE='+str(OUT),flush=True)
