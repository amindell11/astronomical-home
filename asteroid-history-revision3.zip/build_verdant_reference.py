"""A split nodule with an off-center curved mineral exposure and broken rind."""
import bpy,bmesh,math
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree

OUT=Path(__file__).resolve().parent/'verdant-reference'
OUT.mkdir(parents=True,exist_ok=True)
bpy.ops.wm.open_mainfile(filepath='D:/amind/scratch/asteroid-locale-concepts-20261106/art-proof-revision2/copper/copper.blend')
bpy.context.preferences.filepaths.save_version=0
for obj in list(bpy.context.scene.objects):
    if obj.type=='MESH':bpy.data.objects.remove(obj,do_unlink=True)
D=Vector((0,-.8,.6));U=Vector((0,.6,.8));R=Vector((1,0,0))
outline=[(413,748),(426,704),(445,675),(477,663),(513,669),(546,687),(576,698),(610,687),(644,691),(676,709),(703,742),(693,768),(670,790),(631,803),(593,806),(560,815),(524,812),(492,803),(454,799),(429,778)]
def world(x,y,depth):return R*((x-557)/72.5)+U*((744-y)/72.5)+D*depth
vertices=[world(486,729,-.28)]
screens=[(486,729)]
n=len(outline)
for layer,(radius,depth) in enumerate([(18,-.22),(35,-.05),(52,.10),(70,.30)]):
    for i,(x,y) in enumerate(outline):
        theta=math.atan2((y-746)/.77,x-510)
        radius_i=radius*(1+.045*math.sin(i*2.1+layer))
        px=492+radius_i*math.cos(theta)+layer*7.5
        py=733+radius_i*.75*math.sin(theta)+layer*5
        d=depth+.035*math.sin(i*1.3+layer)
        if layer==3 and i in (2,3,4,11,12,13):d+=.15
        screens.append((px,py))
        vertices.append(world(px,py,d))
for i,(x,y) in enumerate(outline):
    depth=.29+.10*math.sin(i*1.6)
    if i in (2,3,4,11,12,13):depth+=.16
    screens.append((x,y));vertices.append(world(x,y,depth))
front_count=len(vertices)
faces=[];slots=[]
for i in range(n):faces.append((0,1+i,1+(i+1)%n));slots.append(3)
for layer in range(4):
    inner=1+layer*n;outer=inner+n
    for i in range(n):
        j=(i+1)%n
        faces.append((inner+i,outer+i,outer+j,inner+j))
        slot=[4,5,4,0][layer]
        if layer in (1,2) and 6<=i<=11:slot=0
        if layer==3 and i in (2,3,4):slot=2
        if layer==3 and i in (5,17):slot=7
        slots.append(slot)
outer_start=1+4*n
rear_start=len(vertices)
for i,(x,y) in enumerate(outline):
    vertices.append(world(557+(x-557)*.84,744+(y-744)*.84,-.85+.13*math.sin(i*1.4)))
rear_inner=len(vertices)
for i,(x,y) in enumerate(outline):
    vertices.append(world(557+(x-557)*.44,744+(y-744)*.44,-1.02+.10*math.sin(i*.8)))
rear_center=len(vertices);vertices.append(world(557,744,-1.04))
for i in range(n):
    j=(i+1)%n
    faces.extend([(outer_start+i,rear_start+i,rear_start+j,outer_start+j),(rear_start+i,rear_inner+i,rear_inner+j,rear_start+j),(rear_inner+i,rear_center,rear_inner+j)])
    slots.extend([i%2,(i+1)%2,i%2])
mesh=bpy.data.meshes.new('VerdantSurfaceMesh')
mesh.from_pydata(vertices,[],faces);mesh.update()
body=bpy.data.objects.new('VerdantSurface',mesh)
bpy.context.scene.collection.objects.link(body)
body['art_proof']=True
colors=[('Slate host',(85,98,101)),('Deep host',(64,74,80)),('Cream rind',(195,181,145)),('Deep green',(43,75,50)),('Green mineral',(68,108,65)),('Green pale band',(112,143,83)),('Olive mineral',(91,113,68)),('Sulfur',(181,153,65))]
def linear(v):return ((v+.055)/1.055)**2.4 if v>.04045 else v/12.92
for name,color in colors:
    mat=bpy.data.materials.new(name);mat.use_nodes=True
    shader=mat.node_tree.nodes['Principled BSDF']
    shader.inputs['Base Color'].default_value=(*[linear(v/255) for v in color],1)
    shader.inputs['Roughness'].default_value=.97
    shader.inputs['Specular IOR Level'].default_value=.02
    mesh.materials.append(mat)
for face,slot in zip(mesh.polygons,slots):face.material_index=slot
bm=bmesh.new();bm.from_mesh(mesh);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(mesh);bm.free()

rind_parts=[]
for index,points in enumerate([[(440,695),(450,678),(477,666),(500,677),(521,697),(510,715),(494,707),(485,738),(463,721)],[(543,748),(557,735),(584,742),(591,756),(576,767),(562,765),(551,781),(536,770)]]):
    top=[world(x,y,.45+.045*math.sin(i*1.9+index)) for i,(x,y) in enumerate(points)]
    bottom=[world(x,y,.16) for x,y in points]
    count=len(points)
    f=[tuple(range(count)),tuple(range(count*2-1,count-1,-1))]+[(i,(i+1)%count,(i+1)%count+count,i+count) for i in range(count)]
    m=bpy.data.meshes.new('Broken cream rind '+str(index));m.from_pydata(top+bottom,[],f);m.update()
    o=bpy.data.objects.new(m.name,m);bpy.context.scene.collection.objects.link(o)
    for mat in body.data.materials:m.materials.append(mat)
    for face in m.polygons:face.material_index=2 if face.index==0 else 0
    bm=bmesh.new();bm.from_mesh(m);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(m);bm.free()
    rind_parts.append(o)
for obj in bpy.context.selected_objects:obj.select_set(False)
for obj in rind_parts+[body]:obj.select_set(True)
bpy.context.view_layer.objects.active=body;bpy.ops.object.join()

tree=BVHTree.FromObject(body,bpy.context.evaluated_depsgraph_get())
paths=[[61,62,63],[64,65],[77,78,79],[91,92,93],[82,83],[96,97],[70,71]]
ink_vertices=[];ink_faces=[]
for index,path in enumerate(paths):
    for ia,ib in zip(path,path[1:]):
        a,b=Vector(vertices[ia]),Vector(vertices[ib])
        a,b=a.lerp(b,.10),a.lerp(b,.88)
        tangent=(b-a).normalized();_,normal,_,_=tree.find_nearest(a.lerp(b,.5));lateral=tangent.cross(normal).normalized()
        start=len(ink_vertices)
        for step in range(15):
            t=step/14;q=a.lerp(b,t);width=.0085*math.sin(math.pi*t)**.6+.0008
            for sign in (-1,1):
                hit,norm,_,_=tree.find_nearest(q+lateral*width*sign+normal*.003)
                ink_vertices.append(hit+norm*.004)
            if step:ink_faces.append((start+2*step-2,start+2*step-1,start+2*step+1,start+2*step))
ink=bpy.data.meshes.new('VerdantDrawingMesh');ink.from_pydata(ink_vertices,[],ink_faces)
drawing=bpy.data.objects.new('VerdantDrawing',ink);bpy.context.scene.collection.objects.link(drawing);drawing['art_proof']=True
drawing['drawing_role']='Fitted broken rind and mineral-boundary graphite; exported geometry.'
mat=bpy.data.materials.new('Near-black graphite');mat.use_nodes=True
shader=mat.node_tree.nodes['Principled BSDF'];shader.inputs['Base Color'].default_value=(.003,.004,.009,1);shader.inputs['Roughness'].default_value=1;shader.inputs['Specular IOR Level'].default_value=0
ink.materials.append(mat)
scene=bpy.context.scene;scene.cycles.samples=24
scene.camera.data.ortho_scale=5.0;scene.camera.location=D*10;scene.camera.rotation_euler=(-scene.camera.location).to_track_quat('-Z','Y').to_euler()
scene.render.use_freestyle=True;line=bpy.context.view_layer.freestyle_settings.linesets[0]
line.select_external_contour=True;line.select_silhouette=False;line.linestyle.thickness=6;line.linestyle.color=(.003,.004,.009);line.linestyle.caps='ROUND'
noise=line.linestyle.thickness_modifiers.new('Hand pressure','NOISE');noise.amplitude=1.3;noise.period=32;noise.seed=7
scene['proof_stage']='Verdant split nodule with off-center curved bands; structural graphite mesh and Freestyle contour.'
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'verdant-reference.blend'))
for label,position in [('hero',D*10),('reverse',Vector((3,8,5))),('side',Vector((7,-6,4)))]:
    scene.camera.location=position;scene.camera.rotation_euler=(-scene.camera.location).to_track_quat('-Z','Y').to_euler();scene.render.filepath=str(OUT/('verdant-'+label+'.png'));bpy.ops.render.render(write_still=True)
print('REFERENCE='+str(OUT),flush=True)
