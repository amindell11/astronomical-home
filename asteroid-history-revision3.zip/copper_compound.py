"""Copper concept correction: unequal descending wedges on a shared rock core."""
import bpy,bmesh,math
from pathlib import Path
from mathutils import Vector

OUT=Path(__file__).resolve().parent/'copper-compound'
OUT.mkdir(parents=True,exist_ok=True)
bpy.ops.wm.open_mainfile(filepath='D:/amind/scratch/asteroid-locale-concepts-20261106/art-proof-revision2/copper/copper.blend')
bpy.context.preferences.filepaths.save_version=0
for obj in list(bpy.context.scene.objects):
    if obj.type=='MESH':bpy.data.objects.remove(obj,do_unlink=True)

def linear(v):return ((v+.055)/1.055)**2.4 if v>.04045 else v/12.92
materials=[]
for name,color in [('Slate',(83,83,103)),('Slate lit',(103,103,120)),('Slate deep',(62,65,83)),('Copper',(169,105,64)),('Copper ochre',(188,128,76)),('Copper dark',(129,77,50)),('Patina',(64,128,123)),('Patina pale',(87,151,136))]:
    mat=bpy.data.materials.new(name)
    mat.use_nodes=True
    shader=mat.node_tree.nodes['Principled BSDF']
    shader.inputs['Base Color'].default_value=(*[linear(v/255) for v in color],1)
    shader.inputs['Roughness'].default_value=.96
    shader.inputs['Specular IOR Level'].default_value=.02
    materials.append(mat)
pieces=[]
ridge_paths=[]

def wedge(name,outline,top_slots,side_copper=(),strokes=()):
    center=sum((Vector(v) for v in outline),Vector())/len(outline)
    n=len(outline)
    bottom=[(center.x+(x-center.x)*.88,center.y+(y-center.y)*.90,-.55+.04*y+.025*math.sin(i*1.8)) for i,(x,y,z) in enumerate(outline)]
    peak=center.copy()
    peak.x-=.06
    peak.y+=.03
    peak.z+=.04
    points=outline+bottom+[tuple(peak)]
    top=[(0,1,2,2*n),(2,3,4,2*n),(4,5,6,2*n),(6,7,0,2*n)]
    faces=top+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]+[tuple(range(2*n-1,n-1,-1))]
    mesh=bpy.data.meshes.new(name+'Mesh')
    mesh.from_pydata(points,[],faces)
    mesh.update()
    obj=bpy.data.objects.new(name,mesh)
    bpy.context.scene.collection.objects.link(obj)
    for mat in materials:mesh.materials.append(mat)
    for i,face in enumerate(mesh.polygons):
        face.material_index=top_slots[i] if i<4 else (5 if i-4 in side_copper else (i+len(pieces))%3)
    bm=bmesh.new()
    bm.from_mesh(mesh)
    bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces))
    bm.to_mesh(mesh)
    bm.free()
    pieces.append(obj)
    for a,b in strokes:
        va,vb=Vector(outline[a]),Vector(outline[b])
        ridge_paths.append((va.lerp(vb,.10),va.lerp(vb,.86)))
    return obj

left=wedge('Copper left descending plate',[
    (-1.93,-.43,-.18),(-1.47,-.82,-.35),(-.78,-.65,-.28),(-.51,-.19,.04),
    (-.63,.58,.44),(-1.08,.76,.50),(-1.63,.55,.40),(-1.90,.05,.12)
],[5,3,1,3],side_copper=(1,2,6),strokes=((1,2),(2,3),(4,5)))
middle=wedge('Copper central shear',[
    (-.70,-.48,-.26),(-.24,-.69,-.33),(.34,-.47,-.25),(.60,-.09,.02),
    (.53,.54,.43),(.26,.83,.56),(-.27,.72,.58),(-.43,.34,.30)
],[0,2,0,1],side_copper=(),strokes=((0,1),(3,4),(6,7)))
right=wedge('Copper right descending plate',[
    (.40,-.61,-.29),(.97,-.72,-.22),(1.78,-.24,-.04),(1.91,.12,.12),
    (1.57,.65,.39),(1.04,.76,.47),(.77,.41,.31),(.69,.02,.04)
],[3,1,4,3],side_copper=(0,1),strokes=((1,2),(4,5),(6,7)))
back=wedge('Copper rear broken shoulder',[
    (-.48,.51,.03),(-.08,.46,.06),(.48,.52,.10),(.84,.65,.25),
    (.61,.94,.43),(.12,1.00,.45),(-.22,.86,.40),(-.56,.71,.28)
],[0,1,0,2],strokes=((4,5),))
core=wedge('Copper shared broken core',[
    (-2.00,-.35,-.37),(-1.52,-.85,-.39),(-.30,-.86,-.39),(1.34,-.61,-.36),
    (1.97,.04,-.31),(1.34,.72,-.32),(-.13,.87,-.32),(-1.61,.54,-.34)
],[0,0,0,0])

for obj in bpy.context.selected_objects:obj.select_set(False)
for obj in pieces:obj.select_set(True)
bpy.context.view_layer.objects.active=left
bpy.ops.object.join()
body=left
body.name='CopperSurface'
body.data.name='CopperSurfaceMesh'
body['art_proof']=True

# Small deposits occupy three selected fracture corners, leaving most lips bare.
patch_vertices=[]
patch_faces=[]
for a,b,c in [
    ((-1.90,.05,.125),(-1.93,-.43,-.175),(-1.63,.55,.405)),
    ((1.57,.65,.395),(1.91,.12,.125),(1.04,.76,.475)),
    ((.40,-.61,-.285),(.97,-.72,-.215),(.69,.02,.045))]:
    a,b,c=Vector(a),Vector(b),Vector(c)
    start=len(patch_vertices)
    patch_vertices.extend((a,a.lerp(b,.50),a.lerp(b,.42).lerp(c,.07),a.lerp(c,.16)))
    patch_faces.append(tuple(range(start,start+4)))
mesh=bpy.data.meshes.new('Local patina deposits')
mesh.from_pydata(patch_vertices,[],patch_faces)
mesh.materials.append(materials[6])
patch=bpy.data.objects.new('Local patina deposits',mesh)
bpy.context.scene.collection.objects.link(patch)
patch.select_set(True)
body.select_set(True)
bpy.context.view_layer.objects.active=body
bpy.ops.object.join()

from mathutils.bvhtree import BVHTree
tree=BVHTree.FromObject(body,bpy.context.evaluated_depsgraph_get())
vertices=[]
faces=[]
for index,(a,b) in enumerate(ridge_paths):
    tangent=(b-a).normalized()
    _,normal,_,_=tree.find_nearest(a.lerp(b,.5))
    lateral=tangent.cross(normal).normalized()
    start=len(vertices)
    for step in range(13):
        t=step/12
        point=a.lerp(b,t)
        width=.010*math.sin(math.pi*t)**.55+.001
        for sign in (-1,1):
            q=point+lateral*width*sign
            hit,n,_,_=tree.find_nearest(q+normal*.004)
            vertices.append(hit+n*.005)
        if step:faces.append((start+step*2-2,start+step*2-1,start+step*2+1,start+step*2))
mesh=bpy.data.meshes.new('CopperDrawingMesh')
mesh.from_pydata(vertices,[],faces)
drawing=bpy.data.objects.new('CopperDrawing',mesh)
bpy.context.scene.collection.objects.link(drawing)
drawing['art_proof']=True
mat=bpy.data.materials.new('Near-black structural graphite')
mat.use_nodes=True
shader=mat.node_tree.nodes['Principled BSDF']
shader.inputs['Base Color'].default_value=(.003,.004,.009,1)
shader.inputs['Roughness'].default_value=1
shader.inputs['Specular IOR Level'].default_value=0
mesh.materials.append(mat)

scene=bpy.context.scene
scene.cycles.samples=32
scene.camera.data.ortho_scale=5.0
hero=(-3,-8,7)
scene.camera.location=hero
scene.camera.rotation_euler=(-scene.camera.location).to_track_quat('-Z','Y').to_euler()
scene.render.use_freestyle=True
line=bpy.context.view_layer.freestyle_settings.linesets[0]
line.select_external_contour=True
line.select_silhouette=False
line.linestyle.thickness=6
line.linestyle.color=(.003,.004,.009)
line.linestyle.caps='ROUND'
noise=line.linestyle.thickness_modifiers.new('Hand pressure','NOISE')
noise.amplitude=1.2
noise.period=35
noise.seed=5
scene['proof_stage']='Copper compound geometry draft. Structural graphite is mesh geometry; outer contour is Freestyle.'
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'copper-compound.blend'))
for label,camera in [('hero',hero),('reverse',(4,7,6))]:
    scene.camera.location=camera
    scene.camera.rotation_euler=(-scene.camera.location).to_track_quat('-Z','Y').to_euler()
    scene.render.filepath=str(OUT/('copper-'+label+'.png'))
    bpy.ops.render.render(write_still=True)
print('COPPER_COMPOUND='+str(OUT),flush=True)
