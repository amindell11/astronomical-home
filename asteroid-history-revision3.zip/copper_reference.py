"""Build Copper's shared fracture planes from the approved reference layout.
The reference camera controls the front layout; a closed rear gives real volume.
"""
import bpy,bmesh,math
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree

OUT=Path(__file__).resolve().parent/'copper-reference'
OUT.mkdir(parents=True,exist_ok=True)
bpy.ops.wm.open_mainfile(filepath='D:/amind/scratch/asteroid-locale-concepts-20261106/art-proof-revision2/copper/copper.blend')
bpy.context.preferences.filepaths.save_version=0
for obj in list(bpy.context.scene.objects):
    if obj.type=='MESH':bpy.data.objects.remove(obj,do_unlink=True)

ROWS=[
 [(432,191),(459,163),(493,151),(538,151),(589,152),(620,142),(657,146),(682,152),(705,163),(717,177)],
 [(420,218),(441,211),(479,206),(516,184),(554,174),(588,179),(622,173),(650,182),(686,185),(717,200)],
 [(408,247),(438,239),(461,235),(494,222),(535,220),(568,208),(605,217),(634,219),(670,218),(705,218)],
 [(421,270),(444,265),(466,275),(497,265),(523,266),(554,250),(586,254),(620,243),(651,250),(693,239)],
 [(444,283),(470,294),(493,292),(516,298),(538,293),(565,294),(594,280),(621,275),(648,262),(673,250)]
]
DEPTH=[
 [-.10,.0,.05,.05,-.10,.0,-.04,.12,.10,.0],
 [.12,.25,.58,.62,.48,.18,.38,.53,.45,.02],
 [.14,.25,.56,.65,.20,.0,.40,.54,.30,.04],
 [.22,.25,.48,.30,.0,-.05,.22,.50,.15,.08],
 [.25,.25,.28,.20,.18,.10,.12,.22,.13,.12]
]
PAINT=[
 [0,3,3,4,1,0,3,4,0],
 [6,0,3,2,2,0,4,3,1],
 [0,1,5,2,0,1,3,6,0],
 [1,0,5,0,2,0,1,0,1]
]
D=Vector((0,-.8,.6))
U=Vector((0,.6,.8))
R=Vector((1,0,0))
def world(x,y,depth):return R*((x-562)/77)+U*((218-y)/77)+D*depth
insertions={2:(.42,[0,.11,.16,.03,0]),3:(.28,[0,.02,-.13,-.06,0]),6:(.62,[0,.10,.12,-.03,0]),7:(.30,[0,-.03,-.10,0,0])}
expanded=[]
expanded_depth=[]
original_indices={}
columns=[]
for c in range(10):
    columns.append(c)
    if c in insertions:columns.append(c+.5)
for r,row in enumerate(ROWS):
    points=[]
    depths=[]
    for c,point in enumerate(row):
        original_indices[r*10+c]=r*len(columns)+len(points)
        points.append(point)
        depths.append(DEPTH[r][c])
        if c in insertions:
            fraction,relief=insertions[c]
            points.append(tuple(point[a]*(1-fraction)+row[c+1][a]*fraction for a in range(2)))
            depths.append(DEPTH[r][c]*(1-fraction)+DEPTH[r][c+1]*fraction+relief[r])
    expanded.append(points)
    expanded_depth.append(depths)
width=len(columns)
count=width*5
front=[world(x,y,expanded_depth[r][c]) for r,row in enumerate(expanded) for c,(x,y) in enumerate(row)]
rear=[world(562+(x-562)*.88,218+(y-218)*.88,-.80+.13*math.sin(c*.9+r*1.3)) for r,row in enumerate(expanded) for c,(x,y) in enumerate(row)]
vertices=front+rear
faces=[]
slots=[]
for r in range(4):
    for c in range(width-1):
        a,b,d,e=r*width+c,r*width+c+1,(r+1)*width+c,(r+1)*width+c+1
        if (r+c)%3==0:
            faces.extend([(a,d,b),(b,d,e)])
        else:faces.extend([(a,d,e),(a,e,b)])
        slots.extend([PAINT[r][int(columns[c])]]*2)
for r in range(4):
    for c in range(width-1):
        a,b,d,e=count+r*width+c,count+r*width+c+1,count+(r+1)*width+c,count+(r+1)*width+c+1
        faces.append((a,b,e,d))
        slots.append((r+c)%3)
rim=list(range(width))+[width*r+width-1 for r in range(1,5)]+list(range(count-2,count-width-1,-1))+[width*r for r in range(3,0,-1)]
mid_start=len(vertices)
for i,a in enumerate(rim):
    point=front[a].lerp(rear[a],.48+.08*math.sin(i*1.7))
    point+=R*(.06*math.sin(i*.8))+U*(.05*math.cos(i*1.2))+D*(.05*math.sin(i*2.1))
    vertices.append(point)
for i,(a,b) in enumerate(zip(rim,rim[1:]+rim[:1])):
    m,n=mid_start+i,mid_start+(i+1)%len(rim)
    faces.extend([(a,b,n,m),(m,n,b+count,a+count)])
    slots.extend([(a+b)%3,(a+b+1)%3])
mesh=bpy.data.meshes.new('CopperSurfaceMesh')
mesh.from_pydata(vertices,[],faces)
mesh.update()
body=bpy.data.objects.new('CopperSurface',mesh)
bpy.context.scene.collection.objects.link(body)
body['art_proof']=True
body['construction']='Shared angular fracture planes, closed back and sidewalls. No image projection.'
def linear(v):return ((v+.055)/1.055)**2.4 if v>.04045 else v/12.92
for name,color in [('Slate',(83,83,103)),('Slate light',(102,104,121)),('Slate shadow mineral',(63,66,84)),('Copper',(164,101,62)),('Copper ochre',(181,117,69)),('Copper dark',(126,76,50)),('Patina',(64,128,123))]:
    mat=bpy.data.materials.new(name)
    mat.use_nodes=True
    shader=mat.node_tree.nodes['Principled BSDF']
    shader.inputs['Base Color'].default_value=(*[linear(v/255) for v in color],1)
    shader.inputs['Roughness'].default_value=.97
    shader.inputs['Specular IOR Level'].default_value=.02
    mesh.materials.append(mat)
for face,slot in zip(mesh.polygons,slots):face.material_index=slot
bm=bmesh.new()
bm.from_mesh(mesh)
bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces))
bm.to_mesh(mesh)
bm.free()

tree=BVHTree.FromObject(body,bpy.context.evaluated_depsgraph_get())
paths=[[11,12],[13,14],[13,23,33],[16,26,36],[27,28],[36,37,38],[30,31],[42,43],[7,8]]
ink_vertices=[]
ink_faces=[]
for index,path in enumerate(paths):
    for ia,ib in zip(path,path[1:]):
        a,b=front[original_indices[ia]],front[original_indices[ib]]
        a,b=a.lerp(b,.06),a.lerp(b,.93)
        tangent=(b-a).normalized()
        _,normal,_,_=tree.find_nearest(a.lerp(b,.5))
        lateral=tangent.cross(normal).normalized()
        start=len(ink_vertices)
        for step in range(15):
            t=step/14
            q=a.lerp(b,t)+lateral*(.0015*math.sin(t*13+index))
            width=.0085*math.sin(math.pi*t)**.6+.0008
            for sign in (-1,1):
                hit,n,_,_=tree.find_nearest(q+lateral*width*sign+normal*.003)
                ink_vertices.append(hit+n*.004)
            if step:ink_faces.append((start+2*step-2,start+2*step-1,start+2*step+1,start+2*step))
ink=bpy.data.meshes.new('CopperDrawingMesh')
ink.from_pydata(ink_vertices,[],ink_faces)
drawing=bpy.data.objects.new('CopperDrawing',ink)
bpy.context.scene.collection.objects.link(drawing)
drawing['art_proof']=True
drawing['drawing_role']='Selected fracture boundaries, fitted exported graphite mesh.'
mat=bpy.data.materials.new('Near-black graphite')
mat.use_nodes=True
shader=mat.node_tree.nodes['Principled BSDF']
shader.inputs['Base Color'].default_value=(.003,.004,.009,1)
shader.inputs['Roughness'].default_value=1
shader.inputs['Specular IOR Level'].default_value=0
ink.materials.append(mat)

scene=bpy.context.scene
scene.cycles.samples=32
scene.camera.data.ortho_scale=5.0
scene.camera.location=D*10
scene.camera.rotation_euler=(-scene.camera.location).to_track_quat('-Z','Y').to_euler()
scene.render.use_freestyle=True
line=bpy.context.view_layer.freestyle_settings.linesets[0]
line.select_external_contour=True
line.select_silhouette=False
line.linestyle.thickness=6
line.linestyle.color=(.003,.004,.009)
line.linestyle.caps='ROUND'
noise=line.linestyle.thickness_modifiers.new('Hand pressure','NOISE')
noise.amplitude=1.3
noise.period=32
noise.seed=7
scene['proof_stage']='Copper reference-layout geometry draft; fitted graphite and Blender outer ink.'
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'copper-reference.blend'))
for label,position in [('hero',D*10),('reverse',Vector((3,8,5))),('side',Vector((7,-6,4)))]:
    scene.camera.location=position
    scene.camera.rotation_euler=(-scene.camera.location).to_track_quat('-Z','Y').to_euler()
    scene.render.filepath=str(OUT/('copper-'+label+'.png'))
    bpy.ops.render.render(write_still=True)
print('COPPER_REFERENCE='+str(OUT),flush=True)
