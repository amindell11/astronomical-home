"""Correct the selected Copper mass and add fitted structural graphite.
Revision 2 remains unchanged. This first pass writes only editable draft previews.
"""
import bpy,bmesh,math,json
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree

OUT=Path(__file__).resolve().parent/'copper'
OUT.mkdir(parents=True,exist_ok=True)
bpy.ops.wm.open_mainfile(filepath='D:/amind/scratch/asteroid-locale-concepts-20261106/art-proof-revision2/copper/copper.blend')
bpy.context.preferences.filepaths.save_version=0
body=bpy.data.objects['CopperSurface']
for vertex in body.data.vertices:
    x,y,z=vertex.co
    floor=.18*math.exp(-((z+.10)/.16)**2)*math.exp(-((y-.03)/.42)**2)
    vertex.co=(x+.10*y+.08*z,y*1.10-.08*x,z*.70+.26*y+floor)
body.data.update()
chip_material=body.data.materials[0].copy()
chip_material.name='Copper new shear planes'
body.data.materials.append(chip_material)

def cut(name,points):
    mesh=bpy.data.meshes.new(name)
    mesh.from_pydata(points,[],[])
    bm=bmesh.new()
    bm.from_mesh(mesh)
    bmesh.ops.convex_hull(bm,input=list(bm.verts))
    bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces))
    bm.to_mesh(mesh)
    bm.free()
    for material in body.data.materials:mesh.materials.append(material)
    for face in mesh.polygons:face.material_index=1
    tool=bpy.data.objects.new(name,mesh)
    bpy.context.scene.collection.objects.link(tool)
    bpy.context.view_layer.objects.active=body
    mod=body.modifiers.new(name,'BOOLEAN')
    mod.operation='DIFFERENCE'
    mod.solver='EXACT'
    mod.object=tool
    bpy.ops.object.modifier_apply(modifier=mod.name)
    bpy.data.objects.remove(tool,do_unlink=True)

for index,(x,width,depth,lean,zlow) in enumerate([(-1.02,.12,.26,.38,-.50),(-.12,.09,.33,.48,-.31),(.98,.15,.50,.34,-.42)]):
    points=[]
    for z in (zlow,.96):
        points.extend([(x+lean*z-width,-1.25,z),(x+lean*z+width,-1.25,z),(x+lean*z,depth,z)])
    cut('Oblique shear '+str(index),points)
cut('Broken left shoulder',[(-2.35,-.75,-.9),(-1.48,-1.10,-.9),(-1.85,-.36,-.9),(-2.35,-.75,.7),(-1.62,-1.10,.7),(-1.96,-.30,.7)])
cut('Right end fracture',[(1.95,-.2,-.8),(1.47,-.82,-.8),(2.4,-1.0,-.8),(1.97,-.12,.8),(1.78,-.60,.8),(2.4,-1.0,.8)])

uv=body.data.uv_layers.active
new_faces=[]
for face in body.data.polygons:
    if face.material_index!=1:continue
    new_faces.append(face.index)
    axis=max(range(3),key=lambda a:abs(face.normal[a]))
    axes=[a for a in range(3) if a!=axis]
    points=[body.data.vertices[body.data.loops[i].vertex_index].co for i in face.loop_indices]
    low=[min(p[a] for p in points) for a in axes]
    high=[max(p[a] for p in points) for a in axes]
    copper=face.normal.x<-.25 and face.center.z>-.28
    base=(.343,.56) if copper else (.57,.36)
    extent=(.043,.22) if copper else (.06,.13)
    for loop,p in zip(face.loop_indices,points):
        uv.data[loop].uv=tuple(base[i]+extent[i]*(p[a]-low[i])/max(high[i]-low[i],1e-6) for i,a in enumerate(axes))
    face.material_index=0
body.data.materials.pop(index=1)
body.data.update()

bm=bmesh.new()
bm.from_mesh(body.data)
bm.normal_update()
candidates=[]
for edge in bm.edges:
    if len(edge.link_faces)!=2:continue
    a,b=(v.co.copy() for v in edge.verts)
    center=(a+b)*.5
    angle=edge.calc_face_angle()
    length=(a-b).length
    if .30<length<1.8 and angle>.5 and center.y<.42 and -.40<center.z<.62:
        normal=sum((f.normal for f in edge.link_faces),Vector()).normalized()
        candidates.append((length*angle,a,b,normal))
selected=[]
for score,a,b,normal in sorted(candidates,key=lambda q:q[0],reverse=True):
    center=(a+b)*.5
    if all((center-(other[0]+other[1])*.5).length>.32 for other in selected):selected.append((a,b,normal))
    if len(selected)==11:break
bm.free()
tree=BVHTree.FromObject(body,bpy.context.evaluated_depsgraph_get())
vertices=[]
faces=[]
for index,(a,b,normal) in enumerate(selected):
    tangent=(b-a).normalized()
    lateral=tangent.cross(normal).normalized()
    a=a.lerp(b,.04)
    b=b.lerp(a,.07)
    start=len(vertices)
    for step in range(17):
        t=step/16
        center=a.lerp(b,t)+lateral*(.003*math.sin(t*9+index))
        width=.013*(math.sin(math.pi*t)**.65)*(.78+.22*math.sin(t*13+index)**2)+.001
        for sign in (-1,1):
            q=center+lateral*width*sign
            hit,n,_,_=tree.find_nearest(q+normal*.008)
            vertices.append(hit+n*.004)
        if step:faces.append((start+2*step-2,start+2*step-1,start+2*step+1,start+2*step))
mesh=bpy.data.meshes.new('CopperDrawingMesh')
mesh.from_pydata(vertices,[],faces)
mesh.update()
drawing=bpy.data.objects.new('CopperDrawing',mesh)
bpy.context.scene.collection.objects.link(drawing)
drawing['art_proof']=True
drawing['drawing_role']='Fitted graphite follows selected structural fracture edges; exported geometry.'
mat=bpy.data.materials.new('Near-black graphite')
mat.use_nodes=True
shader=mat.node_tree.nodes['Principled BSDF']
shader.inputs['Base Color'].default_value=(.003,.004,.009,1)
shader.inputs['Roughness'].default_value=1
shader.inputs['Specular IOR Level'].default_value=0
drawing.data.materials.append(mat)

scene=bpy.context.scene
scene.cycles.samples=32
scene.camera.data.ortho_scale=4.9
scene.camera.location=(-3.5,-7,6.3)
scene.camera.rotation_euler=(-scene.camera.location).to_track_quat('-Z','Y').to_euler()
scene.render.use_freestyle=True
settings=bpy.context.view_layer.freestyle_settings
line=settings.linesets[0]
line.select_external_contour=True
line.select_silhouette=False
line.linestyle.thickness=6
line.linestyle.color=(.003,.004,.009)
line.linestyle.caps='ROUND'
noise=line.linestyle.thickness_modifiers.new('Hand pressure','NOISE')
noise.amplitude=1.5
noise.period=35
noise.seed=8
scene['proof_stage']='Copper revision 3 draft. Exported fitted graphite; screen-width outer ink is Blender Freestyle.'
scene.render.filepath=str(OUT/'copper-draft-hero.png')
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'copper-draft.blend'))
bpy.ops.render.render(write_still=True)
scene.camera.location=(4,7,5.6)
scene.camera.rotation_euler=(-scene.camera.location).to_track_quat('-Z','Y').to_euler()
scene.render.filepath=str(OUT/'copper-draft-reverse.png')
bpy.ops.render.render(write_still=True)
print('COPPER_DRAFT='+str(OUT),flush=True)
