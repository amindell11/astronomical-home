import bpy,json
from pathlib import Path

OUT=Path(__file__).resolve().parent/'outline-diagnosis'
OUT.mkdir(parents=True,exist_ok=True)
bpy.ops.wm.open_mainfile(filepath='D:/amind/scratch/asteroid-locale-concepts-20261106/art-proof-revision2/copper/copper.blend')
s=bpy.context.scene
s.cycles.samples=16
ls=bpy.context.view_layer.freestyle_settings.linesets[0]
for label,enabled,silhouette,thickness in [('off',False,False,1.6),('external16',True,False,16),('silhouette16',True,True,16)]:
    s.render.use_freestyle=enabled
    ls.select_external_contour=not silhouette
    ls.select_silhouette=silhouette
    ls.linestyle.thickness=thickness
    s.render.filepath=str(OUT/(label+'.png'))
    bpy.ops.render.render(write_still=True)
    print('DIAG_RENDER='+label,flush=True)
