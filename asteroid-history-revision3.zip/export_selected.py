"""Package selected art and export surface plus persistent structural Drawing.
Optional --family NAME limits work. Writes clean deliverables, native96 and 8 views.
"""
import bpy,math,sys,shutil
from pathlib import Path
from mathutils import Vector

ROOT=Path(__file__).resolve().parent
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
families=[args[args.index('--family')+1]] if '--family' in args else ('copper','violet','chalk','verdant','ice')
for family in families:
    source=ROOT/(family+'-reference')
    out=ROOT/'deliverables'/family
    out.mkdir(parents=True,exist_ok=True)
    bpy.ops.wm.open_mainfile(filepath=str(source/(family+'-painted.blend')))
    bpy.context.preferences.filepaths.save_version=0
    models=[o for o in bpy.context.scene.objects if o.type=='MESH']
    body=bpy.data.objects[family.title()+'Surface']
    drawing=bpy.data.objects[family.title()+'Drawing']
    assert set(models)=={body,drawing}
    used={m for obj in models for m in obj.data.materials}
    for mat in list(bpy.data.materials):
        if mat not in used:bpy.data.materials.remove(mat,do_unlink=True)
    image=next(node.image for node in body.data.materials[0].node_tree.nodes if node.type=='TEX_IMAGE')
    for old in list(bpy.data.images):
        if old.source=='FILE' and old!=image:bpy.data.images.remove(old,do_unlink=True)
    for mesh in list(bpy.data.meshes):
        if mesh.users==0:bpy.data.meshes.remove(mesh)
    shutil.copy2(source/(family+'-albedo.png'),out/(family+'-albedo.png'))
    image.filepath='//'+family+'-albedo.png'
    image.pack()
    shutil.copy2(source/(family+'-color-guide.png'),out/(family+'-color-guide.png'))
    shutil.copy2(source/(family+'-uv-layout.png'),out/(family+'-guide-uv-layout.png'))
    for view in ('hero','reverse','side'):
        shutil.copy2(source/(family+'-painted-'+view+'.png'),out/(family+'-'+view+'.png'))
    shutil.copy2(source/(family+'-painted-native.png'),out/(family+'-native-160x128.png'))
    scene=bpy.context.scene
    scene.render.filepath='//'+family+'-hero.png'
    scene['proof_stage']='Locale asteroid art proof. Surface and fitted Drawing export; outer contour is Blender Freestyle, not embedded in FBX/GLB.'
    bpy.ops.wm.save_as_mainfile(filepath=str(out/(family+'.blend')),relative_remap=False)
    for obj in bpy.context.selected_objects:obj.select_set(False)
    for obj in models:obj.select_set(True)
    bpy.context.view_layer.objects.active=body
    bpy.ops.export_scene.fbx(filepath=str(out/(family+'.fbx')),use_selection=True,object_types={'MESH'},bake_anim=False,path_mode='COPY',embed_textures=True,axis_forward='-Z',axis_up='Y')
    bpy.ops.export_scene.gltf(filepath=str(out/(family+'.glb')),export_format='GLB',use_selection=True,export_yup=True)
    line=bpy.context.view_layer.freestyle_settings.linesets[0]
    scene.render.resolution_x=120;scene.render.resolution_y=96
    scene.camera.data.ortho_scale=5.14
    line.linestyle.thickness=2.1
    line.linestyle.thickness_modifiers[0].amplitude=.35
    line.linestyle.thickness_modifiers[0].period=10
    scene.render.filepath=str(out/(family+'-native-120x96.png'))
    bpy.ops.render.render(write_still=True)
    turn=out/'turntable';turn.mkdir(exist_ok=True)
    scene.render.resolution_x=360;scene.render.resolution_y=280;scene.cycles.samples=16
    scene.camera.data.ortho_scale=5.0
    line.linestyle.thickness=3.3;line.linestyle.thickness_modifiers[0].amplitude=.7;line.linestyle.thickness_modifiers[0].period=20
    for angle in range(0,360,45):
        theta=math.radians(angle)
        scene.camera.location=(-8*math.sin(theta),-8*math.cos(theta),6)
        scene.camera.rotation_euler=(-scene.camera.location).to_track_quat('-Z','Y').to_euler()
        scene.render.filepath=str(turn/(family+'-'+str(angle).zfill(3)+'.png'))
        bpy.ops.render.render(write_still=True)
    print('EXPORTED='+family,flush=True)
