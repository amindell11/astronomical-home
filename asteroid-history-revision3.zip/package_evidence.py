"""Collect selected prompts and compose final UV/turntable/reimport evidence.
Required --review-dir gives the directory emitted by review_boards.py.
"""
import json,shutil,hashlib,sys
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont,ImageChops,ImageStat

ROOT=Path(__file__).resolve().parent/'deliverables'
args=sys.argv[1:];review=Path(args[args.index('--review-dir')+1])
REFERENCE=Path('D:/amind/scratch/asteroid-locale-concepts-20261106/revision3')
FAMILIES=[('copper','1 Copper'),('violet','2 Violet'),('chalk','3 Chalk'),('verdant','6 Verdant'),('ice','7 Ice')]
BG=(30,38,50,255);FONT='C:/Windows/Fonts/segoeui.ttf'
def label(canvas,xy,value,size=20,color=(231,232,225,255)):
    ImageDraw.Draw(canvas).text(xy,value,font=ImageFont.truetype(FONT,size),fill=color)
def subject(path):
    image=Image.open(path).convert('RGBA');return image.crop(image.getchannel('A').getbbox())
def fit(canvas,image,box):
    x,y,w,h=box;s=min(w/image.width,h/image.height)
    image=image.resize((round(image.width*s),round(image.height*s)),Image.Resampling.LANCZOS)
    canvas.alpha_composite(image,(x+(w-image.width)//2,y+(h-image.height)//2))
for name in ('asteroid-before-after.png','asteroid-mesh-proof-sheet.png'):shutil.copy2(review/name,ROOT/name)
shutil.copy2(REFERENCE/'README-art-revision3.md',ROOT/'README.md')
readme=ROOT/'README.md'
readme.write_text(readme.read_text()+'\nThe `*-guide-uv-layout.png` files preserve the painting inputs. The `*-uv-layout.png` files show final UVs; Chalk’s new ledge wall reuses a slate paint region. Native small renders use 160 × 128 and 120 × 96 canvases, with separately sized outer ink.\n')
chains={name:[name+'-reference-prompt.txt'] for name,_ in FAMILIES}
chains['copper']+=['copper-reference-padding-prompt.txt','copper-reference-calm-prompt.txt']
originals={name:name+'-reference-painted.png' for name,_ in FAMILIES};originals['copper']='copper-reference-calm.png'
provenance={'method':'Built-in Imagegen painting of unlit geometry-region UV guides. Generated final PNGs are unchanged. Internal graphite is fitted mesh geometry; outer contour is Blender Freestyle.','families':[]}
report=json.loads((ROOT/'validation.json').read_text())
for record in report['families']:
    family=record['family'];folder=ROOT/family
    guides=Path(__file__).resolve().parent/(family+'-reference')
    shutil.copy2(guides/(family+'-uv-layout.png'),folder/(family+'-guide-uv-layout.png'))
    polygons=json.loads((folder/(family+'-uv-layout.json')).read_text())
    canvas=Image.new('RGB',(2048,2048),(82,82,102));draw=ImageDraw.Draw(canvas)
    for polygon in polygons:draw.line([(u*2048,(1-v)*2048) for u,v in polygon+[polygon[0]]],fill=(225,227,230),width=2)
    canvas.save(folder/(family+'-uv-layout.png'))
    prompts=folder/'prompts';prompts.mkdir(exist_ok=True)
    for name in chains[family]:shutil.copy2(REFERENCE/'paint'/name,prompts/name)
    digest=hashlib.sha256((folder/(family+'-albedo.png')).read_bytes()).hexdigest()
    assert digest==hashlib.sha256((REFERENCE/'paint'/originals[family]).read_bytes()).hexdigest()
    native=[]
    for size in ('160x128','120x96'):
        image=Image.open(folder/(family+'-native-'+size+'.png')).convert('RGBA')
        bounds=image.getchannel('A').getbbox()
        native.append({'file':family+'/'+family+'-native-'+size+'.png','canvas':list(image.size),'subject_bounds':list(bounds),'subject_width':bounds[2]-bounds[0],'resampled':False})
    record['native_previews']=native
    source=Image.open(folder/(family+'-hero.png')).convert('RGBA')
    for extension in ('glb','fbx'):
        imported=Image.open(ROOT/'reimport-checks'/(family+'-'+extension+'.png')).convert('RGBA')
        assert imported.size==source.size
        difference=ImageChops.difference(source,imported)
        record['exports'][extension]['render_mean_absolute_channel_difference_0_255']=[round(v,5) for v in ImageStat.Stat(difference).mean]
    (folder/'manifest.json').write_text(json.dumps(record,indent=2))
    provenance['families'].append({'family':family,'albedo':family+'/'+family+'-albedo.png','sha256':digest,'size':[1254,1254],'color_guide':family+'/'+family+'-color-guide.png','painting_uv_layout':family+'/'+family+'-guide-uv-layout.png','final_uv_layout':family+'/'+family+'-uv-layout.png','prompts':[family+'/prompts/'+name for name in chains[family]]})
(ROOT/'texture-provenance.json').write_text(json.dumps(provenance,indent=2))
(ROOT/'validation.json').write_text(json.dumps(report,indent=2))

turn=Image.new('RGBA',(1840,1140),BG)
label(turn,(24,18),'Asteroid turntable contact proof',30)
label(turn,(24,60),'Blender art previews  |  45 degree increments',20,(174,184,196,255))
for column,angle in enumerate(range(0,360,45)):label(turn,(148+column*210,103),str(angle)+'°',18)
for row,(family,title) in enumerate(FAMILIES):
    y=138+row*195;label(turn,(18,y+78),title,20)
    for column,angle in enumerate(range(0,360,45)):
        fit(turn,subject(ROOT/family/'turntable'/(family+'-'+str(angle).zfill(3)+'.png')),(138+column*210,y,196,175))
turn.convert('RGB').save(ROOT/'asteroid-turntable-proof.png')

checks=Image.new('RGBA',(1260,1200),BG)
label(checks,(26,18),'Export appearance checks',32)
label(checks,(27,61),'Blender previews with the same outer-contour render treatment',20,(174,184,196,255))
for x,title in ((145,'Packed BLEND'),(514,'GLB reimport'),(885,'FBX reimport')):label(checks,(x,104),title,23)
for row,(family,title) in enumerate(FAMILIES):
    top=145+row*208;label(checks,(26,top+87),title)
    paths=[ROOT/family/(family+'-hero.png')]+[ROOT/'reimport-checks'/(family+'-'+extension+'.png') for extension in ('glb','fbx')]
    for col,path in enumerate(paths):fit(checks,subject(path),(140+col*370,top+8,340,184))
checks.convert('RGB').save(ROOT/'asteroid-reimport-checks.png')
print('PACKAGE='+str(ROOT),flush=True)
