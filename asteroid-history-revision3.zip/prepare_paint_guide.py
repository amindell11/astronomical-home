"""Unwrap a selected color-block source and bake its unlit painting guide.
Arguments: --family NAME --source BLEND. Outputs beside the source.
"""
import bpy,bmesh,json,sys
from pathlib import Path

args=sys.argv[sys.argv.index('--')+1:]
family=args[args.index('--family')+1]
source=Path(args[args.index('--source')+1])
out=source.parent
bpy.ops.wm.open_mainfile(filepath=str(source))
bpy.context.preferences.filepaths.save_version=0
body=bpy.data.objects[family.title()+'Surface']
bm=bmesh.new();bm.from_mesh(body.data);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(body.data);bm.free()
for obj in bpy.context.selected_objects:obj.select_set(False)
body.select_set(True)
bpy.context.view_layer.objects.active=body
for uv in list(body.data.uv_layers):body.data.uv_layers.remove(uv)
body.data.uv_layers.new(name='PaintUV')
bpy.ops.object.mode_set(mode='EDIT')
bpy.ops.mesh.select_all(action='SELECT')
bpy.ops.uv.smart_project(angle_limit=.62,island_margin=.022,scale_to_bounds=True)
bpy.ops.object.mode_set(mode='OBJECT')
uv=body.data.uv_layers.active
(out/(family+'-uv-layout.json')).write_text(json.dumps([[list(uv.data[i].uv) for i in face.loop_indices] for face in body.data.polygons]))
bpy.ops.wm.save_as_mainfile(filepath=str(out/(family+'-paint-source.blend')))
image=bpy.data.images.new(family.title()+'UnlitColorGuide',width=2048,height=2048,alpha=False)
image.generated_color=(.32,.32,.40,1)
image.colorspace_settings.name='sRGB'
links=[]
for mat in body.data.materials:
    tree=mat.node_tree
    shader=tree.nodes['Principled BSDF']
    output=next(node for node in tree.nodes if node.type=='OUTPUT_MATERIAL')
    emission=tree.nodes.new('ShaderNodeEmission')
    emission.inputs[0].default_value=shader.inputs['Base Color'].default_value
    tree.links.new(emission.outputs[0],output.inputs[0])
    target=tree.nodes.new('ShaderNodeTexImage')
    target.image=image
    tree.nodes.active=target
    links.append((tree,shader,output,emission,target))
scene=bpy.context.scene
scene.cycles.samples=1
bpy.ops.object.bake(type='EMIT',margin=18,use_clear=False)
image.filepath_raw=str(out/(family+'-color-guide.png'))
image.file_format='PNG'
image.save()
scene.cycles.samples=32
scene.render.filepath=str(out/(family+'-unlit-hero.png'))
bpy.ops.render.render(write_still=True)
for tree,shader,output,emission,target in links:
    tree.links.new(shader.outputs[0],output.inputs[0])
    tree.nodes.remove(emission)
    tree.nodes.remove(target)
print('GUIDE='+str(out/(family+'-color-guide.png')),flush=True)
