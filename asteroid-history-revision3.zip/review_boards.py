"""Compose untouched concept crops and current Blender renders for review."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'review'
OUT.mkdir(exist_ok=True)
REF=Path('D:/amind/scratch/asteroid-locale-concepts-20261106')
FAMILIES=[('copper','1 Copper',(400,138,733,301)),('violet','2 Violet',(400,311,705,481)),('chalk','3 Chalk',(390,490,733,649)),('verdant','6 Verdant',(400,660,714,820)),('ice','7 Ice',(376,833,734,1000))]
BG=(30,38,50,255)
FONT='C:/Windows/Fonts/segoeui.ttf'
def label(canvas,xy,value,size=22,color=(231,232,225,255)):
    ImageDraw.Draw(canvas).text(xy,value,font=ImageFont.truetype(FONT,size),fill=color)
def subject(path):
    image=Image.open(path).convert('RGBA')
    return image.crop(image.getchannel('A').getbbox())
def fit(canvas,image,box):
    x,y,w,h=box;s=min(w/image.width,h/image.height)
    image=image.resize((round(image.width*s),round(image.height*s)),Image.Resampling.LANCZOS)
    canvas.alpha_composite(image,(x+(w-image.width)//2,y+(h-image.height)//2))
concept=Image.open(REF/'asteroids-by-locale.png').convert('RGBA')
board=Image.new('RGBA',(1500,1210),BG)
label(board,(26,18),'Locale asteroids: reference, shape and ink',32)
label(board,(27,61),'Blender art previews',20,(174,184,196,255))
for x,title in ((150,'Approved concept'),(514,'Revision 2'),(878,'Revision 3'),(1245,'Native 160 × 128')):label(board,(x,104),title,22)
for row,(family,title,crop) in enumerate(FAMILIES):
    top=145+row*208;folder=ROOT/(family+'-reference')
    label(board,(26,top+87),title)
    fit(board,concept.crop(crop),(145,top+8,340,184))
    fit(board,subject(REF/'art-proof-revision2'/family/(family+'-hero.png')),(509,top+8,340,184))
    fit(board,subject(folder/(family+'-painted-hero.png')),(873,top+8,340,184))
    native=Image.open(folder/(family+'-painted-native.png')).convert('RGBA')
    assert native.size==(160,128)
    board.alpha_composite(native,(1260,top+40))
    ImageDraw.Draw(board).line((24,top+205,1474,top+205),fill=(66,76,90,255))
board.convert('RGB').save(OUT/'asteroid-before-after.png')

sheet=Image.new('RGBA',(1580,970),BG)
label(sheet,(26,20),'Locale asteroid meshes',32)
label(sheet,(27,66),'Revision 3  |  Blender art proof  |  Fitted graphite and weighted outer ink',20,(174,184,196,255))
for column,(family,title,_) in enumerate(FAMILIES):
    x=20+column*312;folder=ROOT/(family+'-reference')
    label(sheet,(x+8,120),title,24)
    fit(sheet,subject(folder/(family+'-painted-hero.png')),(x,170,294,260))
    for sub,view in enumerate(('reverse','side')):
        fit(sheet,subject(folder/(family+'-painted-'+view+'.png')),(x+sub*154,465,140,140))
        label(sheet,(x+sub*154+3,633),view.capitalize(),17,(174,184,196,255))
    native=Image.open(folder/(family+'-painted-native.png')).convert('RGBA')
    sheet.alpha_composite(native,(x+64,720))
    label(sheet,(x+37,868),'Native 160 × 128 canvas',18,(174,184,196,255))
sheet.convert('RGB').save(OUT/'asteroid-mesh-proof-sheet.png')
print('REVIEW='+str(OUT),flush=True)
