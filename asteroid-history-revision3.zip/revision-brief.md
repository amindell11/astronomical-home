## What did the owner reject in revision 2?

The owner said: "these are improving but still pretty far off, and you dropped the hand drawn outlines".

The previous proof lost the bold drawn contour and selected internal fracture marks of the approved concepts. UV fit improved, but orderly slabs, the violet cavity, the green exposure and the ice silhouette remain too far from the reference.

## What changes in the next proof?

Keep the same five locale families. Restore visible dark hand-drawn contours with varied weight and selected structural fracture lines. Correct the rock proportions, chipped edges, overlapping layers and embedded mineral masses against the approved concept sheet. Compare the actual mesh renders with that sheet at large and game size before publishing.

Work remains an art proof. No runtime integration or non-asteroid debris. Any outlines that depend on a render setup must be called out; the review cannot imply those are exported material features.

## How will the revision be judged?

The visible result must carry its outlines and fractured massing. File integrity alone is insufficient. Keep the accepted concept beside each preview and use a focused visual review before packaging. Preserve the previous proof separately.
