"""Reopen selected sources and verify/render actual surface+Drawing reimports.
Optional --family NAME limits the pass. Any failed invariant exits nonzero.
"""
import bpy,bmesh,math,json,struct,hashlib,sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent/'deliverables'
ALL=('copper','violet','chalk','verdant','ice')
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
families=[args[args.index('--family')+1]] if '--family' in args else ALL
path=ROOT/'validation.json'
records={f['family']:f for f in json.loads(path.read_text())['families']} if path.exists() else {}
checks=ROOT/'reimport-checks';checks.mkdir(exist_ok=True)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def mesh_info(obj):
    mesh=obj.data;mesh.calc_loop_triangles()
    assert mesh.vertices and mesh.polygons,obj.name
    assert all(math.isfinite(c) for vertex in mesh.vertices for c in vertex.co),obj.name
    areas=[]
    for triangle in mesh.loop_triangles:
        a,b,c=[mesh.vertices[i].co for i in triangle.vertices]
        areas.append((b-a).cross(c-a).length*.5)
    assert min(areas)>1e-10,(obj.name,'collapsed triangle',min(areas))
    assert not mesh.color_attributes,obj.name
    return {'vertices':len(mesh.vertices),'triangles':len(mesh.loop_triangles),'minimum_triangle_area':min(areas),'materials':len(mesh.materials),'uv_layers':len(mesh.uv_layers)}
def albedo(body):
    assert len(body.data.materials)==1
    shader=body.data.materials[0].node_tree.nodes.get('Principled BSDF')
    assert shader.inputs['Base Color'].is_linked
    node=shader.inputs['Base Color'].links[0].from_node
    assert node.type=='TEX_IMAGE'
    return node.image
for family in families:
    folder=ROOT/family;source=folder/(family+'.blend');png=folder/(family+'-albedo.png')
    bpy.ops.wm.open_mainfile(filepath=str(source))
    meshes=[o for o in bpy.context.scene.objects if o.type=='MESH']
    expected={family.title()+'Surface',family.title()+'Drawing'}
    assert {o.name for o in meshes}==expected
    assert all(o.get('art_proof') and not o.get('preview_only') for o in meshes)
    stats={o.name:mesh_info(o) for o in meshes}
    body=bpy.data.objects[family.title()+'Surface']
    bm=bmesh.new();bm.from_mesh(body.data)
    topology={'boundary_edges':sum(edge.is_boundary for edge in bm.edges),'nonmanifold_edges':sum(not edge.is_manifold for edge in bm.edges)}
    bm.free()
    image=albedo(body)
    assert len(body.data.uv_layers)==1
    assert all(math.isfinite(c) for item in body.data.uv_layers.active.data for c in item.uv)
    uv=body.data.uv_layers.active
    (folder/(family+'-uv-layout.json')).write_text(json.dumps([[list(uv.data[i].uv) for i in face.loop_indices] for face in body.data.polygons]))
    assert image.packed_file and image.filepath=='//'+png.name
    assert len([i for i in bpy.data.images if i.source=='FILE'])==1
    assert len(bpy.data.materials)==2
    assert Path(bpy.path.abspath(image.filepath)).is_file()
    components={group.name:sum(any(m.group==group.index and m.weight>.5 for m in vertex.groups) for vertex in body.data.vertices) for group in body.vertex_groups}
    if family=='violet':assert all(components['AmethystFace'+str(i)]>0 for i in range(1,5))
    if family=='ice':assert all(components['EmbeddedStone'+str(i)]>0 for i in range(1,5))
    if family=='verdant':assert all(components['CreamRind'+str(i)]>0 for i in range(1,3))
    image_size=list(image.size)
    record={'family':family,'locale':{'copper':1,'violet':2,'chalk':3,'verdant':6,'ice':7}[family],'source_reopened':True,'source_sha256':digest(source),'albedo_sha256':digest(png),'albedo_size':image_size,'packed_relative_albedo':True,'direct_image_material':True,'vertex_color_multiplication':False,'objects':stats,'surface_topology':topology,'component_vertex_groups':components,'exports':{}}
    if family=='chalk':record['uv_note']='The added ledge wall samples an existing slate region; the painted islands are preserved.'
    for extension in ('glb','fbx'):
        exported=folder/(family+'.'+extension)
        if extension=='glb':
            raw=exported.read_bytes();assert raw[:4]==b'glTF'
            size=struct.unpack('<I',raw[12:16])[0];data=json.loads(raw[20:20+size])
            assert {node['name'] for node in data['nodes']}==expected
            assert 'cameras' not in data and 'KHR_lights_punctual' not in data.get('extensions',{})
            assert len(data['images'])==1 and 'bufferView' in data['images'][0]
            for mesh in data['meshes']:
                for primitive in mesh['primitives']:assert 'COLOR_0' not in primitive['attributes']
            view=data['bufferViews'][data['images'][0]['bufferView']]
            start=20+size+8+view.get('byteOffset',0)
            assert hashlib.sha256(raw[start:start+view['byteLength']]).hexdigest()==record['albedo_sha256']
        bpy.ops.wm.open_mainfile(filepath=str(source))
        for obj in list(bpy.context.scene.objects):
            if obj.type=='MESH':bpy.data.objects.remove(obj,do_unlink=True)
        before=set(bpy.context.scene.objects)
        if extension=='glb':bpy.ops.import_scene.gltf(filepath=str(exported))
        else:bpy.ops.import_scene.fbx(filepath=str(exported))
        imported=[o for o in bpy.context.scene.objects if o not in before]
        assert {o.name for o in imported}==expected and all(o.type=='MESH' for o in imported)
        for obj in imported:assert mesh_info(obj)['triangles']==stats[obj.name]['triangles']
        assert list(albedo(bpy.data.objects[family.title()+'Surface']).size)==image_size
        scene=bpy.context.scene;scene.render.filepath=str(checks/(family+'-'+extension+'.png'))
        bpy.ops.render.render(write_still=True)
        record['exports'][extension]={'reimported':True,'surface_and_drawing_present':True,'nondegenerate_triangles':True,'sha256':digest(exported),'bytes':exported.stat().st_size,'reimport_render':'reimport-checks/'+family+'-'+extension+'.png'}
    (folder/'manifest.json').write_text(json.dumps(record,indent=2));records[family]=record
    current=all(name in records and (ROOT/name/(name+'.blend')).is_file() and records[name]['source_sha256']==digest(ROOT/name/(name+'.blend')) for name in ALL)
    report={'verdict':'PASS' if current else 'IN_PROGRESS','blender':bpy.app.version_string,'families':[records[name] for name in ALL if name in records],'scope':'Blender art proof. No Unity integration or gameplay collision/volume data.','outline':'Persistent fitted Drawing mesh is exported. Outer contour is Blender Freestyle and requires the existing runtime DrawnContour treatment in Unity.'}
    path.write_text(json.dumps(report,indent=2));print('VERIFIED='+family,flush=True)
print('VALIDATION='+str(path),flush=True)
