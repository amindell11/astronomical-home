"""Compose FAMILY-board.png from the five documented model previews and reference."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import sys,json
SET=Path(__file__).resolve().parents[1];family=sys.argv[1]
names={'copper':'Locale 1, Copper / turquoise','violet':'Locale 2, Violet nebula','chalk':'Locale 3, Illustrated blue / Chalk','verdant':'Locale 6, Verdant Giant','ice':'Locale 7, Blue Crescent / Ice'}
font=ImageFont.truetype('C:/Windows/Fonts/segoeui.ttf',26);small=ImageFont.truetype('C:/Windows/Fonts/segoeui.ttf',19)
board=Image.new('RGB',(1800,1120),(39,46,58));draw=ImageDraw.Draw(board);draw.text((26,17),names[family]+' | five bespoke Blender models',font=font,fill=(236,239,235))
for i in range(1,6):
    x=((i-1)%3)*600;y=55+((i-1)//3)*530;ident=f'{family}-{i:02d}';folder=SET/family/ident;meta=json.loads((folder/'model.json').read_text())
    hero=Image.open(folder/(ident+'-hero.png')).convert('RGBA');hero=hero.resize((570,392),Image.Resampling.LANCZOS);board.paste(hero,(x+15,y),hero)
    draw.text((x+26,y+390),ident+'  '+meta['name'],font=small,fill=(236,237,233))
    native=Image.open(folder/(ident+'-150.png')).convert('RGBA');board.paste(native,(x+25,y+420),native)
    draw.text((x+195,y+457),'Native 150 px canvas',font=small,fill=(184,196,210))
x,y=1200,585;ref=Image.open(SET/'references'/('reference-'+family+'.png')).convert('RGB');ref.thumbnail((525,330),Image.Resampling.LANCZOS);ref=ref.resize((525,round(ref.height*525/ref.width)),Image.Resampling.LANCZOS);board.paste(ref,(x+35,y+75))
draw.text((x+35,y+25),'Original approved concept',font=font,fill=(236,237,233));draw.text((x+35,y+420),'Actual models shown at matched camera scale.',font=small,fill=(184,196,210));draw.text((x+35,y+452),'Outer contour is a Blender preview treatment.',font=small,fill=(184,196,210))
output=SET/family/(family+'-board.png');board.save(output);print(str(output))
