"""Compose the five-by-five review overview from selected hero renders."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parents[1]
families=[('copper','1  Copper / turquoise'),('violet','2  Violet nebula'),('chalk','3  Illustrated blue / Chalk'),('verdant','6  Verdant Giant'),('ice','7  Blue Crescent / Ice')]
font=ImageFont.truetype('C:/Windows/Fonts/segoeui.ttf',25);small=ImageFont.truetype('C:/Windows/Fonts/segoeui.ttf',19)
board=Image.new('RGB',(1800,1580),(39,46,58));draw=ImageDraw.Draw(board)
draw.text((26,14),'25 bespoke asteroids | actual Blender art previews',font=font,fill=(238,239,235))
for row,(family,label) in enumerate(families):
    y=62+row*298;draw.text((24,y),label,font=small,fill=(220,227,232))
    for index in range(1,6):
        ident=f'{family}-{index:02d}';folder=ROOT/family/ident;x=(index-1)*360
        render=Image.open(folder/(ident+'-hero.png')).convert('RGBA');render.thumbnail((352,242),Image.Resampling.LANCZOS)
        board.paste(render,(x+4,y+27),render);draw.text((x+22,y+267),ident+('  accepted' if index==1 and family in ('copper','violet') else ''),font=small,fill=(221,229,232))
draw.text((26,1550),'Five per locale. Outer contour is a Blender render treatment; internal ink is retained mesh geometry.',font=small,fill=(181,195,208))
output=ROOT/'asteroid-set-overview.png';board.save(output);print(output)
