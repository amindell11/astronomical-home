from art_common import Model
from models_copper import foot
PALETTE=[('Blue gray slate','slate-paint.png',.35,.76,(.89,.97,1.03)),('Chalk stratum','chalk-paint.png',.82,.72,(1,.94,.83))]
def chalk01():
    m=Model('chalk',1,'Broken chalk fan','Three unequal broad layers fan outward at different angles, exposing cream tops and slate fracture sides with a short broken rear plate.',PALETTE)
    top=[(-2.59,-.57,-.18),(-1.77,-1.10,-.06),(-.49,-1.26,-.10),(.94,-.94,.00),(2.12,-.32,.11),(1.77,.35,.18),(.34,.70,.09),(-1.95,.43,-.04)]
    m.slab('Flared lower fan',top,foot(top,-.63,dx=-.06,taper=.92),top_material=[1,0,0],side_materials={1:1})
    top=[(-2.13,-.41,.16),(-1.26,-.72,.38),(.01,-.61,.43),(1.48,-.14,.58),(2.41,.40,.63),(2.05,.85,.71),(.39,1.03,.54),(-1.70,.71,.39)]
    m.slab('Broad staggered middle stratum',top,foot(top,-.24,dx=-.15,dy=.02,taper=.91),top_material=[1,1,0],side_materials={1:1,3:1})
    top=[(-1.32,.08,.61),(-.51,-.14,.78),(.67,.04,.86),(1.56,.40,.93),(1.36,.92,.99),(.40,1.16,.88),(-.73,1.05,.77),(-1.56,.57,.59)]
    m.slab('Short high broken plate',top,foot(top,.09,dx=-.19,taper=.88),top_material=[0,0,1],side_materials={4:1})
    m.fuse()
    m.cut('Fan left oblique end',(-2.28,-.41,-.12),(.06,.58,.03),(.17,.06,.58),(-1,-.03,.02))
    m.cut('Middle stratum broken right end',(2.11,.47,.27),(.05,.49,.05),(.16,-.05,.64),(1,0,.04),1)
    m.cut('Upper rear uneven break',(.69,1.03,.59),(.62,.04,.03),(.13,-.07,.46),(0,1,.02))
    m.skins([1])
    for i,a in enumerate([(-1.66,-.47,.13),(-.63,-.61,.37),(.65,-.83,-.04),(1.83,.21,.46),(-.54,.97,.63)]):m.stroke('Drawing_Stratum_'+str(i+1),a,.011)
    m.path_stroke('Drawing_MiddleFracture',[(-.91,.43,.50),(-.66,.18,.54),(-.74,-.21,.45),(-.85,-.66,.30),(-.92,-.62,.02)],.009)
    m.path_stroke('Drawing_UpperFracture',[(.70,.75,.94),(.45,.52,.87),(.56,.10,.82),(.43,-.04,.58)],.009)
    return m
def chalk02():
    m=Model('chalk',2,'Long stepped chalk tablet','Two broad unequal strata form a long low tablet; the upper layer shifts back and right, exposing a wide pale left-front ledge.',PALETTE)
    top=[(-2.61,-.44,.02),(-1.93,-.92,.14),(-.52,-1.05,.21),(.96,-.82,.29),(2.32,-.32,.39),(2.43,.34,.41),(1.04,.83,.32),(-1.97,.68,.23)]
    m.slab('Long lower chalk stratum',top,foot(top,-.58,dx=-.08,taper=.92),top_material=[1,0,0],side_materials={0:1,2:1})
    top=[(-1.68,.03,.55),(-.92,-.38,.69),(.37,-.24,.72),(1.61,.18,.86),(2.18,.63,.91),(1.59,1.04,.93),(.11,1.10,.78),(-1.65,.68,.67)]
    m.slab('Offset upper tablet',top,foot(top,.02,dx=-.22,dy=.04,taper=.90),top_material=[0,1,1],side_materials={3:1,5:1})
    m.fuse()
    m.cut('Low tablet left fracture',(-2.37,-.27,-.05),(.05,.55,.05),(.16,.05,.57),(-1,0,.03),1)
    m.cut('Upper tablet broken nose',(1.98,.59,.53),(.05,.46,.07),(.11,-.05,.61),(1,.04,0))
    m.cut('Long front oblique bevel',(.79,-.86,.02),(.77,.18,.02),(.10,.13,.47),(0,-1,.05))
    m.skins([1])
    for i,a in enumerate([(-1.65,-.68,.15),(-.48,-.25,.58),(1.53,.10,.67),(2.06,.38,.42),(-.84,.91,.63)]):m.stroke('Drawing_Stratum_'+str(i+1),a,.010)
    m.path_stroke('Drawing_UpperCrack',[(.23,.75,.81),(.48,.48,.81),(.32,.10,.72),(.43,-.19,.57),(.31,-.21,.28)],.009)
    return m
def chalk03():
    m=Model('chalk',3,'Split chalk ridge','Two canted chalk ridges meet across an oblique break above one thick irregular slate footing; the pale faces cross the exposed wall.',PALETTE)
    top=[(-2.04,-.51,.04),(-1.31,-1.03,.16),(-.38,-1.13,.09),(.67,-.91,.12),(1.91,-.41,.27),(1.94,.31,.34),(.63,.85,.30),(-1.63,.62,.24)]
    m.slab('Wide split-ridge footing',top,foot(top,-.65,dx=-.06,taper=.90),top_material=[0,1,0],side_materials={1:1,5:1})
    top=[(-1.77,-.22,.56),(-1.11,-.57,.77),(-.41,-.30,.89),(-.08,.34,1.05),(-.54,.99,.99),(-1.25,1.05,.80),(-1.88,.61,.60)]
    m.slab('Canted left chalk ridge',top,foot(top,-.13,dx=-.22,taper=.85),top_material=[1,0,0],side_materials={0:1,5:1})
    top=[(-.25,-.55,.23),(.48,-.81,.39),(1.42,-.44,.61),(2.12,.07,.71),(1.89,.65,.82),(1.14,1.01,.84),(.35,.74,.66),(-.27,.10,.40)]
    m.slab('Lower right chalk ridge',top,foot(top,-.23,dx=-.12,taper=.87),top_material=[0,1,1],side_materials={2:1,4:1})
    m.fuse()
    m.cut('Left ridge broad side break',(-1.77,.18,.33),(.04,.53,.06),(.15,.05,.62),(-1,0,.03))
    m.cut('Right ridge diagonal end',(1.87,.22,.30),(.05,.48,.05),(.17,-.05,.65),(1,0,.02),1)
    m.skins([1])
    for i,a in enumerate([(-.68,-.37,.62),(.42,-.67,.31),(1.63,-.14,.43),(-1.50,-.49,.23),(.51,.79,.58)]):m.stroke('Drawing_Stratum_'+str(i+1),a,.011)
    m.path_stroke('Drawing_LeftRidgeCrack',[(-1.14,.57,.87),(-.91,.28,.88),(-1.02,-.22,.79),(-1.11,-.56,.55),(-1.23,-.52,.21)],.009)
    return m
def chalk04():
    m=Model('chalk',4,'Canted chalk stack','Compact steeply canted strata rise toward a blunt right shoulder; unequal pale overhangs and a broad slate center interrupt the stacked profile.',PALETTE)
    top=[(-1.81,-.57,-.13),(-1.16,-1.06,-.02),(-.27,-1.01,.12),(.69,-.73,.29),(1.70,-.17,.49),(1.60,.50,.52),(.43,.92,.37),(-1.51,.53,.09)]
    m.slab('Low canted foundation',top,foot(top,-.66,dx=-.04,taper=.88),top_material=[1,1,0],side_materials={0:1,2:1})
    top=[(-1.60,-.11,.32),(-.92,-.57,.48),(-.02,-.49,.70),(.99,-.02,.96),(1.68,.51,1.09),(1.25,1.03,1.15),(.15,1.16,.91),(-1.50,.66,.52)]
    m.slab('Broad sloping middle plate',top,foot(top,-.16,dx=-.16,taper=.87),top_material=[0,1,0],side_materials={3:1,5:1})
    top=[(-.51,.21,.76),(.09,-.01,.91),(.86,.29,1.18),(1.33,.68,1.26),(1.05,1.08,1.30),(.27,1.22,1.12),(-.61,.86,.87)]
    m.slab('Short high chalk shoulder',top,foot(top,.36,dx=-.12,taper=.86),top_material=[1,0,1],side_materials={1:1})
    m.fuse()
    m.cut('Canted left exterior fracture',(-1.55,-.07,.13),(.04,.57,.04),(.19,.03,.58),(-1,0,.02),1)
    m.cut('Blunt raised right end',(1.43,.61,.61),(.04,.47,.04),(.18,-.05,.75),(1,0,.03))
    m.skins([1])
    for i,a in enumerate([(-.91,-.49,.33),(.29,-.30,.68),(1.18,.30,.84),(-.38,.91,.74),(.34,-.87,.13)]):m.stroke('Drawing_Stratum_'+str(i+1),a,.011)
    m.path_stroke('Drawing_CantedCrack',[(.20,.62,1.0),(.41,.39,1.06),(.28,.06,.94),(.16,-.14,.74),(.02,-.27,.41)],.009)
    return m
def chalk05():
    m=Model('chalk',5,'Thin broken chalk flake','Thin shale flake with half-height strata and a missing oblique upper-left end that exposes a large wedge of the lower plate.',PALETTE)
    top=[(-2.62,-.31,-.02),(-1.83,-.70,.10),(-.48,-.72,.16),(1.02,-.44,.30),(2.39,-.02,.42),(2.47,.43,.45),(1.03,.76,.35),(-2.11,.48,.18)]
    m.slab('Long shale lower blade',top,foot(top,-.54,dx=-.09,taper=.91),top_material=[1,0,1],side_materials={0:1,2:1})
    top=[(-1.96,-.02,.41),(-1.14,-.35,.60),(.17,-.23,.68),(1.47,.20,.82),(2.00,.63,.89),(1.28,.91,.93),(-.11,.93,.77),(-1.99,.51,.55)]
    upper=m.slab('Narrow shifted upper blade',top,foot(top,-.02,dx=-.21,taper=.89),top_material=[0,1,1],side_materials={3:1})
    m.body=upper
    m.cut('Missing oblique upper end',(-1.25,.30,.40),(.35,.90,0),(.12,0,1),(-2,0,.03))
    m.fuse()
    m.cut('Diagonal shale broken left end',(-2.27,-.05,.10),(.10,.48,.03),(.25,.04,.57),(-1,-.04,.03))
    m.cut('Unequal upper blade end',(1.81,.54,.51),(.04,.42,.04),(.15,-.05,.57),(1,0,.03),1)
    m.cut('Rear shale fracture',(.45,.85,.48),(.70,.04,.03),(.11,-.06,.50),(0,1,.03))
    m.skins([1])
    for i,a in enumerate([(-1.66,-.34,.32),(-.49,-.27,.58),(.70,-.55,.18),(1.66,.41,.61),(-.70,.73,.57)]):m.stroke('Drawing_Stratum_'+str(i+1),a,.010)
    m.path_stroke('Drawing_ShaleCrack',[(-.75,.50,.69),(-.51,.28,.70),(-.69,-.11,.62),(-.81,-.40,.39),(-.94,-.44,.11)],.009)
    for obj in list(m.parts.objects)+list(m.author.objects):
        if obj.type=='MESH':
            for vertex in obj.data.vertices:vertex.co.z*=.52
            obj.data.update()
    return m
BUILDERS={1:chalk01,2:chalk02,3:chalk03,4:chalk04,5:chalk05}
