from art_common import Model
from models_copper import foot
PALETTE=[('Slate','slate-paint.png',.72,.68),('Amethyst','violet-crystal-paint.png',1,1),('Warm mineral','chalk-paint.png',.85,.70,(1,.68,.28))]
def violet02():
    m=Model('violet',2,'Split amethyst spine','Tall asymmetric left spine and heavy rear shoulder enclose a narrow crystal-filled cleft above an uneven low jaw.',PALETTE)
    top=[(-2.00,-.45,.55),(-1.41,-.85,.84),(-.77,-.69,1.17),(-.46,-.02,1.35),(-.68,.88,1.25),(-1.25,1.10,1.05),(-2.02,.69,.76),(-2.24,.09,.51)]
    m.slab('Tall split left spine',top,foot(top,-.62,dx=.04,dy=.09,taper=.81))
    top=[(-.70,.17,.65),(.02,.18,.74),(.88,.17,.64),(1.63,.41,.56),(1.93,.83,.63),(1.27,1.19,.91),(.16,1.23,1.16),(-.68,.90,1.19)]
    m.slab('Heavy diagonal back shoulder',top,foot(top,-.57,dx=-.02,taper=.90))
    top=[(-1.37,-.80,-.24),(-.64,-1.12,-.19),(.19,-1.02,-.30),(.95,-.70,-.23),(1.79,-.18,-.08),(1.68,.39,.08),(.69,.55,-.10),(-.86,.35,-.12)]
    m.slab('Unequal root jaw',top,foot(top,-.79,dx=-.05,taper=.91))
    top=[(1.07,-.49,.06),(1.62,-.33,.25),(2.08,.08,.43),(2.00,.68,.54),(1.44,.85,.56),(.95,.29,.34)]
    m.slab('Broken right pocket end',top,foot(top,-.45,dx=.04,taper=.84))
    m.fuse()
    m.cut('Left shoulder slanted plane',(-1.92,-.35,.29),(.05,.48,.08),(-.11,.04,.64),(-1,-.05,0))
    m.cut('Unequal rear ridge break',(.61,1.12,.62),(.64,.05,.08),(.12,-.05,.56),(0,1,.06))
    m.cut('Right open fracture end',(1.91,.19,.10),(.03,.42,.05),(.13,-.05,.53),(1,0,0))
    main=m.crystal('Crystal_Main',(.02,-.48,.15),.96,.73,1.19,(.10,-.18,.19))
    left=m.crystal('Crystal_Left',(-.58,-.60,-.05),.74,.66,.80,(.18,.25,-.33))
    right=m.crystal('Crystal_Right',(.72,-.27,.04),.81,.62,.89,(-.09,-.33,.42))
    fragment=m.crystal('Crystal_Fragment',(1.14,.06,.21),.42,.39,.47,(.15,.18,-.25),clipped=False)
    for crystal in (right,fragment):
        crystal.data.vertices[3].co.y+=.20;crystal.data.vertices[3].co.z-=.12;crystal.data.update()
    m.crystal_accent(main,2);m.crystal_accent(left,1)
    for i,(a,w) in enumerate([((-1.03,-.39,.95),.18),((.11,.20,.79),.17),((1.40,.49,.52),.17)]):m.patch('WarmDeposit_'+str(i+1),a,w,2)
    for i,a in enumerate([(-1.08,-.64,.47),(-.48,.12,.62),(.91,.17,.41),(1.62,-.25,.17),(-.50,-.92,-.25),(.77,1.0,.78)]):m.stroke('Drawing_Fracture_'+str(i+1),a,.011)
    m.path_stroke('Drawing_SpineCrack',[(-1.44,.49,1.02),(-1.20,.16,1.11),(-1.25,-.38,.98),(-1.49,-.71,.63)])
    return m
def violet03():
    m=Model('violet',3,'Flat broken amethyst jaw','Wide low host with a shallow overhanging left roof, broken front jaw and three broad short crystals clustered toward the right.',PALETTE)
    top=[(-2.38,-.35,.26),(-1.73,-.72,.43),(-.77,-.56,.57),(.13,-.05,.69),(.16,.69,.77),(-.78,1.02,.75),(-1.98,.79,.56),(-2.53,.14,.31)]
    m.slab('Low broad left roof',top,foot(top,-.38,dx=-.10,dy=.12,taper=.88))
    top=[(-.36,.18,.25),(.48,.08,.36),(1.42,.35,.49),(2.28,.65,.60),(2.20,1.02,.67),(1.27,1.16,.75),(.20,1.12,.76),(-.65,.71,.62)]
    m.slab('Uneven rear jaw',top,foot(top,-.50,dx=-.04,taper=.89))
    top=[(-1.62,-.61,-.20),(-.78,-1.12,-.19),(.03,-1.05,-.32),(.83,-.80,-.25),(1.99,-.22,-.12),(2.18,.41,.07),(1.01,.69,.05),(-1.12,.35,-.12)]
    m.slab('Long rooted lower jaw',top,foot(top,-.72,dx=-.04,taper=.93))
    top=[(1.51,-.27,-.02),(2.14,-.05,.18),(2.50,.34,.35),(2.27,.83,.52),(1.74,.91,.50),(1.39,.37,.24)]
    m.slab('Clipped right jaw end',top,foot(top,-.48,dx=.03,taper=.84))
    m.fuse()
    m.cut('Left diagonal roof break',(-1.85,-.46,.28),(.52,.14,.05),(.09,.07,.40),(0,-1.2,.03))
    m.cut('Right corner fracture',(2.25,.23,.12),(.06,.45,.06),(.11,-.06,.50),(1,0,.02))
    m.cut('Rear uneven plane',(.56,1.07,.27),(.62,.05,.05),(.13,-.06,.48),(0,1,.04))
    main=m.crystal('Crystal_Main',(.56,-.48,-.04),1.10,.78,.86,(.28,-.21,.30))
    left=m.crystal('Crystal_Left',(-.20,-.65,-.20),.82,.63,.57,(.20,.29,-.41))
    m.crystal('Crystal_Right',(1.20,-.10,.05),.77,.62,.71,(-.10,-.31,.48))
    m.crystal_accent(main,2);m.crystal_accent(left,1)
    for i,(a,w) in enumerate([((-1.05,-.30,.53),.18),((.13,.22,.52),.15),((1.75,.42,.37),.16)]):m.patch('WarmDeposit_'+str(i+1),a,w,2)
    for i,a in enumerate([(-1.47,-.44,.35),(-.23,-.01,.43),(1.61,.24,.24),(-.53,-.95,-.20),(.76,1.02,.53)]):m.stroke('Drawing_Fracture_'+str(i+1),a,.011)
    m.path_stroke('Drawing_RoofCrack',[(-1.62,.42,.55),(-1.30,.24,.61),(-1.19,-.20,.57),(-1.42,-.56,.36)])
    return m
def violet04():
    m=Model('violet',4,'Offset amethyst ridges','Two offset angular roof ridges enclose a diagonal exposure; a dominant broad crystal leans across the opening with smaller buried supports.',PALETTE)
    top=[(-1.98,-.53,.49),(-1.29,-.82,.71),(-.56,-.48,.96),(-.45,.30,1.08),(-.96,.98,.97),(-1.68,1.02,.81),(-2.11,.50,.54)]
    m.slab('Left offset ridge',top,foot(top,-.57,dx=.03,taper=.85))
    top=[(-.24,.18,.67),(.45,-.08,.85),(1.30,.10,1.02),(1.91,.53,1.05),(1.70,1.08,.94),(.81,1.32,.90),(-.07,.93,.88)]
    m.slab('High right rear ridge',top,foot(top,-.46,dx=-.04,taper=.84))
    top=[(-1.23,-.78,-.23),(-.49,-1.15,-.19),(.36,-1.04,-.22),(1.29,-.65,-.06),(1.82,-.16,.15),(1.39,.53,.26),(.42,.68,.02),(-.94,.29,-.11)]
    m.slab('Diagonal low root bridge',top,foot(top,-.75,dx=-.03,taper=.92))
    top=[(.98,-.72,.07),(1.63,-.58,.29),(2.11,-.13,.53),(1.94,.47,.67),(1.41,.61,.58),(.93,.15,.36)]
    m.slab('Short forward right shoulder',top,foot(top,-.43,dx=.01,taper=.86))
    m.fuse()
    m.cut('Left ridge outer break',(-1.80,-.14,.27),(.03,.46,.04),(.13,.04,.63),(-1,0,.02))
    m.cut('High ridge uneven end',(1.72,.80,.59),(.03,.42,.03),(.10,-.05,.62),(1,.1,0))
    main=m.crystal('Crystal_Main',(.12,-.45,.13),1.05,.76,1.10,(.18,.25,-.32))
    left=m.crystal('Crystal_Left',(-.54,-.62,-.10),.75,.64,.70,(.12,-.26,.37))
    m.crystal('Crystal_Right',(.82,-.27,.11),.68,.58,.83,(-.12,-.36,.15))
    m.crystal('Crystal_Fragment',(.56,.13,.38),.38,.40,.47,(.16,.23,-.13),clipped=False)
    m.crystal_accent(main,2);m.crystal_accent(left,1)
    for i,(a,w) in enumerate([((-1.17,-.32,.77),.17),((.34,.12,.80),.19),((1.47,.29,.54),.16)]):m.patch('WarmDeposit_'+str(i+1),a,w,2)
    for i,a in enumerate([(-.79,-.49,.50),(.15,.19,.63),(1.37,-.34,.31),(-.45,-.96,-.22),(.96,1.16,.77)]):m.stroke('Drawing_Fracture_'+str(i+1),a,.011)
    m.path_stroke('Drawing_LeftRidgeCrack',[(-1.52,.53,.85),(-1.22,.25,.90),(-1.34,-.22,.81),(-1.47,-.62,.51)])
    m.path_stroke('Drawing_RightRidgeCrack',[(1.16,.73,1.0),(.96,.44,1.0),(1.05,.15,.95),(1.17,.08,.65)],.009)
    return m
def violet05():
    m=Model('violet',5,'Side-pocket amethyst shard','Long narrow slate shard carries one compact side opening near its broken right end; two stout crystals emerge sideways beneath the roof.',PALETTE)
    top=[(-2.42,-.28,.32),(-1.82,-.61,.54),(-.61,-.50,.69),(.44,-.17,.73),(.61,.44,.85),(-.29,.86,.82),(-1.58,.78,.67),(-2.53,.25,.42)]
    m.slab('Long angular slate spine',top,foot(top,-.54,dx=-.12,taper=.89))
    top=[(.12,.10,.37),(.86,.03,.49),(1.59,.15,.70),(2.26,.49,.82),(2.18,.91,.89),(1.42,1.04,.93),(.57,.85,.91),(-.10,.53,.66)]
    m.slab('Heavy pocket roof',top,foot(top,-.31,dx=-.03,taper=.88))
    top=[(-.13,-.43,-.22),(.66,-.84,-.19),(1.56,-.63,-.11),(2.24,-.16,.05),(2.40,.42,.30),(1.69,.77,.39),(.80,.57,.15),(.06,.11,-.04)]
    m.slab('Broken end root ledge',top,foot(top,-.65,dx=-.03,taper=.89))
    m.fuse()
    m.cut('Open blunt left end',(-2.27,-.07,.07),(.04,.43,.03),(.12,.04,.61),(-1,0,.03))
    m.cut('Pocket right corner',(2.20,.36,.25),(.05,.47,.03),(.12,-.05,.56),(1,0,.03))
    main=m.crystal('Crystal_Main',(1.13,-.42,.13),.91,.72,.97,(.25,-.35,.36))
    small=m.crystal('Crystal_Support',(.54,-.50,-.05),.67,.56,.66,(.14,.24,-.28))
    m.crystal('Crystal_Fragment',(1.70,-.02,.24),.38,.40,.48,(.12,-.27,.14),clipped=False)
    m.crystal_accent(main,2);m.crystal_accent(small,1)
    for i,(a,w) in enumerate([((.52,.08,.58),.19),((1.56,.21,.70),.17)]):m.patch('WarmDeposit_'+str(i+1),a,w,2)
    for i,a in enumerate([(-1.65,-.34,.35),(-.22,-.33,.48),(.66,.04,.48),(1.92,.07,.27),(1.12,-.64,-.08)]):m.stroke('Drawing_Fracture_'+str(i+1),a,.011)
    m.path_stroke('Drawing_SpineCrack',[(-1.38,.40,.70),(-1.10,.14,.72),(-1.25,-.27,.64),(-1.40,-.54,.34)])
    return m
BUILDERS={2:violet02,3:violet03,4:violet04,5:violet05}
