"""Render an immutable accepted source into set preview names; never saves the .blend."""
import bpy,sys,json,hashlib
from pathlib import Path
from mathutils import Vector
SET=Path(__file__).resolve().parents[1];family=sys.argv[sys.argv.index('--')+1];ident=family+'-01';out=SET/family/ident
source=out/('copper-painted.blend' if family=='copper' else 'violet-painted.blend');before=hashlib.sha256(source.read_bytes()).hexdigest()
bpy.ops.wm.open_mainfile(filepath=str(source));scene=bpy.context.scene
view=(-1.8,-9,5.1) if family=='copper' else (-3,-8,4.18);target=(.05,0,.12) if family=='copper' else (0,0,.12);scale=6.35 if family=='copper' else 5.4
scene.render.resolution_x=640;scene.render.resolution_y=440;scene.cycles.samples=32
def aim(direction):scene.camera.data.ortho_scale=scale;scene.camera.location=Vector(target)+Vector(direction).normalized()*10;scene.camera.rotation_euler=(Vector(target)-scene.camera.location).to_track_quat('-Z','Y').to_euler()
def render(label):scene.render.filepath=str(out/(ident+'-'+label+'.png'));bpy.ops.render.render(write_still=True)
settings=bpy.context.view_layer.freestyle_settings
original=[line.linestyle.thickness for line in settings.linesets]
for line,width in zip(settings.linesets,original):line.linestyle.thickness=width*.62
aim(view);render('hero')
scene.render.resolution_x=150;scene.render.resolution_y=110
for line,width in zip(settings.linesets,original):line.linestyle.thickness=2.3 if width>4 else width*.35
render('150')
scene.render.resolution_x=640;scene.render.resolution_y=440
for line,width in zip(settings.linesets,original):line.linestyle.thickness=width*.62
aim((6.8,-3,3.5));render('side');aim((3.3,7,4.4));render('reverse');aim(view)
clay=bpy.data.materials.new('Review neutral clay');clay.diffuse_color=(.32,.34,.36,1);clay.use_nodes=True;clay.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value=(.32,.34,.36,1);clay.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value=.94
bpy.context.view_layer.material_override=clay;scene.render.use_freestyle=False
for obj in bpy.data.objects:
    if obj.type=='MESH' and (obj.name.startswith('Drawing_') or 'PaleAccent' in obj.name):obj.hide_render=True
render('clay')
assert hashlib.sha256(source.read_bytes()).hexdigest()==before
(out/'model.json').write_text(json.dumps({'id':ident,'name':'Accepted copper shear' if family=='copper' else 'Accepted violet pocket','family':family,'status':'Owner accepted, immutable source','distinction':'Accepted individually authored prototype','source':source.name,'source_sha256':before,'preview_canvas':[640,440],'native_canvas':[150,110]},indent=2))
print('IMMUTABLE_ACCEPTED_RENDER_COMPLETE='+ident,flush=True)
