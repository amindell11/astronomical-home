#if UNITY_EDITOR
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Cameras;
using Capture.Recording;
using Capture.Views;
using NUnit.Framework;
using Substrate;
using Substrate.Services.Locales;
using Substrate.Sessions;
using Tests.PlayMode.Common;
using Tests.PlayMode.Recording;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
using Object = UnityEngine.Object;

public sealed class LocaleAsteroidCurrentSetScenario : CaptureScenario
{
    private const string Assets = "Assets/Visuals/Environment/Asteroids/LocaleReviewCurrent20";
    private readonly List<Material> ownedMaterials = new();
    private readonly List<CapturedView> captured = new();
    public override bool NeedsSession => false;
    public override GizmoCaptureProfile Profile => GizmoCaptureProfile.None;

    public override IEnumerator Run()
    {
        var catalog = JsonUtility.FromJson<ExportCatalog>(File.ReadAllText(Assets + "/export-catalog.json"));
        Assert.That(catalog.models.Length, Is.EqualTo(20));
        Import(catalog);
        var calibration = Object.Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>(Assets + "/" + catalog.orientation_basis));
        var basis = calibration.AddComponent<OrientationBasis>();
        var axisX = basis.X;
        var axisY = basis.Y;
        var axisZ = basis.Z;
        Object.DestroyImmediate(calibration);
        Debug.Log($"FBX_BASIS X={axisX} Y={axisY} Z={axisZ}");
        var materials = catalog.materials.ToDictionary(m => m.key, MakeMaterial);
        var contourSource = AssetDatabase.LoadAssetAtPath<Material>("Assets/Visuals/Vfx/LayeredExplosion/Materials/AsteroidContour.mat");
        Assert.IsNotNull(contourSource);
        var contour = new Material(contourSource) { name = "Locale preview contour" };
        contour.SetFloat("_ContourPixels", 4f);
        contour.SetFloat("_UniformWidth", 1f);
        ownedMaterials.Add(contour);
        var poses = new[] { new Vector2(-10f, 5f), new Vector2(0f, 6f), new Vector2(10f, 4f), new Vector2(-7f, -5f), new Vector2(7f, -5f) };
        var angles = new[] { -12f, 9f, -7f, 15f, -17f };
        try
        {
            foreach (var family in catalog.models.GroupBy(m => m.family))
            {
                var root = new GameObject("Locale asteroid baseline " + family.Key);
                var locale = family.First().locale;
                var session = TestSession.Create(root, new SessionProfile
                {
                    presentation = true,
                    idleLocale = AssetDatabase.LoadAssetAtPath<LocaleSky>($"Assets/Prefabs/Locales/Locale_{locale}.prefab")
                });
                try
                {
                    yield return session.Compose();
                    AddReviewLighting(root.transform);
                    var observer = TestAssets.NewObserverCam();
                    observer.transform.SetParent(root.transform, false);
                    var pilotRoot = new GameObject("Stationary scale pilot");
                    pilotRoot.transform.SetParent(root.transform, false);
                    var pilot = pilotRoot.AddComponent<JumpTestCommander>();
                    var ship = session.Units.SpawnShip(TestAssets.LoadCrimsonPrefab(), pilot, 0,
                        session.Frame.Place(new Vector2(0f, -2f)), GamePlane.Rotation, null);
                    observer.SetSubject(ship.transform);
                    observer.SetManualCenter(Vector2.zero);
                    var index = 0;
                    foreach (var model in family)
                    {
                        var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(Assets + "/" + model.fbx);
                        Assert.IsNotNull(prefab, model.fbx);
                        var rock = Object.Instantiate(prefab, root.transform);
                        rock.name = model.id;
                        var rig = rock.AddComponent<PreviewRig>();
                        rig.Initialize(model, materials, contour);
                        rock.transform.position = session.Frame.Place(poses[index]);
                        var view = axisX * model.source_view[0] + axisY * model.source_view[1] + axisZ * model.source_view[2];
                        var up = axisX * model.source_up[0] + axisY * model.source_up[1] + axisZ * model.source_up[2];
                        var pose = Quaternion.LookRotation(Vector3.back, Vector3.up) * Quaternion.Inverse(Quaternion.LookRotation(view, up));
                        Assert.That(Vector3.Dot(pose * view.normalized, Vector3.back), Is.GreaterThan(.999f), model.id);
                        Assert.That(Vector3.Dot(pose * up.normalized, Vector3.up), Is.GreaterThan(.999f), model.id);
                        rock.transform.rotation = Quaternion.AngleAxis(angles[index], Vector3.forward) * pose;
                        Debug.Log($"MODEL_POSE {model.id} sourceView={view} sourceUp={up} pose={pose.eulerAngles} frontCameraDot={Vector3.Dot(pose * -axisY, Vector3.back)}");
                        rock.transform.localScale = Vector3.one;
                        index++;
                    }
                    Assert.That(index, Is.EqualTo(5));
                    using (var view = (IDisposable)Capture.GetType().GetMethod("PrepareGameTopdown")
                               .Invoke(Capture, new object[] { observer }))
                    {
                        foreach (var zoom in new[] { 15f, 9f })
                        {
                            observer.SetManualZoom(zoom);
                            yield return new WaitForSecondsRealtime(1.2f);
                            var label = $"current20-review-locale-{locale}-{family.Key}-{(zoom == 15f ? "flight" : "close")}";
                            using var recording = Capture.Prepare(new CaptureRequest("results/capture", label, Commit, 1280, 720,
                                measurements: new Dictionary<string, Func<double>>
                                {
                                    ["locale_id"] = () => locale,
                                    ["observer_zoom"] = () => observer.Cam.orthographicSize,
                                    ["asteroid_count"] = () => 5
                                }));
                            yield return recording.Ready;
                            recording.Start();
                            for (var frame = 0; frame < 10; frame++) yield return null;
                            Result = recording.Finish();
                            Assert.That(Result.FrameCount, Is.GreaterThan(1));
                            AssertPixels(Result.FrameDirectory);
                            captured.Add(new CapturedView { family = family.Key, locale = locale, zoom = zoom,
                                frame_directory = Result.FrameDirectory, models = family.Select(m => m.id).ToArray() });
                            Debug.Log("LOCALE_BASELINE=" + JsonUtility.ToJson(captured[captured.Count - 1]));
                        }
                    }
                    yield return session.Teardown();
                }
                finally { Object.DestroyImmediate(root); }
            }
            var output = Path.GetFullPath(Path.Combine(Application.dataPath, "../../..", "results/capture/locale-asteroid-current20-index.json"));
            File.WriteAllText(output, JsonUtility.ToJson(new CaptureIndex { lighting = "Game camera and locale backdrops with neutral review lighting; declared Verdant dark/jade material roles gain 1.4; contour-only joined normals, uniform 4px", views = captured.ToArray() }, true));
            Debug.Log("LOCALE_BASELINE_INDEX=" + output);
        }
        finally
        {
            foreach (var material in ownedMaterials) Object.DestroyImmediate(material);
        }
    }

    private static void AddReviewLighting(Transform parent)
    {
        var keyRoot = new GameObject("Neutral asteroid review key");
        keyRoot.transform.SetParent(parent, false);
        keyRoot.transform.rotation = Quaternion.LookRotation(new Vector3(.38f, -.52f, .82f));
        var key = keyRoot.AddComponent<Light>();
        key.type = LightType.Directional;
        key.color = Color.white;
        key.intensity = 1.15f;
        key.shadows = LightShadows.Soft;
        key.shadowStrength = .65f;
        key.shadowBias = .04f;
        key.shadowNormalBias = .15f;
        RenderSettings.sun = key;
        RenderSettings.ambientMode = AmbientMode.Custom;
        RenderSettings.ambientIntensity = 1f;
        var probe = new SphericalHarmonicsL2();
        probe.AddAmbientLight(new Color(.55f, .55f, .55f));
        RenderSettings.ambientProbe = probe;
        Debug.Log("REVIEW_LIGHTING key=white,1.15 direction=(-.38,.52,-.82) SH=neutral,.55 shadowTint=(.56,.58,.62) threshold=.15");
    }

    private static void Import(ExportCatalog catalog)
    {
        foreach (var path in catalog.models.Select(m => m.fbx).Append(catalog.orientation_basis))
        {
            var importer = (ModelImporter)AssetImporter.GetAtPath(Assets + "/" + path);
            Assert.IsNotNull(importer, path);
            importer.globalScale = 1f;
            importer.useFileScale = true;
            importer.bakeAxisConversion = true;
            importer.importAnimation = false;
            importer.importCameras = false;
            importer.importLights = false;
            importer.isReadable = true;
            importer.materialImportMode = ModelImporterMaterialImportMode.None;
            importer.importNormals = ModelImporterNormals.Import;
            importer.importTangents = ModelImporterTangents.CalculateMikk;
            importer.SaveAndReimport();
        }
        foreach (var material in catalog.materials.Where(m => !string.IsNullOrEmpty(m.paint_path)))
        {
            var importer = (TextureImporter)AssetImporter.GetAtPath(Assets + "/" + material.paint_path);
            importer.sRGBTexture = true;
            importer.textureType = TextureImporterType.Default;
            importer.wrapMode = TextureWrapMode.Repeat;
            importer.maxTextureSize = 1024;
            importer.textureCompression = TextureImporterCompression.Uncompressed;
            importer.SaveAndReimport();
        }
    }

    private Material MakeMaterial(ExportMaterial data)
    {
        var template = AssetDatabase.LoadAssetAtPath<Material>(string.IsNullOrEmpty(data.paint_path)
            ? "Assets/Visuals/Environment/Asteroids/DrawnField/FieldGraphite.mat"
            : "Assets/Visuals/Environment/Asteroids/DrawnField/Shape01/Asteroid1Paint.mat");
        var material = new Material(template) { name = data.key };
        material.DisableKeyword("_NORMALMAP");
        material.DisableKeyword("_PAINT_LAYERS");
        material.DisableKeyword("_LIGHT_DRIVEN_PAINT");
        material.SetFloat("_UseRelief", 0f);
        material.SetFloat("_LineStrength", 0f);
        material.SetFloat("_WearStrength", 0f);
        material.SetFloat("_SpecularStrength", 0f);
        material.SetFloat("_SootStrength", 0f);
        material.SetFloat("_EmissionStrength", 0f);
        var gain = data.review_role == "verdant_dark" ? 1.4f : 1f;
        material.SetColor("_BaseColor", new Color(data.color[0] * gain, data.color[1] * gain, data.color[2] * gain, data.color[3]));
        material.SetColor("_PaperColor", Color.white);
        material.SetFloat("_AmbientStrength", 1f);
        material.SetFloat("_ShadowThreshold", .15f);
        material.SetFloat("_ShadowSoftness", .16f);
        material.SetFloat("_CastShadowStrength", .55f);
        material.SetColor("_ShadowColor", new Color(.56f, .58f, .62f, 1f));
        material.SetTexture("_BaseMap", string.IsNullOrEmpty(data.paint_path) ? Texture2D.whiteTexture
            : AssetDatabase.LoadAssetAtPath<Texture2D>(Assets + "/" + data.paint_path));
        material.SetFloat("_TextureStrength", string.IsNullOrEmpty(data.paint_path) ? 0f : 1f);
        ownedMaterials.Add(material);
        return material;
    }

    private static void AssertPixels(string folder)
    {
        var paths = Directory.GetFiles(folder, "*.png").OrderBy(p => p).ToArray();
        var image = new Texture2D(2, 2);
        try
        {
            Assert.IsTrue(image.LoadImage(File.ReadAllBytes(paths[paths.Length / 2])));
            var colors = new HashSet<Color32>();
            var pixels = image.GetPixels32();
            for (var y = 180; y < 540; y += 3)
            for (var x = 160; x < 1120; x += 3) colors.Add(pixels[y * image.width + x]);
            Assert.That(colors.Count, Is.GreaterThan(100), "Game View must contain rendered scene content.");
        }
        finally { Object.DestroyImmediate(image); }
    }

    public sealed class PreviewRig : MonoBehaviour
    {
        private Dictionary<string, MeshRenderer> renderers;
        private Dictionary<string, MeshFilter> filters;
        private readonly List<Mesh> contourMeshes = new();
        private void Awake()
        {
            renderers = GetComponentsInChildren<MeshRenderer>(true).ToDictionary(r => r.name);
            filters = GetComponentsInChildren<MeshFilter>(true).ToDictionary(f => f.name);
        }
        public void Initialize(ExportModel model, Dictionary<string, Material> materials, Material contour)
        {
            Assert.That(renderers.Count, Is.EqualTo(model.parts.Length), model.id);
            foreach (var part in model.parts)
            {
                var renderer = renderers[part.name];
                var mesh = filters[part.name].sharedMesh;
                Assert.That(mesh.vertexCount, Is.GreaterThan(0));
                Assert.That(mesh.subMeshCount, Is.EqualTo(part.materials.Length), model.id + " " + part.name);
                renderer.sharedMaterials = part.materials.Select(key => materials[key]).ToArray();
                renderer.shadowCastingMode = part.ink ? ShadowCastingMode.Off : ShadowCastingMode.On;
                if (part.ink) continue;
                var shell = new GameObject(part.name + " contour");
                shell.transform.SetParent(renderer.transform, false);
                var contourMesh = JoinedContour(mesh);
                contourMeshes.Add(contourMesh);
                shell.AddComponent<MeshFilter>().sharedMesh = contourMesh;
                var outline = shell.AddComponent<MeshRenderer>();
                outline.sharedMaterials = Enumerable.Repeat(contour, mesh.subMeshCount).ToArray();
                outline.shadowCastingMode = ShadowCastingMode.Off;
                outline.receiveShadows = false;
            }
        }
        private static Mesh JoinedContour(Mesh source)
        {
            var positions = source.vertices;
            var normals = source.normals;
            var uv = source.uv;
            Assert.That(normals.Length, Is.EqualTo(positions.Length));
            Assert.That(uv.Length, Is.EqualTo(positions.Length));
            var sums = new Dictionary<Vector3, Vector3>();
            var distinct = new HashSet<(Vector3 position, Vector3 normal, Vector2 uv)>();
            for (var i = 0; i < positions.Length; i++)
            {
                if (!distinct.Add((positions[i], normals[i], uv[i]))) continue;
                sums.TryGetValue(positions[i], out var sum);
                sums[positions[i]] = sum + normals[i];
            }
            for (var i = 0; i < positions.Length; i++)
            {
                Assert.That(sums[positions[i]].sqrMagnitude, Is.GreaterThan(.000001f), source.name);
                normals[i] = sums[positions[i]].normalized;
            }
            var result = Object.Instantiate(source);
            result.name = source.name + " joined contour normals";
            result.normals = normals;
            return result;
        }

        private void OnDestroy()
        {
            foreach (var mesh in contourMeshes) Object.DestroyImmediate(mesh);
        }
    }

    public sealed class OrientationBasis : MonoBehaviour
    {
        public Vector3 X { get; private set; }
        public Vector3 Y { get; private set; }
        public Vector3 Z { get; private set; }
        private void Awake()
        {
            var markers = GetComponentsInChildren<MeshRenderer>().ToDictionary(r => r.name, r => r.bounds.center);
            var origin = markers["AxisOrigin"];
            X = (markers["AxisX"] - origin).normalized;
            Y = (markers["AxisY"] - origin).normalized;
            Z = (markers["AxisZ"] - origin).normalized;
        }
    }

    [Serializable] public sealed class ExportCatalog { public ExportModel[] models; public ExportMaterial[] materials; public string orientation_basis; }
    [Serializable] public sealed class ExportModel { public string id; public string family; public int locale; public string fbx; public ExportPart[] parts; public float[] source_view; public float[] source_up; }
    [Serializable] public sealed class ExportPart { public string name; public string source_name; public bool ink; public string[] materials; }
    [Serializable] public sealed class ExportMaterial { public string key; public string source_name; public string review_role; public string paint_path; public float[] color; }
    [Serializable] private sealed class CapturedView { public string family; public int locale; public float zoom; public string frame_directory; public string[] models; }
    [Serializable] private sealed class CaptureIndex { public string lighting; public CapturedView[] views; }
}
#endif
