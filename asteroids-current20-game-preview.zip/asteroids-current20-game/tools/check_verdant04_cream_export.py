import bpy,bmesh,json
from pathlib import Path

def corners(obj,mesh):
    uv=mesh.uv_layers.active
    return {tuple(round(c,5) for c in obj.matrix_world@mesh.vertices[loop.vertex_index].co)+tuple(round(c,5) for c in uv.data[loop.index].uv) for loop in mesh.loops}

root=Path(__file__).resolve().parents[1]
catalog=json.loads((root/'current-preview-export/export-catalog.json').read_text())
model=next(m for m in catalog['models'] if m['id']=='verdant-04')
part=next(p for p in model['parts'] if p['source_name']=='Broken pale crust_FittedSections')
material=next(m for m in catalog['materials'] if m['key']==part['materials'][0])
assert material['review_role']=='pale_crust'
bpy.ops.wm.open_mainfile(filepath=str(root/'current-set/verdant/verdant-04/verdant-04.blend'))
source=bpy.data.objects[part['source_name']];evaluated=source.evaluated_get(bpy.context.evaluated_depsgraph_get())
mesh=evaluated.to_mesh();source_material=mesh.materials[mesh.polygons[0].material_index]
assert source_material.get('review_role')=='pale_crust'
source_material_name=source_material.name
source_corners=corners(source,mesh)
bm=bmesh.new();bm.from_mesh(mesh);source_volume=bm.calc_volume(signed=True);bm.free();evaluated.to_mesh_clear()
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.fbx(filepath=str(root/'current-preview-export'/model['fbx']))
obj=bpy.data.objects[part['name']]
assert {obj.material_slots[p.material_index].material.name for p in obj.data.polygons}==set(part['materials'])
assert source_corners==corners(obj,obj.data), 'Export repair changed cream positions or UV mapping.'
bm=bmesh.new();bm.from_mesh(obj.data);volume=bm.calc_volume(signed=True);closed=all(e.is_manifold for e in bm.edges);bm.free()
print(json.dumps({'part':part['source_name'],'source_material':source_material_name,'export_role':material['review_role'],'source_signed_volume':source_volume,'imported_signed_volume':volume,'closed':closed,'positions_and_uvs_preserved':True}),flush=True)
assert closed and volume>0, 'Cream crust is inside-out and culled by the single-sided game surface shader.'
