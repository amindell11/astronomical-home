"""Blender CLI: export frozen catalog meshes and unlit graded color swatches to assets/.

No source is saved. Outputs export-catalog.json, models/*.fbx and paint/*.png.
The JSON declares every part/material mapping; exit nonzero on a changed source hash.
"""
import bpy,json,hashlib
from pathlib import Path
from mathutils import Vector
ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'current-set'
OUT=ROOT/'current-preview-export';(OUT/'models').mkdir(parents=True,exist_ok=True);(OUT/'paint').mkdir(exist_ok=True)
catalog=json.loads((SOURCE/'catalog.json').read_text());materials={};models=[]
def hashfile(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def signature(mat):
    nodes=[]
    for node in mat.node_tree.nodes:
        values=[]
        for socket in node.inputs:
            if hasattr(socket,'default_value'):
                value=socket.default_value
                if not isinstance(value,(str,float,int,bool)):value=list(value)
                values.append((socket.name,value))
        nodes.append((node.name,node.bl_idname,values,getattr(getattr(node,'image',None),'name',None),getattr(node,'blend_type',None)))
    links=[(l.from_node.name,l.from_socket.name,l.to_node.name,l.to_socket.name) for l in mat.node_tree.links]
    return hashlib.sha256(json.dumps((nodes,links),sort_keys=True).encode()).hexdigest()[:16]
def export_material(mat):
    key='M_'+signature(mat)
    if key in materials:return key
    shader=next(n for n in mat.node_tree.nodes if n.type=='BSDF_PRINCIPLED');color=shader.inputs['Base Color']
    data={'key':key,'source_name':mat.name,'review_role':mat.get('review_role','surface' if color.is_linked else 'ink'),'paint_path':'','color':list(color.default_value)}
    if color.is_linked:
        path=OUT/'paint'/(key+'.png');data['paint_path']='paint/'+path.name;data['color']=[1,1,1,1]
        temp=mat.copy();nodes=temp.node_tree.nodes;links=temp.node_tree.links;principled=next(n for n in nodes if n.type=='BSDF_PRINCIPLED');output=next(n for n in nodes if n.type=='OUTPUT_MATERIAL')
        emission=nodes.new('ShaderNodeEmission');source=principled.inputs['Base Color'].links[0].from_socket;links.new(source,emission.inputs['Color']);links.new(emission.outputs[0],output.inputs['Surface'])
        target=bpy.data.images.new('ExportColor',1024,1024,alpha=False);target.colorspace_settings.name='sRGB';image=nodes.new('ShaderNodeTexImage');image.image=target;nodes.active=image
        bpy.ops.mesh.primitive_plane_add(size=2);plane=bpy.context.object;plane.data.materials.append(temp)
        for uvnode in [n for n in nodes if n.type=='UVMAP']:
            if uvnode.uv_map and not plane.data.uv_layers.get(uvnode.uv_map):
                uv=plane.data.uv_layers.new(name=uvnode.uv_map)
                for i,coord in enumerate(((0,0),(1,0),(1,1),(0,1))):uv.data[i].uv=coord
        bpy.context.scene.render.engine='CYCLES';bpy.context.scene.cycles.samples=1;bpy.context.scene.render.bake.margin=0
        bpy.ops.object.bake(type='EMIT');target.filepath_raw=str(path);target.file_format='PNG';target.save()
        bpy.data.objects.remove(plane,do_unlink=True);bpy.data.materials.remove(temp);bpy.data.images.remove(target)
        data['paint_sha256']=hashfile(path)
    materials[key]=data;return key
for item in catalog['models']:
    source=SOURCE/item['source'];before=hashfile(source);assert before==item['source_sha256'];bpy.ops.wm.open_mainfile(filepath=str(source))
    objects=sorted([o for o in bpy.context.scene.objects if o.type=='MESH' and not o.hide_render and not any(c.hide_render for c in o.users_collection)],key=lambda o:o.name)
    parts=[]
    for index,obj in enumerate(objects):
        original=obj.name;ink=bool(obj.get('intentional_open_ribbon')) or original.startswith('Drawing_') or 'PaleAccent' in original
        used=sorted({face.material_index for face in obj.data.polygons});chosen=[obj.material_slots[i].material for i in used];remap={old:new for new,old in enumerate(used)}
        indices=[remap[face.material_index] for face in obj.data.polygons];obj.data.materials.clear()
        for material in chosen:obj.data.materials.append(material)
        for face,material_index in zip(obj.data.polygons,indices):face.material_index=material_index
        keys=[export_material(slot.material) for slot in obj.material_slots]
        matrix=obj.matrix_world.copy();obj.parent=None;obj.matrix_world=matrix;obj.name=f'part_{index:03d}'
        for slot,key in zip(obj.material_slots,keys):slot.material.name=key
        parts.append({'name':obj.name,'source_name':original,'ink':ink,'materials':keys})
    bpy.ops.object.select_all(action='DESELECT')
    for obj in objects:obj.hide_set(False);obj.select_set(True)
    path=OUT/'models'/(item['id']+'.fbx')
    bpy.ops.export_scene.fbx(filepath=str(path),use_selection=True,object_types={'MESH'},use_mesh_modifiers=True,mesh_smooth_type='OFF',add_leaf_bones=False,bake_anim=False,path_mode='STRIP',axis_forward='-Z',axis_up='Y',global_scale=1,apply_unit_scale=True)
    assert before==hashfile(source)
    camera_rotation=bpy.context.scene.camera.matrix_world.to_quaternion()
    models.append({'id':item['id'],'family':item['family'],'locale':item['locale_id'],'fbx':'models/'+path.name,'source_sha256':before,'fbx_sha256':hashfile(path),'parts':parts,'source_view':list(camera_rotation@Vector((0,0,1))),'source_up':list(camera_rotation@Vector((0,1,0)))})
    print('EXPORTED='+item['id'],flush=True)
bpy.ops.wm.read_factory_settings(use_empty=True)
for name,point in [('AxisOrigin',(0,0,0)),('AxisX',(1,0,0)),('AxisY',(0,1,0)),('AxisZ',(0,0,1))]:
    bpy.ops.mesh.primitive_cube_add(size=.02,location=point);bpy.context.object.name=name
bpy.ops.object.select_all(action='SELECT')
bpy.ops.export_scene.fbx(filepath=str(OUT/'models/orientation-basis.fbx'),use_selection=True,object_types={'MESH'},use_mesh_modifiers=True,mesh_smooth_type='OFF',add_leaf_bones=False,bake_anim=False,path_mode='STRIP',axis_forward='-Z',axis_up='Y',global_scale=1,apply_unit_scale=True)
(OUT/'export-catalog.json').write_text(json.dumps({'models':models,'materials':list(materials.values()),'orientation_basis':'models/orientation-basis.fbx','color_workflow':'Blender Base Color emission bake, no lighting/AO; original images unchanged','axes':'FBX -Z forward, Y up'},indent=2))
print('EXPORT_COMPLETE='+str(OUT/'export-catalog.json'),flush=True)
