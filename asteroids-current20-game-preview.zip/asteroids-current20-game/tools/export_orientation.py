"""Add measured source-camera vectors and an FBX axis calibration to the preview export."""
import bpy,json,hashlib
from pathlib import Path
from mathutils import Vector
ROOT=Path(__file__).resolve().parent;SOURCE=ROOT.parent/'bespoke-five/set';OUT=ROOT/'assets'
catalog=json.loads((OUT/'export-catalog.json').read_text());sources=json.loads((SOURCE/'catalog.json').read_text())
for model,item in zip(catalog['models'],sources['models']):
    source=SOURCE/item['source'];before=hashlib.sha256(source.read_bytes()).hexdigest();bpy.ops.wm.open_mainfile(filepath=str(source))
    rotation=bpy.context.scene.camera.matrix_world.to_quaternion()
    model['source_view']=list(rotation@Vector((0,0,1)));model['source_up']=list(rotation@Vector((0,1,0)))
    assert before==hashlib.sha256(source.read_bytes()).hexdigest()==item['source_sha256']
bpy.ops.wm.read_factory_settings(use_empty=True)
for name,point in [('AxisOrigin',(0,0,0)),('AxisX',(1,0,0)),('AxisY',(0,1,0)),('AxisZ',(0,0,1))]:
    bpy.ops.mesh.primitive_cube_add(size=.02,location=point);bpy.context.object.name=name
bpy.ops.object.select_all(action='SELECT');path=OUT/'models/orientation-basis.fbx'
bpy.ops.export_scene.fbx(filepath=str(path),use_selection=True,object_types={'MESH'},use_mesh_modifiers=True,mesh_smooth_type='OFF',add_leaf_bones=False,bake_anim=False,path_mode='STRIP',axis_forward='-Z',axis_up='Y',global_scale=1,apply_unit_scale=True)
catalog['orientation_basis']='models/orientation-basis.fbx'
(OUT/'export-catalog.json').write_text(json.dumps(catalog,indent=2))
print('ORIENTATION_READY='+str(OUT/'export-catalog.json'))
