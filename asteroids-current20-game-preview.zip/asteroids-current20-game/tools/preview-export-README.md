# Current20 game review exports

The export catalog declares twenty models from the four active families. It preserves separate components, material roles, directional UVs and fitted drawing meshes. Eighteen derived paint swatches contain only the Blender material's unlit Base Color result. Original source PNGs and Blender files are unchanged.

The scratch Unity scenario uses actual game cameras and locale backdrops with neutral review lighting. Declared `verdant_dark` materials use linear gain 1.4; pale crust, ochre and ink remain unchanged. Contour-only mesh copies carry joined normals and uniform four-pixel width through the existing house contour shader. Surface normals remain authored.

One export correction is required by the frozen source: Verdant04's `Broken pale crust_FittedSections` is a closed, inward-wound component. Blender's double-sided material displayed its cream surface; Unity's single-sided material culled it and exposed the green host. The exporter reverses only that component's winding in memory. Its positions, UVs and material binding are preserved, as are all source bytes. The source remains an authoring review asset requiring this explicit correction for single-sided consumers.

`scripts/check_verdant04_cream_export.py` compares evaluated source and imported FBX material roles, positions and UVs, then checks outward winding. `cream-export-red.log` records the failure before repair; `cream-export-green.log` records the corrected result. `preview-export-correction.json` records exact scope and hashes. Only `models/verdant-04.fbx` and `export-catalog.json` changed during the partial repair; the other models and maps stayed unchanged.

`scripts/export_current_review.py` retains the correction when rebuilding the entire export. Run it through Blender background mode with `--python-exit-code 1`; its optional trailing `-- --only verdant-04` re-exports that model while preserving all other assets and source catalog order. The script uses sibling `current-set` as input and `current-preview-export` as output. The game scenario and its capture index are separate evidence; no production spawn routing or locale assets are changed.
