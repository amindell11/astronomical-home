"""Blender authoring helpers for the bespoke locale set. Outputs stay under this set."""
import bpy,bmesh,math,json,hashlib
from pathlib import Path
from mathutils import Vector,Euler
from mathutils.bvhtree import BVHTree

SET=Path(__file__).resolve().parents[1]
class Model:
    def __init__(self,family,index,name,distinction,palette):
        bpy.ops.wm.read_factory_settings(use_empty=True);bpy.context.preferences.filepaths.save_version=0
        self.family,self.index,self.name=family,index,name;self.id=f'{family}-{index:02d}'
        self.out=SET/family/self.id;self.out.mkdir(parents=True,exist_ok=True)
        self.scene=bpy.context.scene
        self.parts=self.collection('Editable components');self.author=self.collection('Construction, hidden');self.review=self.collection('Review cameras and lights')
        self.root=bpy.data.objects.new(self.id+' '+name,None);self.parts.objects.link(self.root)
        self.palette=[self.paint(*entry) for entry in palette];self.volumes=[];self.body=None
        self.metadata={'id':self.id,'name':name,'family':family,'distinction':distinction,'status':'New individually authored candidate','construction_parts':[],'sources':'Purpose-built geometry; no legacy asteroid mesh reuse'}
        self.clay=self.flat('Neutral clay',(.32,.34,.36));self.ink=self.flat('Graphite',(.018,.014,.027));self.drawings=[]
    def collection(self,name):
        coll=bpy.data.collections.new(name);self.scene.collection.children.link(coll);return coll
    def flat(self,name,color):
        mat=bpy.data.materials.new(name);mat.use_nodes=True
        shader=mat.node_tree.nodes.get('Principled BSDF');shader.inputs['Base Color'].default_value=(*color,1);shader.inputs['Roughness'].default_value=.94;shader.inputs['Specular IOR Level'].default_value=.12
        return mat
    def paint(self,name,filename,saturation=1,value=1,tint=None):
        mat=self.flat(name,(.1,.1,.1));nodes=mat.node_tree.nodes;links=mat.node_tree.links
        image=bpy.data.images.get(filename)
        if image is None:
            image=bpy.data.images.load(str(SET/'paint'/filename));image.pack();image.filepath='//../../paint/'+filename
        texture=nodes.new('ShaderNodeTexImage');texture.image=image;texture.extension='REPEAT';texture.interpolation='Linear'
        uv=nodes.new('ShaderNodeUVMap');uv.uv_map='DirectionalPaintUV';links.new(uv.outputs[0],texture.inputs[0])
        tone=nodes.new('ShaderNodeHueSaturation');tone.inputs['Saturation'].default_value=saturation;tone.inputs['Value'].default_value=value;links.new(texture.outputs['Color'],tone.inputs['Color'])
        color=tone.outputs[0]
        if tint:
            mix=nodes.new('ShaderNodeMixRGB');mix.blend_type='MULTIPLY';mix.inputs[0].default_value=1;mix.inputs[2].default_value=(*tint,1);links.new(color,mix.inputs[1]);color=mix.outputs[0]
        links.new(color,nodes.get('Principled BSDF').inputs['Base Color']);return mat
    def mesh(self,name,vertices,faces,author=False,mats=None):
        data=bpy.data.meshes.new(name+'Mesh');data.from_pydata([tuple(v) for v in vertices],[],faces);data.update()
        for mat in mats or self.palette:data.materials.append(mat)
        bm=bmesh.new();bm.from_mesh(data);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(data);bm.free()
        obj=bpy.data.objects.new(name,data);(self.author if author else self.parts).objects.link(obj)
        if not author:obj.parent=self.root
        return obj
    def slab(self,name,top,bottom,roof=None,top_material=0,side_materials=None):
        n=len(top)
        if isinstance(bottom,(int,float)):
            center=sum((Vector(v) for v in top),Vector())/n
            bottom=[(center.x+(p[0]-center.x)*.85-.16,center.y+(p[1]-center.y)*.85,float(bottom)) for p in top]
        if roof is None:
            roof={6:[(0,1,2,5),(2,3,4,5)],7:[(0,1,2,6),(2,3,5,6),(3,4,5)],8:[(0,1,2,7),(2,3,6,7),(3,4,5,6)]}[n]
        faces=[tuple(range(n-1,-1,-1))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]+[tuple(n+i for i in f) for f in roof]
        obj=self.mesh(name,list(bottom)+list(top),faces,True)
        for i,face in enumerate(obj.data.polygons):
            if i>n:face.material_index=top_material[i-n-1] if isinstance(top_material,(list,tuple)) else top_material
            elif i>0:face.material_index=(side_materials or {}).get(i-1,0)
        self.triangulate(obj);self.volumes.append(obj);self.metadata['construction_parts'].append(name);return obj
    def triangulate(self,obj):
        bm=bmesh.new();bm.from_mesh(obj.data);bmesh.ops.triangulate(bm,faces=list(bm.faces));bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(obj.data);bm.free()
    def fuse(self):
        first=self.volumes[0];self.body=first.copy();self.body.data=first.data.copy();self.body.name='Rock_Host' if self.family!='ice' else 'Ice_Host';self.parts.objects.link(self.body);self.body.parent=self.root
        bpy.context.view_layer.objects.active=self.body;self.body.select_set(True)
        for volume in self.volumes[1:]:
            mod=self.body.modifiers.new('Fuse '+volume.name,'BOOLEAN');mod.operation='UNION';mod.solver='EXACT';mod.object=volume;bpy.ops.object.modifier_apply(modifier=mod.name)
        self.triangulate(self.body);return self.body
    def cut(self,name,center,u,v,outward,material=0):
        center,u,v,outward=map(Vector,(center,u,v,outward));inner=[center-u-v,center+u-v,center+u+v,center-u+v]
        cutter=self.mesh(name,inner+[p+outward for p in inner],[(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)],True)
        for face in cutter.data.polygons:face.material_index=material
        bpy.context.view_layer.objects.active=self.body
        mod=self.body.modifiers.new(name,'BOOLEAN');mod.operation='DIFFERENCE';mod.solver='EXACT';mod.object=cutter;bpy.ops.object.modifier_apply(modifier=mod.name);self.triangulate(self.body)
    def uv(self,obj,axis=(.75,.55,.7),span=4):
        uv=obj.data.uv_layers.new(name='DirectionalPaintUV');axis=Vector(axis).normalized()
        for face in obj.data.polygons:
            normal=face.normal.normalized();grain=axis-normal*axis.dot(normal)
            if grain.length<.1:grain=Vector((1,0,.1))-normal*Vector((1,0,.1)).dot(normal)
            grain.normalize();cross=normal.cross(grain).normalized()
            for index in face.loop_indices:
                point=obj.data.vertices[obj.data.loops[index].vertex_index].co;across,along=point.dot(cross),point.dot(grain)
                uv.data[index].uv=((across+along)/(span*math.sqrt(2))+.5,(-across+along)/(span*math.sqrt(2))+.5)
        obj['paint_mapping']='Actual face UV, brush aligned to physical fracture axis'
    def adjacency(self):
        adjacent={tuple(sorted(e.vertices)):[] for e in self.body.data.edges}
        for face in self.body.data.polygons:
            ids=list(face.vertices)
            for a,b in zip(ids,ids[1:]+ids[:1]):adjacent[tuple(sorted((a,b)))].append(face)
        return adjacent
    def skins(self,indices,erode=True):
        self.triangulate(self.body);adj=self.adjacency()
        for index in indices:
            faces=[p for p in self.body.data.polygons if p.material_index==index]
            unseen={p.index for p in faces};groups={};group=0
            while unseen:
                seed=unseen.pop();stack=[seed]
                while stack:
                    fi=stack.pop();groups[fi]=group;verts=list(self.body.data.polygons[fi].vertices)
                    for a,b in zip(verts,verts[1:]+verts[:1]):
                        for neighbor in adj[tuple(sorted((a,b)))]:
                            if neighbor.index in unseen:unseen.remove(neighbor.index);stack.append(neighbor.index)
                group+=1
            ids=sorted({(groups[p.index],v) for p in faces for v in p.vertices});lookup={v:i for i,v in enumerate(ids)};normals={v:Vector() for v in ids}
            for face in faces:
                for v in face.vertices:normals[(groups[face.index],v)]+=face.normal
            for v in normals:normals[v].normalize()
            upper=[self.body.data.vertices[v[1]].co+normals[v]*.003 for v in ids];lower=[self.body.data.vertices[v[1]].co-normals[v]*.045 for v in ids];exposed=[]
            for face in faces:
                source=list(face.vertices);loop=[]
                for a,b in zip(source,source[1:]+source[:1]):
                    loop.append(lookup[(groups[face.index],a)]);first,last=self.body.data.vertices[a].co,self.body.data.vertices[b].co;length=(last-first).length
                    if erode and face.normal.z>.4 and length>.45 and any(p.material_index!=index and p.normal.z>.35 for p in adj[tuple(sorted((a,b)))]):
                        tangent=(last-first).normalized();inward=face.center-(first+last)*.5;inward-=tangent*inward.dot(tangent);inward.normalize()
                        third=self.body.data.vertices[next(v for v in source if v not in (a,b))].co;altitude=(third-first).dot(inward);projection=(third-first).dot(tangent)/length
                        for t,d in [(.22,.03),(.39,.07),(.57,.035),(.74,.09),(.87,.04)]:
                            fractions=[1]
                            if projection>0:fractions.append(t/projection)
                            if projection<1:fractions.append((1-t)/(1-projection))
                            point=first.lerp(last,t)+inward*min(d,length*.07,altitude*min(fractions)*.7);loop.append(len(upper));upper.append(point+face.normal*.003);lower.append(point-face.normal*.045)
                exposed.append(loop)
            n=len(upper);polys=[];edges={}
            for loop in exposed:
                polys.extend([tuple(loop),tuple(i+n for i in loop[::-1])])
                for a,b in zip(loop,loop[1:]+loop[:1]):edges.setdefault(tuple(sorted((a,b))),[]).append((a,b))
            for uses in edges.values():
                if len(uses)==1:
                    a,b=uses[0];polys.append((b,a,a+n,b+n))
            obj=self.mesh(self.palette[index].name+'_FittedSections',upper+lower,polys,mats=(self.palette[index],));obj['solid_role']='Fitted mineral section, buried thickness'
            bpy.ops.object.select_all(action='DESELECT');obj.select_set(True);bpy.context.view_layer.objects.active=obj;bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.mesh.separate(type='LOOSE');bpy.ops.object.mode_set(mode='OBJECT')
        for face in self.body.data.polygons:face.material_index=0
        self.body['solid_role']='Connected primary mass'
    def patch(self,name,anchor,width,material,depth=.026,offset=.009):
        self.triangulate(self.body);adj=self.adjacency();anchor=Vector(anchor);candidates=[]
        for edge in self.body.data.edges:
            faces=adj[tuple(sorted(edge.vertices))]
            if len(faces)!=2:continue
            a,b=[self.body.data.vertices[i].co.copy() for i in edge.vertices];length=(b-a).length
            if length<.4 or faces[0].normal.angle(faces[1].normal)<math.radians(16):continue
            for face in faces:
                if face.normal.z<.25 or face.area<.07:continue
                c=self.body.data.vertices[next(i for i in face.vertices if i not in edge.vertices)].co.copy();altitude=(c-a).cross((b-a).normalized()).length
                if altitude>.2:candidates.append((((a+b)*.5-anchor).length_squared,a,b,c,face.normal.copy(),altitude))
        _,a,b,c,normal,altitude=min(candidates,key=lambda t:t[0]);tangent=(b-a).normalized();length=(b-a).length;projection=(c-a).dot(tangent)/length;inward=(c-a-tangent*(c-a).dot(tangent)).normalized()
        profile=[(.17,.05),(.27,.01),(.41,.05),(.54,.02),(.69,.04),(.82,.09),(.78,.55),(.70,.82),(.61,.61),(.51,1),(.40,.77),(.29,.93),(.21,.53)]
        limits=[]
        for along,h in profile:
            fractions=[1]
            if projection>0:fractions.append(along/projection)
            if projection<1:fractions.append((1-along)/(1-projection))
            limits.append(altitude*min(fractions)*.8/h)
        width=min(width,min(limits));points=[a.lerp(b,t)+inward*width*h for t,h in profile];n=len(points)
        obj=self.mesh(name,[p+normal*offset for p in points]+[p-normal*depth for p in points],[tuple(range(n)),tuple(range(2*n-1,n-1,-1))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)],mats=(self.palette[material],))
        obj['solid_role']='Near-flush deposit, fitted to one host face';self.uv(obj,span=1.15);return obj
    def stroke(self,name,anchor,width=.012,start=.13,end=.83):
        if not hasattr(self,'used_ink'):self.used_ink=set()
        anchor=Vector(anchor);adj=self.adjacency();candidates=[]
        for edge in self.body.data.edges:
            key=tuple(sorted(edge.vertices));faces=adj[key]
            if key in self.used_ink or len(faces)!=2:continue
            a,b=[self.body.data.vertices[i].co.copy() for i in edge.vertices];length=(b-a).length
            if length<.38 or faces[0].normal.angle(faces[1].normal)<math.radians(28):continue
            t=max(0,min(1,(anchor-a).dot(b-a)/(length*length)));candidates.append(((a.lerp(b,t)-anchor).length_squared,key,a,b,faces))
        _,key,a,b,faces=min(candidates,key=lambda t:t[0]);self.used_ink.add(key);normal=max(faces,key=lambda f:f.normal.z-f.normal.y*.5).normal.copy();tangent=(b-a).normalized();side=normal.cross(tangent).normalized();vertices=[]
        for t,w in [(start,.1),(start+(end-start)*.32,.8),(start+(end-start)*.67,1),(end,.07)]:
            point=a.lerp(b,t)+normal*.011;vertices.extend([point-side*width*w,point+side*width*w])
        obj=self.mesh(name,vertices,[(0,1,3,2),(2,3,5,4),(4,5,7,6)],mats=(self.ink,));obj['intentional_open_ribbon']=True;self.drawings.append(obj)
    def path_stroke(self,name,path,width=.010):
        tree=BVHTree.FromObject(self.body,bpy.context.evaluated_depsgraph_get());targets=list(map(Vector,path));samples=[]
        for first,last in zip(targets,targets[1:]):
            for j in range(10):samples.append(tree.find_nearest(first.lerp(last,j/10))[0])
        samples.append(tree.find_nearest(targets[-1])[0]);samples=[p for i,p in enumerate(samples) if i==0 or (p-samples[i-1]).length>1e-5];vertices=[]
        for i,p in enumerate(samples):
            normal=tree.find_nearest(p)[1];tangent=(samples[min(i+1,len(samples)-1)]-samples[max(i-1,0)]).normalized();side=normal.cross(tangent).normalized();t=i/(len(samples)-1);pressure=.08+.92*math.sin(math.pi*t)**.7
            for sign in (-1,1):
                hit,n,_,_=tree.find_nearest(p+side*width*pressure*sign);vertices.append(hit+n*.011)
        obj=self.mesh(name,vertices,[(2*i,2*i+1,2*i+3,2*i+2) for i in range(len(samples)-1)],mats=(self.ink,));obj['intentional_open_ribbon']=True;self.drawings.append(obj)
    def crystal(self,name,center,width,depth,height,angles,material=1,clipped=True):
        center=Vector(center);matrix=Euler(angles).to_matrix();outline=[(-.53,-.17),(-.22,-.43),(.35,-.34),(.51,.13),(.13,.40),(-.39,.29)]
        base=[Vector((x*width*.70+.04,y*depth*.70+.06,-height*.61)) for x,y in outline]
        shoulder=[Vector((x*width,y*depth,height*.04+.09*x*width)) for x,y in outline]
        top=[Vector((x*width*.77-.03,y*depth*.77+.025,height*.49+.20*x*width-.09*y*depth)) for x,y in outline]
        obj=self.mesh(name,[matrix@v+center for v in base+shoulder+top],[tuple(range(5,-1,-1)),tuple(range(12,18))]+[(j+i,j+(i+1)%6,j+(i+1)%6+6,j+i+6) for j in (0,6) for i in range(6)],mats=(self.palette[material],))
        group=obj.vertex_groups.new(name='BuriedRoots');group.add(list(range(6)),1,'REPLACE')
        tree=BVHTree.FromObject(self.body,bpy.context.evaluated_depsgraph_get());adjusted=0
        for vertex in obj.data.vertices[:6]:
            hit,n,_,_=tree.find_nearest(vertex.co)
            if (vertex.co-hit).dot(n)>-.06:vertex.co=hit-n*.15;adjusted+=1
        if clipped:
            bm=bmesh.new();bm.from_mesh(obj.data)
            cut=bmesh.ops.bisect_plane(bm,geom=list(bm.verts)+list(bm.edges)+list(bm.faces),dist=.000001,plane_co=matrix@Vector((width*.19,-depth*.24,height*.39))+center,plane_no=matrix@Vector((1,-.25,1)).normalized(),clear_outer=True)
            bmesh.ops.holes_fill(bm,edges=[e for e in cut['geom_cut'] if isinstance(e,bmesh.types.BMEdge) and e.is_boundary],sides=0);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(obj.data);bm.free()
        self.uv(obj,matrix@Vector((0,0,1)),1.8);obj['solid_role']='Stout raw crystal with buried root ring';obj['root_vertices_fitted']=adjusted
        return obj
    def crystal_accent(self,obj,count=1):
        material=self.flat('Pale lavender facet accent',(.65,.40,.85));upper=max((p for p in obj.data.polygons if p.normal.z>.35),key=lambda p:p.center.z);ids=list(upper.vertices);edges=[]
        for a,b in zip(ids,ids[1:]+ids[:1]):
            first,last=obj.data.vertices[a].co.copy(),obj.data.vertices[b].co.copy();edges.append(((last-first).length,first,last))
        for i,(_,a,b) in enumerate(sorted(edges,key=lambda t:t[0],reverse=True)[:count]):
            tangent=(b-a).normalized();normal=upper.normal.normalized();middle=(a+b)*.5;inward=upper.center-middle;inward-=tangent*inward.dot(tangent);inward.normalize();center=middle+inward*.018+normal*.004;half=(b-a).length*.30;side=normal.cross(tangent).normalized()
            stroke=self.mesh(obj.name+'_PaleAccent_'+str(i+1),[center-tangent*half,center-side*.008,center+tangent*half,center+side*.008],[(0,1,3),(1,2,3)],mats=(material,));stroke['intentional_open_ribbon']=True;self.drawings.append(stroke)
    def finish(self,axis=(.75,.55,.7),span=4,view=(-1.8,-9,5.1),scale=6.35):
        if self.family=='violet':view=(-3,-8,4.18);scale=5.8
        if self.family=='verdant':view=(-2,-8,5.4);scale=5.9
        for obj in self.parts.objects:
            if obj.type=='MESH' and not obj.get('intentional_open_ribbon') and not obj.data.uv_layers:self.uv(obj,axis,span)
        for obj in self.author.objects:obj.hide_render=True;obj.hide_set(True)
        self.author.hide_render=True;self.author.hide_viewport=True
        scene=self.scene;scene.render.engine='CYCLES';scene.cycles.samples=32;scene.cycles.use_denoising=True
        scene.render.resolution_x=640;scene.render.resolution_y=440;scene.render.resolution_percentage=100;scene.render.image_settings.file_format='PNG';scene.render.image_settings.color_mode='RGBA';scene.render.film_transparent=True
        scene.world=bpy.data.worlds.new('Neutral studio');scene.world.use_nodes=True;scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.20,.23,.28,1);scene.world.node_tree.nodes['Background'].inputs[1].default_value=.45
        scene.view_settings.view_transform='AgX';scene.view_settings.look='AgX - Medium High Contrast'
        for name,location,power,size in [('Key',(-3,-4,7),900,3.5),('Fill',(4,-2,3),240,5),('Rim',(2,4,5),500,4)]:
            data=bpy.data.lights.new(name,'AREA');data.energy=power;data.shape='DISK';data.size=size;light=bpy.data.objects.new(name,data);self.review.objects.link(light);light.location=location;light.rotation_euler=(-light.location).to_track_quat('-Z','Y').to_euler()
        data=bpy.data.cameras.new('ReviewCamera');data.type='ORTHO';data.ortho_scale=scale;camera=bpy.data.objects.new('ReviewCamera',data);self.review.objects.link(camera);scene.camera=camera
        settings=bpy.context.view_layer.freestyle_settings
        for line in list(settings.linesets):settings.linesets.remove(line)
        contour_subject=self.collection('Contour solids')
        for obj in self.parts.objects:
            if obj.type=='MESH' and not obj.get('intentional_open_ribbon'):contour_subject.objects.link(obj)
        line=settings.linesets.new('Outer drawn contour')
        for prop in ('select_silhouette','select_border','select_crease','select_edge_mark','select_material_boundary','select_contour','select_suggestive_contour','select_ridge_valley'):setattr(line,prop,False)
        line.select_external_contour=True;line.select_by_collection=True;line.collection=contour_subject;line.collection_negation='INCLUSIVE';line.linestyle.color=(.003,.004,.009);line.linestyle.thickness=3.4;line.linestyle.caps='ROUND'
        noise=line.linestyle.thickness_modifiers.new('Hand pressure','NOISE');noise.amplitude=.65;noise.period=24;noise.seed=7;scene.render.use_freestyle=True
        target=(0,0,.1)
        def aim(direction):camera.location=Vector(target)+Vector(direction).normalized()*10;camera.rotation_euler=(Vector(target)-camera.location).to_track_quat('-Z','Y').to_euler()
        aim(view)
        for screen in bpy.data.screens:
            for area in screen.areas:
                if area.type=='VIEW_3D':area.spaces.active.region_3d.view_perspective='CAMERA';area.spaces.active.shading.type='MATERIAL';area.spaces.active.shading.use_scene_world=True;area.spaces.active.shading.use_scene_lights=True
        scene['art_status']='New bespoke candidate, no runtime integration';scene['outline']='Freestyle external contour is render-only; internal drawing meshes are retained'
        bpy.ops.object.select_all(action='DESELECT');self.body.select_set(True);bpy.context.view_layer.objects.active=self.body
        source=self.out/(self.id+'.blend');bpy.ops.wm.save_as_mainfile(filepath=str(source),relative_remap=False)
        def render(label):scene.render.filepath=str(self.out/(self.id+'-'+label+'.png'));bpy.ops.render.render(write_still=True);print('RENDER='+scene.render.filepath,flush=True)
        render('hero')
        scene.render.resolution_x=150;scene.render.resolution_y=110;line.linestyle.thickness=2.3;noise.amplitude=.4;render('150')
        scene.render.resolution_x=640;scene.render.resolution_y=440;line.linestyle.thickness=3.4;noise.amplitude=.65
        bpy.context.view_layer.material_override=self.clay;scene.render.use_freestyle=False
        for obj in self.drawings:obj.hide_render=True
        render('clay')
        bpy.context.view_layer.material_override=None;scene.render.use_freestyle=True
        for obj in self.drawings:obj.hide_render=False
        aim((6.8,-3.0,3.5));render('side');aim((3.3,7,4.4));render('reverse')
        self.metadata['source']=source.name;self.metadata['source_sha256']=hashlib.sha256(source.read_bytes()).hexdigest();self.metadata['preview_canvas']=[640,440];self.metadata['native_canvas']=[150,110]
        (self.out/'model.json').write_text(json.dumps(self.metadata,indent=2));print('MODEL_COMPLETE='+self.id,flush=True)
