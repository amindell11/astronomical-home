import bpy,bmesh,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from mathutils import Vector
from art_common import Model

PALETTE=[('Blue slate fracture','slate-paint.png',.52,.78,(.87,.95,1.06)),('Warm chalk exposure','chalk-paint.png',.86,.76,(1,.95,.84))]
m=Model('chalk',1,'Broken chalk laminae','Two unequal tapering fractured sheets with an interrupted lower ledge and a short side splinter; mineral bodies cross physical roofs and lips.',PALETTE)
m.metadata['owner_direction']='More thin, broken layers like the reference.'

def sheet(name,stations):
    top=[];bottom=[]
    for x,front,back,zf,zm,zb,tf,tb in stations:
        mid=front*.39+back*.61
        top.extend([(x,front,zf),(x+.035,mid,zm),(x-.025,back,zb)])
        bottom.extend([(x+.035,front+.10,zf-tf),(x+.02,mid,zm-(tf+tb)*.5),(x-.045,back-.065,zb-tb)])
    n=len(top);faces=[]
    for i in range(len(stations)-1):
        for j in range(2):
            a=i*3+j;b=(i+1)*3+j
            faces.extend([(a,b,b+1,a+1),(n+a+1,n+b+1,n+b,n+a)])
        a=i*3;b=(i+1)*3
        faces.extend([(a,n+a,n+b,b),(a+2,b+2,n+b+2,n+a+2)])
    faces.extend([(0,1,2,n+2,n+1,n),(n-3,2*n-3,2*n-2,2*n-1,n-1,n-2)])
    obj=m.mesh(name,top+bottom,faces,True);m.triangulate(obj);m.volumes.append(obj);m.metadata['construction_parts'].append(name)
    return obj

sheet('Long lower fractured lamina',[
    (-2.44,-.20,.20,-.36,-.22,-.12,.18,.20),(-2.07,-.80,.58,-.26,-.16,-.08,.24,.27),
    (-1.58,-.91,.80,-.25,-.12,-.06,.24,.27),(-1.15,-.78,.84,-.23,-.10,-.03,.19,.27),
    (-.68,-1.03,.83,-.24,-.11,-.03,.22,.26),(-.12,-.91,1.08,-.18,-.08,.02,.24,.28),
    (.42,-.97,1.07,-.15,-.03,.08,.21,.27),(.87,-.75,1.15,-.08,.03,.13,.25,.29),
    (1.33,-.76,1.28,-.07,.08,.17,.20,.29),(1.71,-.48,1.12,.00,.12,.23,.23,.29),
    (2.16,-.35,1.06,.05,.18,.24,.18,.27),(2.62,.11,.69,.11,.23,.26,.22,.25)])
sheet('Canted upper lamina with unequal broken ends',[
    (-2.35,-.18,.27,.04,.11,.15,.16,.23),(-2.15,-.62,.59,.10,.20,.23,.20,.30),
    (-1.56,-.72,.76,.17,.29,.27,.22,.38),(-1.25,-.53,.82,.22,.32,.28,.17,.41),
    (-.76,-.64,.79,.20,.31,.35,.18,.44),(-.39,-.40,1.00,.25,.39,.41,.23,.44),
    (.16,-.51,1.03,.31,.40,.45,.17,.48),(.68,-.24,.92,.35,.47,.52,.21,.50),
    (1.12,-.18,1.15,.40,.48,.55,.20,.50),(1.57,.08,1.10,.45,.52,.54,.18,.48),
    (1.92,.31,.77,.38,.48,.47,.20,.45)])
sheet('Short offset shale splinter',[
    (.78,-.72,.12,-.21,-.12,-.05,.12,.16),(1.12,-.91,.23,-.17,-.06,.02,.16,.17),
    (1.62,-.76,.43,-.11,-.03,.07,.13,.16),(2.05,-.49,.53,-.09,.03,.13,.16,.18),
    (2.40,-.20,.32,-.02,.09,.15,.12,.17)])
m.fuse()

def cutter(name,inner,outward):
    n=len(inner);verts=inner+[tuple(Vector(p)+Vector(outward)) for p in inner]
    obj=m.mesh(name,verts,[tuple(range(n-1,-1,-1)),tuple(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)],True)
    m.triangulate(obj);bpy.context.view_layer.objects.active=m.body
    mod=m.body.modifiers.new(name,'BOOLEAN');mod.operation='DIFFERENCE';mod.solver='EXACT';mod.object=obj;bpy.ops.object.modifier_apply(modifier=mod.name);m.triangulate(m.body)

cutter('Upper left broken lip',[(-1.90,-.54,.33),(-1.64,-.48,.34),(-1.43,-.69,-.03),(-1.81,-.80,-.13)],(0,-1,.02))
cutter('Diagonal end fracture',[(1.75,.24,.76),(1.58,.73,.74),(1.73,.71,.06),(2.06,.21,-.08)],(.65,.1,0))
cutter('Lower unequal edge break',[(-.66,-.80,-.12),(-.35,-.69,-.08),(-.13,-.97,-.53),(-.53,-1.14,-.60)],(0,-.9,0))
m.body['solid_role']='Connected fractured laminated rock';m.uv(m.body,(1,.2,.15),3.6)

def mineral(name,outline,base,slope=.06):
    n=len(outline);lower=[(x,y,base+slope*x-.09*y) for x,y in outline];upper=[(x,y,1.8) for x,y in outline]
    mask=m.mesh(name+' region volume',lower+upper,[tuple(range(n-1,-1,-1)),tuple(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)],True)
    m.triangulate(mask);obj=m.body.copy();obj.data=m.body.data.copy();obj.name=name;m.parts.objects.link(obj);obj.parent=m.root
    bpy.context.view_layer.objects.active=obj;mod=obj.modifiers.new('Mineral bounded by fractured host','BOOLEAN');mod.operation='INTERSECT';mod.solver='EXACT';mod.object=mask;bpy.ops.object.modifier_apply(modifier=mod.name)
    obj.data.materials.clear();obj.data.materials.append(m.palette[1])
    for face in obj.data.polygons:face.material_index=0
    for vertex in obj.data.vertices:vertex.co+=vertex.normal*.003
    obj['solid_role']='Embedded chalk exposure crossing roof and broken lamina edges';obj.data.update()
    for layer in list(obj.data.uv_layers):obj.data.uv_layers.remove(layer)
    m.uv(obj,(1,.2,.15),3.6)

mineral('Interrupted left pale exposure',[(-2.62,-.93),(-1.87,-1.04),(-1.63,-.82),(-1.27,-.77),(-1.13,-.49),(-.78,-.41),(-.83,-.18),(-1.04,-.14),(-1.01,.10),(-1.36,.23),(-1.59,.53),(-1.82,.42),(-2.12,.66),(-2.55,.37)],-.18)
mineral('Broken rear chalk stratum',[(.02,.66),(.31,.57),(.42,.28),(.70,.33),(.81,.18),(1.04,.31),(1.26,.15),(1.53,.29),(1.73,.19),(2.12,.33),(2.40,.23),(2.72,.70),(2.49,1.42),(.38,1.35),(.41,.99),(.05,.94)],.14)
mineral('Unequal lower pale layer',[(.02,-1.16),(.65,-1.25),(.91,-1.06),(1.40,-.97),(1.51,-.77),(1.93,-.63),(2.17,-.45),(2.56,-.19),(2.41,.09),(2.03,-.06),(1.72,-.24),(1.46,-.14),(1.13,-.39),(.99,-.28),(.77,-.52),(.49,-.47),(.34,-.72),(.03,-.69)],-.35,.035)
for i,point in enumerate([(-1.81,-.62,.09),(-1.22,-.54,.12),(-.45,-.43,.16),(.28,-.37,.24),(1.24,-.05,.29),(2.20,-.16,.04),(-.40,-.86,-.25)]):
    m.stroke('Drawing_Lamina_'+str(i+1),point,.009,start=.16,end=.72)
m.path_stroke('Drawing_UpperCrossFracture',[(-.94,.60,.34),(-.84,.35,.32),(-.91,.11,.28),(-.72,-.10,.29),(-.78,-.45,.23)],.007)
m.finish(axis=(1,.2,.15),span=3.6,view=(-1.8,-9,5.1),scale=6.0)
