"""Blender --background --python build_model.py -- FAMILY INDEX.

Writes the named model source, five actual renders and model.json under the set.
Exit 0 means completion; --python-exit-code 1 makes authoring errors fail the run.
"""
import sys,importlib
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
family,index=sys.argv[sys.argv.index('--')+1:];index=int(index)
module=importlib.import_module('models_'+family)
model=module.BUILDERS[index]()
if family=='verdant':
    for i,material in enumerate(model.palette):material['review_role']='pale_crust' if i==4 else 'ochre' if i==5 else 'verdant_dark'
    model.ink['review_role']='ink'
model.finish()
