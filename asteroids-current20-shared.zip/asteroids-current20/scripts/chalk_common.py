import bpy,bmesh
from mathutils import Vector
from art_common import Model

PALETTE=[('Blue slate fracture','slate-paint.png',.52,.78,(.87,.95,1.06)),('Warm chalk exposure','chalk-paint.png',.86,.76,(1,.95,.84))]

def sheet(m,name,stations):
    top=[];bottom=[]
    for x,front,back,zf,zm,zb,tf,tb in stations:
        mid=front*.39+back*.61
        top.extend([(x,front,zf),(x+.035,mid,zm),(x-.025,back,zb)])
        bottom.extend([(x+.035,front+min(.10,(back-front)*.20),zf-tf),(x+.02,mid,zm-(tf+tb)*.5),(x-.045,back-min(.065,(back-front)*.16),zb-tb)])
    n=len(top);faces=[]
    for i in range(len(stations)-1):
        for j in range(2):
            a=i*3+j;b=(i+1)*3+j
            faces.extend([(a,b,b+1,a+1),(n+a+1,n+b+1,n+b,n+a)])
        a=i*3;b=(i+1)*3
        faces.extend([(a,n+a,n+b,b),(a+2,b+2,n+b+2,n+a+2)])
    faces.extend([(0,1,2,n+2,n+1,n),(n-3,2*n-3,2*n-2,2*n-1,n-1,n-2)])
    obj=m.mesh(name,top+bottom,faces,True);m.triangulate(obj);m.volumes.append(obj);m.metadata['construction_parts'].append(name)
    return obj

def cutter(m,name,inner,outward):
    n=len(inner);verts=inner+[tuple(Vector(p)+Vector(outward)) for p in inner]
    obj=m.mesh(name,verts,[tuple(range(n-1,-1,-1)),tuple(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)],True)
    m.triangulate(obj);bpy.context.view_layer.objects.active=m.body
    mod=m.body.modifiers.new(name,'BOOLEAN');mod.operation='DIFFERENCE';mod.solver='EXACT';mod.object=obj;bpy.ops.object.modifier_apply(modifier=mod.name);m.triangulate(m.body)

def mineral(m,name,outline,base,slope=.06):
    n=len(outline);lower=[(x,y,base+slope*x-.09*y) for x,y in outline];upper=[(x,y,1.8) for x,y in outline]
    mask=m.mesh(name+' region volume',lower+upper,[tuple(range(n-1,-1,-1)),tuple(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)],True)
    m.triangulate(mask);obj=m.body.copy();obj.data=m.body.data.copy();obj.name=name;m.parts.objects.link(obj);obj.parent=m.root
    bpy.context.view_layer.objects.active=obj;mod=obj.modifiers.new('Mineral bounded by fractured host','BOOLEAN');mod.operation='INTERSECT';mod.solver='EXACT';mod.object=mask;bpy.ops.object.modifier_apply(modifier=mod.name)
    obj.data.materials.clear();obj.data.materials.append(m.palette[1])
    for face in obj.data.polygons:face.material_index=0
    for vertex in obj.data.vertices:vertex.co+=vertex.normal*.003
    obj['solid_role']='Embedded chalk exposure crossing roof and broken lamina edges';obj.data.update()
    for layer in list(obj.data.uv_layers):obj.data.uv_layers.remove(layer)
    m.uv(obj,(1,.2,.15),3.6)
