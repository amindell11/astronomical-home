"""Declare the curated 20-model set and its exact relative paths and hashes."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]
FAMILIES={'copper':(1,'Copper / turquoise'),'chalk':(3,'Illustrated blue / Chalk'),'verdant':(6,'Verdant Giant'),'ice':(7,'Blue Crescent / Ice')}
EXPECTED={'copper-01':'0c60959803e777bd116a11a1699edbcf182808b583cdeb9135c09a6623d7a694'}
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,data):(ROOT/path).write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
files={'README.md','catalog.json','validation-summary.json','source-hashes.json','deliverable-files.json','file-hashes.json','asteroid-set-overview.png'}
models=[];families=[];summaries=[]
for family,(locale,name) in FAMILIES.items():
    board=f'{family}/{family}-board.png';summary=f'{family}/{family}-validation-summary.json';report=f'{family}/{family}-validation.json'
    files.update((board,summary,report));summaries.append(json.loads((ROOT/summary).read_text()))
    families.append({'family':family,'locale_id':locale,'locale_name':name,'model_count':5,'board':board,'validation_summary':summary,'validation_report':report})
    for index in range(1,6):
        ident=f'{family}-{index:02d}';folder=f'{family}/{ident}';metadata=f'{folder}/model.json';data=json.loads((ROOT/metadata).read_text());source=f"{folder}/{data['source']}";source_hash=digest(ROOT/source)
        assert source_hash==data['source_sha256'],ident
        accepted=ident in EXPECTED
        if accepted:assert source_hash==EXPECTED[ident],ident
        views={key:f'{folder}/{ident}-{suffix}.png' for key,suffix in [('hero','hero'),('native150','150'),('clay','clay'),('side','side'),('reverse','reverse')]}
        model={'id':ident,'family':family,'locale_id':locale,'display_name':data['name'],'status':'accepted_immutable' if accepted else 'new_candidate','geometry_distinction':data['distinction'],'source':source,'source_sha256':source_hash,'previews':views,'preview_canvas':[640,440],'native_canvas':[150,110],'metadata':metadata}
        files.update((metadata,source));files.update(views.values())
        if accepted:
            support=[p.relative_to(ROOT).as_posix() for p in (ROOT/folder/'paint').iterdir() if p.is_file()]
            model['source_support_files']=support;files.update(support)
        models.append(model)
shared_paint=[{'path':p.relative_to(ROOT).as_posix(),'sha256':digest(p)} for p in sorted((ROOT/'paint').glob('*.png'))]
provenance=['paint/texture-provenance.json','copper/copper-01/paint/texture-provenance.json']
references=[f'references/reference-{family}.png' for family in FAMILIES]
scripts=['art_common.py','build_model.py','models_copper.py','models_verdant.py','models_ice.py','chalk_common.py','build_chalk01.py','build_chalk_companion.py','mineral_openings.py','make_family_board.py','make_set_overview.py','validate_family.py','make_catalog.py']
files.update(p['path'] for p in shared_paint);files.update(provenance);files.update(references);files.update('scripts/'+name for name in scripts)
catalog={'title':'Four active locales, five current asteroid models each','model_count':20,'accepted_immutable_count':1,'new_candidate_count':19,'families':families,'boards':['asteroid-set-overview.png']+[f'{f}/{f}-board.png' for f in FAMILIES],'models':models,'shared_paint':shared_paint,'paint_provenance':provenance,'references':references,'source_hashes':'source-hashes.json','validation':'validation-summary.json','delivery_file_list':'deliverable-files.json','file_hashes':'file-hashes.json'}
write('catalog.json',catalog)
all_solids=all(not s['solid_issues'] for s in summaries);all_connected=all(n==1 for s in summaries for n in s['host_component_counts'].values());new_roots=all(not s['new_root_issues'] for s in summaries)
validation={'model_count':20,'source_checks_complete':True,'closed_nondegenerate_solids':all_solids,'primary_hosts_single_component':all_connected,'new_buried_roots_pass':new_roots,'all_images_packed':all(s['all_images_packed'] for s in summaries),'all_source_hashes_match':all(s['all_source_hashes_match'] for s in summaries),'accepted_sources_exact':EXPECTED,'excluded_family':'Violet / NebulaGlow removed from this active review by owner ruling; original accepted Violet and the other four drafts remain in historical archives.','intentional_open_geometry':'Fitted internal drawing ribbons and pale accents are intentionally open, excluded from solid closure checks.','visual_review':'Copper01 accepted by owner. Copper02-05 and Ice01-05 retained draft sources; ten Chalk/Verdant sources revised for thin layers and categorical variation. Remaining 19 models are review candidates, not owner-approved as a complete set.','family_summaries':summaries,'scope':'Editable Blender sources and scratch Unity review exports/captures. No production spawn routing, runtime integration, merge or debris.'}
validation['source_verdict']='PASS_SOURCE_CHECKS' if all((all_solids,all_connected,new_roots,validation['all_images_packed'],validation['all_source_hashes_match'])) else 'ISSUES_REMAIN'
write('validation-summary.json',validation);write('source-hashes.json',{m['source']:m['source_sha256'] for m in models})
write('deliverable-files.json',{'files':sorted(files),'notes':'Exact curated files. Historical extra proofs, build logs, caches and diagnostic scripts are excluded.'})
hashes={path:{'sha256':digest(ROOT/path),'bytes':(ROOT/path).stat().st_size} for path in sorted(files) if path!='file-hashes.json'}
write('file-hashes.json',{'algorithm':'SHA256','self_omitted':True,'files':hashes})
print(json.dumps({'models':len(models),'curated_files':len(files),'bytes':sum(v['bytes'] for v in hashes.values()),'source_verdict':validation['source_verdict']}))
