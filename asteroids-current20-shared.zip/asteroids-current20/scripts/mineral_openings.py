import bpy,math
from mathutils import Vector

def recess(m,name,surface,faces,colors,normal):
    normal=Vector(normal).normalized();surface=list(map(Vector,surface));count=len(surface);edges={}
    for face in faces:
        for a,b in zip(face,face[1:]+face[:1]):edges.setdefault(tuple(sorted((a,b))),[]).append((a,b))
    boundary=[uses[0] for uses in edges.values() if len(uses)==1]
    cutter_faces=list(faces)+[tuple(i+count for i in f[::-1]) for f in faces]+[(a,b,b+count,a+count) for a,b in boundary]
    cutter=m.mesh(name+' cutter',surface+[p+normal*2 for p in surface],cutter_faces,True);m.triangulate(cutter)
    original=m.body.copy();original.data=m.body.data.copy();original.name='Host before '+name;m.author.objects.link(original)
    bpy.context.view_layer.objects.active=m.body
    mod=m.body.modifiers.new(name,'BOOLEAN');mod.operation='DIFFERENCE';mod.solver='EXACT';mod.object=cutter;bpy.ops.object.modifier_apply(modifier=mod.name);m.triangulate(m.body)
    liner_faces=list(faces)+[tuple(i+count for i in f[::-1]) for f in faces]+[(a,b,b+count,a+count) for a,b in boundary]
    liner=m.mesh(name,[p+normal*.004 for p in surface]+[p-normal*.12 for p in surface],liner_faces)
    for i,p in enumerate(liner.data.polygons):p.material_index=colors[i%len(faces)] if i<len(faces)*2 else 1
    bpy.context.view_layer.objects.active=liner;mod=liner.modifiers.new('Mineral fitted inside host','BOOLEAN');mod.operation='INTERSECT';mod.solver='EXACT';mod.object=original;bpy.ops.object.modifier_apply(modifier=mod.name)
    for p in liner.data.polygons:p.use_smooth=True
    liner['solid_role']='Physical mineral section recessed into original host';m.uv(liner,(1,.3,.2),2.8)
    return liner

def crescent(m):
    normal=Vector((0,-.55,.84)).normalized();u=Vector((1,0,0));v=normal.cross(u);center=Vector((-.74,-.19,.39));surface=[]
    angles=[-200,-176,-150,-124,-99,-75,-51,-27,-4,18]
    rings=[1,.85,.68,.53];n=len(angles)
    for j,r in enumerate(rings):
        for i,degrees in enumerate(angles):
            a=math.radians(degrees);w=[1,.97,1.03,.96,1.02,.98,1.04,.99,1.02,.96,1,.98,1.03,.95][i]
            x=1.13*r*w*math.cos(a)+.18*(1-r);y=.70*r*w*math.sin(a)-.05*(1-r)
            d=.23*math.sin(math.pi*(1-r)/.47)
            surface.append(center+u*x+v*y-normal*d)
    faces=[];colors=[]
    for j in range(3):
        for i in range(n-1):faces.append((j*n+i,j*n+i+1,(j+1)*n+i+1,(j+1)*n+i));colors.append([1,2,1][j] if i not in (0,1,10,11,12) else 1)
    return recess(m,'Partial crescent around intact stone center',surface,faces,colors,normal)

def vein(m):
    normal=Vector((-.12,-.58,.81)).normalized();u=Vector((1,0,0));u=(u-normal*u.dot(normal)).normalized();v=normal.cross(u);center=Vector((-.50,-.25,.36));surface=[]
    path=[(-1.60,-.20,.11),(-1.20,-.13,.15),(-.78,-.20,.16),(-.32,-.02,.13),(.12,.06,.18),(.53,.02,.15),(.88,.19,.12),(1.16,.24,.08)]
    for x,y,width in path:
        for t in (-1,-.45,.42,1):surface.append(center+u*x+v*(y+t*width)-normal*(.12*(1-t*t)))
    faces=[];colors=[]
    for i in range(len(path)-1):
        for j in range(3):faces.append((4*i+j,4*(i+1)+j,4*(i+1)+j+1,4*i+j+1));colors.append(2 if j==1 else 1)
    return recess(m,'Narrow irregular jade vein',surface,faces,colors,normal)
