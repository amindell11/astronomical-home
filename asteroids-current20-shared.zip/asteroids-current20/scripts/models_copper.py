from art_common import Model
def foot(top,z,dx=-.32,dy=.08,taper=.86):
    cx=sum(p[0] for p in top)/len(top);cy=sum(p[1] for p in top)/len(top)
    return [(cx+(x-cx)*taper+dx,cy+(y-cy)*taper+dy,z+.045*(x-cx)) for x,y,_ in top]
PALETTE=[('Slate','slate-paint.png',.48,.52),('Copper','copper-paint.png',.90,.56),('Turquoise','turquoise-paint.png',.78,.42)]
def copper02():
    m=Model('copper',2,'Forked shear ridge','Two unequal raised ridges diverge from a thick low root; short left toe and long lowered right fork.',PALETTE)
    top=[(-2.30,-.78,-.02),(-1.45,-1.12,.04),(-.38,-1.09,.19),(.77,-.87,.23),(1.28,-.23,.36),(.70,.58,.46),(-.58,.80,.38),(-1.95,.31,.18)]
    m.slab('Dense fork root',top,foot(top,-.68,dx=-.12,taper=.88))
    top=[(-1.79,-.56,.69),(-1.02,-.64,.94),(-.23,-.18,1.06),(.03,.65,1.18),(-.48,1.17,1.16),(-1.13,1.02,.94),(-1.96,.65,.68),(-2.20,.11,.43)]
    m.slab('Left leaning copper ridge',top,foot(top,-.38,dx=-.47,dy=.02,taper=.80),top_material=[1,1,0],side_materials={0:1,7:1})
    top=[(-.12,-1.11,.08),(.64,-1.23,.20),(1.81,-.90,.52),(2.51,-.36,.76),(2.39,.11,.88),(1.69,.45,.95),(.85,.34,.62),(.22,-.13,.39)]
    m.slab('Long forward right fork',top,foot(top,-.55,dx=-.20,taper=.88),top_material=[0,1,1],side_materials={1:1,2:1})
    top=[(-.22,.45,.55),(.49,.27,.68),(1.17,.58,.89),(1.09,1.12,1.02),(.23,1.38,.95),(-.45,1.06,.75)]
    m.slab('Rear connecting shoulder',top,foot(top,-.35,dx=-.08,taper=.84))
    m.fuse()
    m.cut('Left cliff oblique step',(-1.00,-.57,.20),(.15,.08,0),(.30,.11,.72),(0,-1.2,0))
    m.cut('Broken right fork end',(2.39,-.13,.30),(0,.47,.03),(.09,-.04,.70),(1,0,0),1)
    m.cut('Rear shoulder facet',(.19,1.20,.56),(.55,.06,.03),(.13,-.08,.52),(0,1,.04))
    m.skins([1])
    for i,(a,w) in enumerate([((-2.00,-.62,.04),.22),((-1.10,-.52,.87),.18),((.65,-.98,.22),.25),((2.10,.04,.78),.21),((.32,1.10,.91),.15)]):m.patch('Turquoise_'+str(i+1),a,w,2)
    for i,a in enumerate([(-1.03,-.48,.30),(-.25,.0,.83),(.58,-.86,.22),(1.80,-.55,.45),(.46,1.15,.7),(-1.90,.30,.55)]):m.stroke('Drawing_Fracture_'+str(i+1),a)
    m.path_stroke('Drawing_LeftRoofCrack',[(-1.52,.43,.79),(-1.26,.18,.90),(-1.10,-.30,.92),(-1.10,-.65,.70),(-1.27,-.64,.28)])
    m.path_stroke('Drawing_RightRoofCrack',[(1.40,.14,.78),(1.51,-.22,.70),(1.61,-.65,.51),(1.50,-.81,.10)],.009)
    return m
def copper03():
    m=Model('copper',3,'Offset copper tablet','Long canted upper tablet overlaps a broad low front ledge; one raised rear-left shoulder breaks the staggered profile.',PALETTE)
    top=[(-2.48,-.53,-.04),(-1.67,-1.03,.10),(-.49,-1.12,.13),(.85,-1.01,.16),(2.35,-.55,.36),(2.42,.07,.46),(.80,.64,.41),(-1.69,.47,.25)]
    m.slab('Long low ledge',top,foot(top,-.61,dx=-.12,taper=.91),top_material=[0,1,0],side_materials={3:1})
    top=[(-1.65,-.27,.67),(-.83,-.59,.87),(.51,-.36,.86),(1.77,.02,.99),(2.05,.49,1.05),(1.27,.92,1.08),(-.45,.97,.92),(-1.86,.45,.74)]
    m.slab('Canted copper tablet',top,foot(top,-.32,dx=-.42,dy=.13,taper=.88),top_material=[1,1,0],side_materials={0:1,1:1,7:1})
    top=[(-2.27,-.06,.36),(-1.83,-.46,.55),(-1.24,-.08,.85),(-1.25,.80,1.05),(-1.84,1.02,.91),(-2.40,.42,.60)]
    m.slab('Broken left shoulder',top,foot(top,-.43,dx=-.07,taper=.84))
    m.fuse()
    m.cut('Middle tablet shear',(.30,-.40,.31),(.19,.07,0),(.37,.16,.69),(0,-1.3,.02))
    m.cut('Oblique tablet end',(1.91,.39,.40),(0,.49,.03),(.13,-.05,.78),(1,0,.04),1)
    m.cut('Low ledge corner',(-2.14,-.77,-.17),(.46,.09,.05),(.10,.05,.47),(0,-1,0))
    m.skins([1])
    for i,(a,w) in enumerate([((-1.95,-.42,.31),.20),((-.63,-.47,.79),.20),((.94,-.87,.18),.23),((1.81,.32,.97),.18),((-.46,.83,.84),.14)]):m.patch('Turquoise_'+str(i+1),a,w,2)
    for i,a in enumerate([((.28,-.40,.28)),(-1.34,-.40,.59),(.84,-.88,.03),(1.87,.34,.66),(-1.97,.55,.67)]):m.stroke('Drawing_Fracture_'+str(i+1),a)
    m.path_stroke('Drawing_TabletCrack',[(-.38,.57,.91),(-.18,.22,.89),(-.40,-.20,.84),(-.48,-.52,.69),(-.66,-.49,.19)])
    m.path_stroke('Drawing_LowerCrack',[(1.25,-.41,.34),(1.10,-.67,.27),(1.18,-.94,.12),(1.03,-.94,-.18)],.009)
    return m
def copper04():
    m=Model('copper',4,'Stepped copper core','Single dominant left/back peak with a low right shelf tucked underneath and a broad off-center front-right setback.',PALETTE)
    top=[(-1.84,-.55,.22),(-1.31,-1.17,.27),(-.52,-1.20,.33),(.30,-.73,.34),(.31,.10,.46),(-.11,.84,.63),(-1.15,1.01,.59),(-1.94,.29,.40)]
    m.slab('Left core footing',top,foot(top,-.74,dx=-.03,taper=.88))
    top=[(-1.13,-.80,.94),(-.43,-.84,1.22),(.26,-.22,1.43),(.33,.56,1.45),(-.21,1.06,1.31),(-.95,.96,1.02),(-1.49,.45,.79),(-1.51,-.16,.70)]
    m.slab('High copper core',top,foot(top,-.43,dx=-.38,taper=.82),top_material=[1,1,0],side_materials={0:1,7:1})
    top=[(-.18,-.94,-.03),(.59,-1.10,.08),(1.53,-.67,.23),(1.90,-.08,.36),(1.53,.55,.47),(.90,.84,.43),(.35,.45,.34),(-.20,-.14,.19)]
    m.slab('Heavy right broken shoulder',top,foot(top,-.65,dx=-.12,taper=.87),top_material=[0,1,1],side_materials={1:1,2:1})
    m.fuse()
    m.cut('Broad front-right setback',(.90,-.79,.05),(.60,.20,0),(.22,.11,.60),(0,-1.1,.02))
    m.cut('Core left shoulder fracture',(-1.62,.32,.43),(.03,.54,.07),(-.12,.07,.61),(-1,0,.02))
    m.cut('Right core broken end',(1.69,-.15,.20),(.07,.45,.06),(.10,-.04,.64),(1,0,.04),1)
    m.skins([1])
    for i,(a,w) in enumerate([((-1.51,-.65,.26),.22),((-.71,-.74,1.03),.20),((.68,-.95,.24),.23),((1.43,.40,.76),.18)]):m.patch('Turquoise_'+str(i+1),a,w,2)
    for i,a in enumerate([(-.19,-.45,.32),(-.74,-.79,.63),(.62,-.88,.07),(1.50,.16,.44),(-1.40,.61,.68)]):m.stroke('Drawing_Fracture_'+str(i+1),a)
    m.path_stroke('Drawing_CoreCrack',[(-.61,.48,1.14),(-.37,.15,1.22),(-.55,-.32,1.14),(-.58,-.84,.92),(-.77,-.83,.39)])
    return m
def copper05():
    m=Model('copper',5,'Broken copper blade','Narrow long diagonal blade with a blunt broken nose, displaced central shear, and a shorter dark rear spine.',PALETTE)
    top=[(-2.48,-.38,.08),(-1.78,-.72,.19),(-.42,-.70,.31),(1.03,-.39,.53),(2.29,-.10,.67),(2.49,.37,.72),(1.12,.76,.57),(-1.96,.54,.34)]
    m.slab('Long blade foundation',top,foot(top,-.51,dx=-.14,taper=.91),top_material=[0,1,0],side_materials={2:1,3:1})
    top=[(-2.13,-.11,.64),(-1.43,-.48,.78),(-.32,-.34,.95),(.64,.04,.99),(.91,.52,.97),(.18,.93,.88),(-1.12,.81,.78),(-2.28,.38,.55)]
    m.slab('Leaning copper blade crest',top,foot(top,-.25,dx=-.40,taper=.87),top_material=[1,1,0],side_materials={0:1,1:1,7:1})
    top=[(.34,.20,.60),(1.07,.07,.76),(1.79,.38,.86),(1.83,.82,.93),(.97,1.05,.95),(.25,.78,.80)]
    m.slab('Short dark back spine',top,foot(top,-.22,dx=-.12,taper=.85))
    m.fuse()
    m.cut('Diagonal open blade nose',(-2.10,-.20,.10),(.12,.55,.03),(.25,.02,.55),(-1,-.15,.03),1)
    m.cut('Rear spine clipped shoulder',(1.68,.70,.50),(.05,.42,.04),(.12,-.08,.55),(1,0,.02))
    m.skins([1])
    for i,(a,w) in enumerate([((-2.17,-.29,.46),.20),((-1.07,-.41,.75),.17),((.54,-.47,.40),.23),((2.04,.10,.65),.21)]):m.patch('Turquoise_'+str(i+1),a,w,2)
    for i,a in enumerate([(-.39,-.34,.27),(-1.62,-.42,.52),(.67,-.40,.27),(1.78,.58,.73),(-1.85,.45,.55)]):m.stroke('Drawing_Fracture_'+str(i+1),a)
    m.path_stroke('Drawing_BladeCrack',[(-1.13,.45,.78),(-.96,.15,.85),(-1.10,-.30,.79),(-1.17,-.51,.55),(-1.29,-.45,.18)])
    m.path_stroke('Drawing_EndCrack',[(1.63,.39,.64),(1.45,.09,.60),(1.62,-.25,.52),(1.52,-.37,.19)],.009)
    return m
BUILDERS={2:copper02,3:copper03,4:copper04,5:copper05}
