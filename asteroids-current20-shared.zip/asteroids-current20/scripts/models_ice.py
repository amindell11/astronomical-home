from mathutils import Vector,Matrix
from mathutils.bvhtree import BVHTree
import bpy
from art_common import Model
from models_copper import foot
PALETTE=[('Frozen blue mantle','ice-paint.png',1,.86),('Embedded dark stone','slate-paint.png',.42,.50,(.89,.91,.93)),('Fresh pale ice','ice-paint.png',1.03,.98,(.95,1,1.05))]
def inclusion(m,name,anchor,width,depth,height=.48,spin=0):
    tree=BVHTree.FromObject(m.body,bpy.context.evaluated_depsgraph_get());point,normal,_,_=tree.find_nearest(Vector(anchor));matrix=normal.to_track_quat('Z','Y').to_matrix()@Matrix.Rotation(spin,3,'Z')
    outline=[(-.53,-.17),(-.22,-.43),(.35,-.34),(.51,.13),(.13,.40),(-.39,.29)]
    vertices=[point+matrix@Vector((x*width*.74,y*depth*.74,-.39)) for x,y in outline]+[point+matrix@Vector((x*width,y*depth,.035+.05*x-.025*y)) for x,y in outline]
    obj=m.mesh(name,vertices,[tuple(range(5,-1,-1)),(6,7,8,11),(8,9,10,11)]+[(i,(i+1)%6,(i+1)%6+6,i+6) for i in range(6)],mats=(m.palette[1],))
    group=obj.vertex_groups.new(name='BuriedRoots');group.add(list(range(6)),1,'REPLACE')
    for vertex in obj.data.vertices[:6]:
        hit,n,_,_=tree.find_nearest(vertex.co)
        if (vertex.co-hit).dot(n)>-.06:vertex.co=hit-n*.15
    m.uv(obj,matrix@Vector((0,1,0)),2.4);obj['solid_role']='Broad shallow rock section with buried root ring';return obj

def rock_rib(m,name,top,bottom):
    obj=m.slab(name,top,bottom,top_material=1,side_materials={i:1 for i in range(len(top))})
    m.author.objects.unlink(obj);m.parts.objects.link(obj);obj.parent=m.root;m.volumes.remove(obj)
    for face in obj.data.polygons:face.material_index=1
    group=obj.vertex_groups.new(name='BuriedRoots');group.add(list(range(len(top))),1,'REPLACE')
    tree=BVHTree.FromObject(m.body,bpy.context.evaluated_depsgraph_get())
    for vertex in obj.data.vertices[:len(top)]:
        hit,n,_,_=tree.find_nearest(vertex.co)
        if (vertex.co-hit).dot(n)>-.06:vertex.co=hit-n*.15
    obj['solid_role']='Substantial embedded rock rib crossing an ice fracture';return obj
def ice_ink(m,anchors,path):
    m.ink.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value=(.045,.095,.16,1)
    for i,a in enumerate(anchors):m.stroke('Drawing_IceFracture_'+str(i+1),a,.010)
    m.path_stroke('Drawing_IceCrack',path,.009)
def ice01():
    m=Model('ice',1,'Broad frozen mantle','Thick broad ice mantle consists of crossing offset fracture plates; shallow dark inclusions are enclosed by pale ice on the top and broken edge.',PALETTE)
    top=[(-2.47,-.56,.12),(-1.73,-1.02,.25),(-.45,-1.07,.35),(.88,-.84,.41),(2.13,-.30,.51),(2.29,.37,.57),(.87,.88,.47),(-1.98,.67,.34)]
    m.slab('Broad frozen foundation',top,foot(top,-.62,dx=-.12,taper=.91),top_material=[0,2,0])
    top=[(-1.95,-.12,.58),(-1.17,-.53,.76),(-.24,-.24,.86),(.37,.36,.95),(.16,.96,1.04),(-.77,1.17,.94),(-1.94,.85,.77),(-2.28,.29,.54)]
    m.slab('Left pale ice plate',top,foot(top,-.25,dx=-.25,taper=.87),top_material=[2,0,2],side_materials={0:2})
    top=[(-.14,-.81,.43),(.71,-1.00,.48),(1.64,-.57,.73),(2.40,.01,.91),(2.27,.63,1.02),(1.41,1.02,1.07),(.43,.78,.85),(-.27,.14,.60)]
    m.slab('Crossing right ice plate',top,foot(top,-.29,dx=-.17,taper=.88),top_material=[0,2,0],side_materials={6:2})
    m.fuse()
    m.cut('Mantle blunt left fracture',(-2.23,-.24,.01),(.06,.53,.05),(.18,.04,.66),(-1,0,.03),2)
    m.cut('Right crossing ice break',(2.18,.31,.43),(.05,.48,.05),(.16,-.06,.68),(1,0,.03))
    m.cut('Broken rear ice shoulder',(.78,1.03,.61),(.62,.05,.04),(.14,-.08,.55),(0,1,.04),2)
    m.skins([2],erode=False)
    top=[(-1.72,-.76,.31),(-1.43,-1.05,.24),(-1.02,-.98,.32),(-.78,-.56,.42),(-1.12,-.27,.67),(-1.53,-.31,.55)]
    rock_rib(m,'Rock crossing front fracture',top,[(-1.95,-.77,-.46),(-1.65,-1.00,-.55),(-1.29,-1.01,-.48),(-1.13,-.51,-.42),(-1.37,-.25,-.40),(-1.69,-.35,-.43)])
    inclusion(m,'Stone_RightPlate',(1.56,.42,.91),.93,.72,.46,-.38)
    ice_ink(m,[(-1.50,-.41,.49),(-.39,-.73,.31),(.73,-.80,.41),(1.88,.18,.60),(-.59,.97,.72)],[(-.98,.56,.87),(-.75,.27,.88),(-.89,-.18,.79),(-1.04,-.53,.54),(-1.17,-.55,.19)])
    return m
def ice02():
    m=Model('ice',2,'Ice blade and stone spine','Slender canted ice blade breaks along a long irregular embedded rock spine; a lower opposite ice shard closes the root.',PALETTE)
    top=[(-2.63,-.40,-.02),(-1.91,-.69,.08),(-.56,-.49,.35),(.90,-.27,.55),(2.35,.06,.70),(2.48,.48,.77),(.77,.78,.65),(-1.98,.24,.19)]
    m.slab('Long canted ice blade',top,foot(top,-.46,dx=-.14,taper=.91),top_material=[0,2,0],side_materials={2:2})
    top=[(-1.18,-.61,-.02),(-.49,-.93,.01),(.77,-.75,.18),(1.88,-.27,.38),(1.40,.17,.46),(.32,.28,.31),(-.78,.03,.12)]
    m.slab('Lower crossing ice shard',top,foot(top,-.48,dx=-.17,taper=.85),top_material=[2,0,2])
    m.fuse();m.cut('Blade blunt left break',(-2.32,-.23,-.01),(.05,.36,.04),(.20,.04,.43),(-1,0,.03),2)
    m.cut('Ice blade oblique end',(2.24,.19,.39),(.07,.40,.02),(.19,-.04,.51),(1,.03,.02))
    m.cut('Crossing lower shard end',(1.46,-.48,.03),(.38,.15,.03),(.12,.04,.39),(.3,-1,.03),2)
    m.skins([2],erode=False)
    top=[(-2.07,.04,.22),(-1.12,-.15,.34),(.19,.06,.60),(1.54,.25,.72),(1.74,.53,.78),(.66,.61,.70),(-.65,.38,.46),(-1.77,.31,.26)]
    bottom=foot(top,-.29,dx=-.08,taper=.82);rock_rib(m,'Exposed stone spine',top,bottom)
    ice_ink(m,[(-1.60,-.41,.10),(-.50,-.55,.20),(.70,-.55,.19),(1.77,.20,.48),(.20,.59,.49)],[(-.20,.49,.56),(-.04,.24,.56),(-.27,-.19,.42),(-.43,-.50,.22)])
    return m

def ice03():
    m=Model('ice',3,'Broken frozen arc','A thick bent ice mass wraps a broken inner notch, with one high rear arm and a lower forward ice horn enclosing a rock root.',PALETTE)
    top=[(-2.05,-.40,.29),(-1.34,-.75,.31),(-.35,-.32,.51),(.20,.33,.68),(-.03,1.07,.78),(-.82,1.37,.88),(-1.91,.94,.69),(-2.30,.29,.43)]
    m.slab('High rear frozen arc',top,foot(top,-.55,dx=-.21,taper=.88),top_material=[2,0,2],side_materials={2:2})
    top=[(-.99,-.65,.17),(-.61,-1.12,.17),(.51,-1.13,.31),(1.80,-.67,.47),(2.15,-.12,.56),(1.63,.42,.64),(.76,.28,.49),(-.29,-.23,.29)]
    m.slab('Low forward ice horn',top,foot(top,-.58,dx=-.10,taper=.86),top_material=[0,2,0])
    top=[(-.83,.21,.35),(-.14,.04,.32),(.89,.39,.60),(1.37,.91,.87),(.93,1.28,.92),(-.38,1.17,.78)]
    m.slab('Rear elbow of arc',top,foot(top,-.36,dx=-.19,taper=.84),top_material=[0,2])
    top=[(-1.04,-.34,.10),(-.53,-.56,.08),(.19,-.42,.11),(.57,-.02,.17),(.21,.52,.26),(-.64,.48,.24)]
    m.slab('Low solid elbow joining arc arms',top,foot(top,-.51,dx=-.09,taper=.90),top_material=0)
    m.fuse();m.cut('Broken ice horn end',(1.89,-.16,.22),(.06,.47,.03),(.17,-.05,.61),(1,0,.02),2)
    m.cut('Left thick arc fracture',(-2.00,.20,.09),(.06,.48,.03),(.15,.05,.58),(-1,0,.03))
    m.cut('Rear arc angled break',(.70,1.14,.55),(.48,.06,.02),(.17,-.09,.48),(.1,1,.03),2)
    m.skins([2],erode=False)
    top=[(-1.71,-.37,.33),(-1.25,-.70,.29),(-.87,-.54,.39),(-.62,-.04,.47),(-.99,.27,.63),(-1.46,.12,.51)]
    rock_rib(m,'Rock root in inner bend',top,foot(top,-.40,dx=-.08,taper=.8))
    inclusion(m,'Far horn rock section',(1.25,-.44,.45),.92,.60,spin=.57)
    ice_ink(m,[(-1.76,.13,.41),(-.99,-.51,.26),(.33,-.84,.24),(1.58,-.32,.39),(.66,.91,.73)],[(-1.43,.79,.73),(-1.16,.50,.72),(-1.32,.12,.57),(-1.53,-.26,.32)])
    return m

def ice04():
    m=Model('ice',4,'Split frozen peak','Compact high ice peak splits into two unequal broad fracture masses, with dark rock crossing the lower cleft and a small upper stone exposure.',PALETTE)
    top=[(-1.67,-.54,.32),(-.93,-.92,.40),(-.12,-.63,.67),(.39,.06,.96),(.21,.83,1.29),(-.56,1.12,1.42),(-1.50,.66,1.04),(-1.83,.02,.52)]
    m.slab('High split ice peak',top,foot(top,-.64,dx=-.21,taper=.83),top_material=[0,2,0],side_materials={1:2})
    top=[(-.39,-.86,.11),(.45,-1.08,.18),(1.47,-.68,.44),(1.91,-.02,.69),(1.62,.76,.88),(.84,.98,.92),(.12,.43,.59),(-.51,-.10,.35)]
    m.slab('Lower opposing frozen mass',top,foot(top,-.62,dx=-.14,taper=.85),top_material=[2,0,2])
    m.fuse();m.cut('Peak left broad chipped face',(-1.54,-.09,.15),(.06,.46,.03),(.20,.04,.69),(-1,0,.03),2)
    m.cut('Peak right low broken end',(1.62,.16,.32),(.05,.48,.04),(.14,-.05,.66),(1,0,.03))
    m.cut('Peak oblique rear loss',(-.25,.93,1.04),(.48,.06,.02),(.17,-.09,.70),(0,1,.02),2)
    m.skins([2],erode=False)
    top=[(-.53,-.80,.28),(-.19,-1.00,.22),(.23,-.87,.31),(.42,-.38,.47),(.09,.02,.71),(-.33,-.10,.56)]
    rock_rib(m,'Stone crossing lower split',top,[(-.85,-.69,-.52),(-.44,-.94,-.56),(-.10,-.87,-.50),(.12,-.36,-.43),(-.10,-.02,-.32),(-.62,-.14,-.39)])
    inclusion(m,'Upper frozen stone section',(-.75,.48,1.09),.82,.61,spin=-.43)
    ice_ink(m,[(-1.26,-.39,.40),(-.15,-.66,.31),(.92,-.67,.35),(1.48,.29,.53),(-.42,.78,1.06)],[(-.94,.57,1.11),(-.76,.19,.91),(-.91,-.25,.65),(-1.14,-.61,.30)])
    return m

def ice05():
    m=Model('ice',5,'Stepped frozen slab','Long low frozen slab has a broad broken central step and an unequal uplifted end; buried rock is exposed in an oblique end fracture.',PALETTE)
    top=[(-2.61,-.39,-.02),(-2.05,-.81,.10),(-.61,-.88,.18),(.79,-.66,.24),(2.19,-.29,.38),(2.56,.20,.41),(1.54,.69,.42),(-2.05,.44,.20)]
    m.slab('Long low frozen body',top,foot(top,-.54,dx=-.12,taper=.91),top_material=[2,0,2])
    top=[(-.51,-.35,.41),(.23,-.51,.46),(1.26,-.25,.69),(2.11,.24,.80),(1.81,.74,.90),(.95,.99,.94),(.08,.66,.69),(-.64,.17,.47)]
    m.slab('Uplifted right frozen end',top,foot(top,-.19,dx=-.19,taper=.85),top_material=[0,2,0],side_materials={0:2})
    m.fuse();m.cut('Low slab left oblique end',(-2.28,-.12,-.06),(.05,.39,.03),(.18,.04,.43),(-1,0,.03),2)
    m.cut('Frozen end right shear',(2.08,.33,.39),(.05,.42,.04),(.16,-.04,.60),(1,.03,.02))
    m.cut('Uplifted end rear break',(.77,.84,.66),(.49,.07,.04),(.13,-.05,.46),(0,1,.02),2)
    m.skins([2],erode=False)
    top=[(-2.16,-.32,.16),(-1.80,-.73,.17),(-1.21,-.69,.20),(-.94,-.25,.29),(-1.35,.15,.35),(-1.91,.12,.27)]
    rock_rib(m,'Long slab buried left rib',top,foot(top,-.43,dx=-.19,taper=.79))
    inclusion(m,'Right step enclosed stone',(1.38,.39,.78),1.10,.59,spin=-.51)
    ice_ink(m,[(-1.77,-.56,.10),(-.67,-.68,.13),(.48,-.46,.39),(1.87,.21,.61),(.60,.72,.63)],[(-.15,.48,.66),(.03,.19,.61),(-.11,-.16,.47),(-.33,-.48,.27),(-.41,-.66,.03)])
    return m
BUILDERS={1:ice01,2:ice02,3:ice03,4:ice04,5:ice05}
