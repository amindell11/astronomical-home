import bpy,bmesh,math
from mathutils import Vector,Euler
from art_common import Model
from mineral_openings import crescent,vein
PALETTE=[('Dark mineral support','slate-paint.png',.32,.44,(.84,.97,.86)),('Deep jade','verdant-paint.png',.90,.58,(.66,.86,.62)),('Green mineral band','verdant-paint.png',.95,.88,(.84,1,.72)),('Pale olive band','verdant-paint.png',.78,1.02,(1,1,.67)),('Broken pale crust','chalk-paint.png',.82,.76,(1,.94,.81)),('Ochre seam','chalk-paint.png',1,.61,(1,.64,.16))]
def lobe(m,name,center,radii,angle,profile):
    center=Vector(center);matrix=Euler((.03,-.04,angle)).to_matrix();n=len(profile);levels=[(-.90,.42),(-.58,.80),(-.15,1.00),(.30,.95),(.66,.76),(.91,.40)];vertices=[]
    for z,r in levels:
        for i,w in enumerate(profile):
            theta=2*math.pi*i/n;vertices.append(center+matrix@Vector((radii[0]*r*w*math.cos(theta),radii[1]*r*w*math.sin(theta),radii[2]*z)))
    bottom=len(vertices);vertices.append(center+matrix@Vector((0,0,-radii[2])));top=len(vertices);vertices.append(center+matrix@Vector((0,0,radii[2])))
    faces=[]
    for j in range(len(levels)-1):
        for i in range(n):faces.append((j*n+i,j*n+(i+1)%n,(j+1)*n+(i+1)%n,(j+1)*n+i))
    faces.extend((bottom,(i+1)%n,i) for i in range(n));faces.extend((top,(len(levels)-1)*n+i,(len(levels)-1)*n+(i+1)%n) for i in range(n))
    obj=m.mesh(name,vertices,faces,True);m.triangulate(obj);m.volumes.append(obj);m.metadata['construction_parts'].append(name);return obj
def exposure(m,center,radii,normal,depth,profile,skew=(.08,-.04),band_break=(1,4),angle=0,uplift=0):
    center=Vector(center);normal=Vector(normal).normalized();u=Vector((1,0,0));u=(u-normal*u.dot(normal)).normalized();v=normal.cross(u).normalized();n=len(profile)
    u,v=u*math.cos(angle)+v*math.sin(angle),v*math.cos(angle)-u*math.sin(angle)
    rings=[1.0,.80,.61,.43,.22];surface=[]
    for j,r in enumerate(rings):
        for i,w in enumerate(profile):
            theta=2*math.pi*i/n;dx=math.cos(theta)*radii[0]*r*w+skew[0]*(1-r);dy=math.sin(theta)*radii[1]*r*w+skew[1]*(1-r)
            d=depth*(1-r*r)+.035*math.sin(theta*2)*r*(1-r)-uplift*(1-r)**3
            surface.append(center+u*dx+v*dy-normal*d)
    ci=len(surface);surface.append(center+u*skew[0]+v*skew[1]-normal*(depth-uplift))
    exposed=[];materials=[]
    for j in range(len(rings)-1):
        for i in range(n):
            exposed.append((j*n+i,j*n+(i+1)%n,(j+1)*n+(i+1)%n,(j+1)*n+i))
            color=[1,2,1,2][j]
            if j==2 and 8<=i<=12:color=3
            if j==3 and not 6<=i<=13:color=1
            if band_break[0]<=i<=band_break[1]:color=1
            materials.append(color)
    for i in range(n):exposed.append(((len(rings)-1)*n+i,(len(rings)-1)*n+(i+1)%n,ci));materials.append(1)
    front=[surface[i]+normal*2 for i in range(n)];cutter_vertices=surface+front;front_start=len(surface)
    cutter_faces=list(exposed)+[(front_start+i,front_start+(i+1)%n,(i+1)%n,i) for i in range(n)]+[tuple(front_start+i for i in range(n))]
    cutter=m.mesh('Curved mineral opening cutter',cutter_vertices,cutter_faces,True);m.triangulate(cutter)
    original=m.body.copy();original.data=m.body.data.copy();original.name='Host before mineral opening';m.author.objects.link(original)
    bpy.context.view_layer.objects.active=m.body
    mod=m.body.modifiers.new('Actual recessed mineral opening','BOOLEAN');mod.operation='DIFFERENCE';mod.solver='EXACT';mod.object=cutter;bpy.ops.object.modifier_apply(modifier=mod.name);m.triangulate(m.body)
    count=len(surface);upper=[p+normal*.004 for p in surface];lower=[p-normal*.12 for p in surface]
    liner_faces=list(exposed)+[tuple(i+count for i in f[::-1]) for f in exposed]+[(i,(i+1)%n,(i+1)%n+count,i+count) for i in range(n)]
    liner=m.mesh('Recessed_GreenMineral',upper+lower,liner_faces)
    for i,face in enumerate(liner.data.polygons):face.material_index=materials[i%len(exposed)] if i<2*len(exposed) else 1
    bpy.context.view_layer.objects.active=liner
    mod=liner.modifiers.new('Crust bounds constrain mineral exposure','BOOLEAN');mod.operation='INTERSECT';mod.solver='EXACT';mod.object=original;bpy.ops.object.modifier_apply(modifier=mod.name)
    for face in liner.data.polygons:face.use_smooth=True
    m.uv(liner,u+v*.5,2.8);liner['solid_role']='Curved recessed mineral bands, bounded by original rock volume';liner['band_structure']='Three unequal curved bands with one interrupted sector, separate material groups'
    return liner
PROFILE=[1,.98,1.04,.96,1.02,.94,1.06,.98,1.03,.95,1,.97,1.05,.94,1.02,.98]
def verdant01():
    m=Model('verdant',1,'Partial jade crescent','Broken green crescent wraps an intact off-center stone island; the host conceals the mineral center instead of carrying a full bowl.',PALETTE)
    lobe(m,'Large left mineral nodule',(-.91,.06,.02),(1.46,1.05,.85),-.12,PROFILE)
    lobe(m,'Smaller right crust lobe',(1.04,.16,.10),(1.13,.91,.74),.24,PROFILE[4:]+PROFILE[:4])
    m.fuse()
    m.cut('Left nodule fractured foot',(-2.05,-.38,-.20),(.06,.45,.05),(.15,.04,.49),(-1,-.1,.03))
    m.cut('Right crust blunt break',(1.92,.22,.16),(.06,.46,.05),(.13,-.04,.52),(1,0,.03))
    crescent(m)
    for face in m.body.data.polygons:
        p=face.center
        if (p.z>.46 and p.x<-.84 and (p.y>.05 or p.x<-1.50)) or (p.x>.45 and p.z>.35 and p.y<.54 and (p.x>1.35 or p.y>.12)) or (p.x<-.85 and p.y<-.70 and .02<p.z<.23):face.material_index=4
    m.skins([4],erode=True)
    for i,(a,w) in enumerate([((-1.55,-.55,.34),.15),((.62,-.42,.49),.20),((1.30,.37,.52),.16)]):m.patch('Ochre_Vein_'+str(i+1),a,w,5)
    for i,a in enumerate([(-1.80,-.53,.11),(-.77,-.63,.48),(.59,-.55,.31),(1.70,.15,.19),(-.25,.74,.45)]):m.stroke('Drawing_Crust_'+str(i+1),a,.010)
    m.path_stroke('Drawing_RightRindCrack',[(1.13,.45,.67),(1.38,.22,.57),(1.23,-.21,.54),(1.42,-.42,.26)],.009)
    return m
def verdant02():
    m=Model('verdant',2,'Narrow jade vein','Long crust nodule with a narrow irregular jade seam following a diagonal fracture; no bowl or broad central opening.',PALETTE)
    lobe(m,'Long low left nodule',(-.93,.02,-.04),(1.53,.91,.70),-.22,PROFILE[2:]+PROFILE[:2])
    lobe(m,'High right crust shoulder',(1.02,.22,.12),(1.19,.96,.82),.18,PROFILE[7:]+PROFILE[:7])
    m.fuse()
    m.cut('Open eroded left end',(-2.08,-.15,-.05),(.05,.54,.05),(.17,.03,.62),(-1,-.1,.02))
    m.cut('Right nodule broad break',(1.94,.28,.15),(.05,.49,.04),(.14,-.04,.60),(1,0,.03))
    vein(m)
    bm=bmesh.new();bm.from_mesh(m.body.data);before=sum(f.calc_area()<1e-10 for f in bm.faces)
    bmesh.ops.dissolve_degenerate(bm,edges=list(bm.edges),dist=.00001);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));after=sum(f.calc_area()<1e-10 for f in bm.faces)
    bm.to_mesh(m.body.data);bm.free();m.metadata['vein_boolean_degeneracy']={'before':before,'after':after}
    for face in m.body.data.polygons:
        p=face.center
        if (p.x<-1.12 and p.z>.26 and p.y>.05) or (p.x>.68 and p.z>.36 and (p.y>.12 or p.x>1.61)) or (-.40<p.x<.40 and .02<p.z<.22 and p.y<-.53):face.material_index=4
    m.skins([4])
    for i,(a,w) in enumerate([((-1.66,.12,.44),.19),((.32,-.39,.32),.23),((1.52,.38,.65),.18)]):m.patch('Ochre_Vein_'+str(i+1),a,w,5)
    for i,a in enumerate([(-1.91,-.38,.03),(-.56,-.64,.12),(.75,-.48,.34),(1.73,.40,.39),(-.40,.69,.39)]):m.stroke('Drawing_Crust_'+str(i+1),a,.010)
    m.path_stroke('Drawing_RightCrustCrack',[(1.15,.55,.72),(1.37,.24,.66),(1.21,-.13,.58),(1.45,-.39,.28)],.009)
    return m
def verdant03():
    m=Model('verdant',3,'Paired mineral windows','Two unequal recessed green windows on a compact nodule are separated by a substantial intact rock bridge.',PALETTE)
    lobe(m,'Compact central nodule',(-.23,.05,.03),(1.54,1.10,.91),.12,PROFILE[5:]+PROFILE[:5])
    lobe(m,'Low right crust fragment',(1.13,.15,-.12),(.78,.79,.62),-.27,PROFILE[9:]+PROFILE[:9])
    m.fuse()
    m.cut('Front-right notched wall',(1.17,-.50,.04),(.45,.18,.04),(.15,.07,.57),(0,-1.1,.02))
    m.cut('Left core clipped plane',(-1.50,-.13,.02),(.05,.50,.05),(.17,.04,.62),(-1,0,.03))
    exposure(m,(-.75,-.18,.37),(.62,.49),(0,-.50,.86),.32,PROFILE[1:]+PROFILE[:1],skew=(-.10,.04),band_break=(8,12),angle=.22)
    exposure(m,(.59,-.34,.17),(.37,.28),(.13,-.70,.70),.20,PROFILE[7:]+PROFILE[:7],skew=(.04,-.02),band_break=(0,5),angle=-.28)
    for face in m.body.data.polygons:
        p=face.center
        if (p.x<-.34 and p.z>.53 and p.y>.02) or (p.x>.62 and p.z>.21 and p.y>.21) or (p.x<-.85 and p.y<-.59 and -.02<p.z<.20):face.material_index=4
        q=p-Vector((-.75,-.18,.37));u=Vector((math.cos(.22),math.sin(.22)*.864,math.sin(.22)*.503));v=Vector((-math.sin(.22),math.cos(.22)*.864,math.cos(.22)*.503))
        if face.material_index==4 and (q.dot(u)/.62)**2+(q.dot(v)/.49)**2<1.10:face.material_index=0
    m.skins([4])
    for i,(a,w) in enumerate([((-.99,.16,.69),.18),((.65,.42,.51),.22),((-.84,-.68,.11),.18)]):m.patch('Ochre_Vein_'+str(i+1),a,w,5)
    for i,a in enumerate([(-1.28,-.30,.32),(-.19,-.65,.24),(.83,-.37,.12),(.88,.65,.33),(-.60,.83,.42)]):m.stroke('Drawing_Crust_'+str(i+1),a,.010)
    m.path_stroke('Drawing_BackRindCrack',[(.47,.67,.66),(.68,.41,.63),(.60,.05,.57),(.84,-.23,.25)],.009)
    return m
def verdant04():
    m=Model('verdant',4,'Exposed mineral core','A mostly exposed green mineral body is enclosed by broken pale rind on its rear and left shoulder, with dark support beneath.',[('Exposed mineral core','verdant-paint.png',.94,.79,(.75,.97,.64))]+PALETTE[1:]+[PALETTE[0]])
    lobe(m,'Low left supporting lobe',(-.93,.06,-.09),(1.20,.87,.66),-.17,PROFILE[10:]+PROFILE[:10])
    lobe(m,'High right mineral core',(.75,.17,.14),(1.33,1.08,.94),.22,PROFILE[3:]+PROFILE[:3])
    m.fuse()
    m.cut('Left root blunt fracture',(-1.98,-.11,-.11),(.05,.43,.04),(.13,.03,.48),(-1,-.06,.02))
    m.cut('High core right broken wall',(1.80,.35,.27),(.05,.52,.06),(.17,-.04,.64),(1,0,.03))
    m.cut('Exposed core broad fracture',(.82,-.54,.44),(.64,.13,.06),(.06,.08,.39),(0,-.7,.03))
    for face in m.body.data.polygons:
        p=face.center
        if (p.x<-.70 and p.z>.08) or (p.y>.49 and p.z>.30) or (p.x>1.51 and p.y>.05):face.material_index=4
        elif p.z<-.18 or (p.x<-.22 and p.y<-.47 and p.z<.04):face.material_index=6
    m.skins([4,6])
    for i,(a,w) in enumerate([((-1.22,.23,.43),.17),((1.50,.37,.72),.22),((.19,-.62,.20),.18)]):m.patch('Ochre_Vein_'+str(i+1),a,w,5)
    for i,a in enumerate([(-1.57,-.26,.12),(-.15,-.49,.23),(.66,-.62,.33),(1.54,.37,.51),(.34,.93,.60)]):m.stroke('Drawing_Crust_'+str(i+1),a,.010)
    m.path_stroke('Drawing_LeftRindCrack',[(-1.10,.39,.49),(-.85,.20,.50),(-.98,-.18,.42),(-.82,-.49,.13)],.009)
    return m
def verdant05():
    m=Model('verdant',5,'Nearly sealed mineral nodule','Mostly unbroken pale crust on an unequal double lobe; only a tiny green seam opens through the right end.',PALETTE)
    lobe(m,'Low long left lobe',(-1.03,.12,-.10),(1.38,.79,.64),-.08,PROFILE[7:]+PROFILE[:7])
    lobe(m,'Broad right lobe',(.99,.13,.04),(1.55,.88,.77),.12,PROFILE[12:]+PROFILE[:12])
    m.fuse()
    m.cut('Left low fracture end',(-2.18,-.05,-.07),(.05,.43,.03),(.16,.03,.48),(-1,0,.02))
    m.cut('Right curved nodule break',(2.22,.26,.13),(.05,.48,.04),(.15,-.04,.54),(1,0,.03))
    exposure(m,(1.97,-.30,.18),(.35,.12),(.50,-.75,.43),.12,PROFILE[4:]+PROFILE[:4],skew=(-.03,.01),band_break=(1,6),angle=.16)
    for face in m.body.data.polygons:
        p=face.center
        if (p.z>-.02 and (p.y>-.40 or p.x<-1.05 or p.x>1.29)) or (p.x<-.8 and p.z>-.20 and p.y>-.26):face.material_index=4
    m.skins([4])
    for i,(a,w) in enumerate([((-1.63,.18,.39),.18),((.80,.59,.49),.20),((1.73,-.12,.44),.18)]):m.patch('Ochre_Vein_'+str(i+1),a,w,5)
    for i,a in enumerate([(-1.96,-.22,.02),(-.84,-.53,.11),(.31,-.65,.10),(1.77,.21,.30),(.32,.72,.39)]):m.stroke('Drawing_Crust_'+str(i+1),a,.010)
    m.path_stroke('Drawing_RearRindCrack',[(1.27,.54,.58),(1.49,.28,.55),(1.36,-.12,.48),(1.55,-.36,.18)],.009)
    return m
BUILDERS={1:verdant01,2:verdant02,3:verdant03,4:verdant04,5:verdant05}
