"""Fresh-reopen FAMILY sources. Writes FAMILY-validation.json and a concise summary.

Reports solids separately from intentional drawing ribbons; never edits sources.
"""
import bpy,bmesh,json,hashlib,sys
from pathlib import Path
from mathutils.bvhtree import BVHTree
SET=Path(__file__).resolve().parents[1];family=sys.argv[sys.argv.index('--')+1];results=[]
for index in range(1,6):
    ident=f'{family}-{index:02d}';folder=SET/family/ident;meta=json.loads((folder/'model.json').read_text());path=folder/meta['source'];before=hashlib.sha256(path.read_bytes()).hexdigest();bpy.ops.wm.open_mainfile(filepath=str(path))
    visible=[o for o in bpy.data.objects if o.type=='MESH' and not o.hide_render];host=bpy.data.objects.get('Rock_Host') or bpy.data.objects.get('Ice_Host');tree=BVHTree.FromObject(host,bpy.context.evaluated_depsgraph_get());meshes=[];roots=[]
    for obj in visible:
        ribbon=bool(obj.get('intentional_open_ribbon')) or obj.name.startswith('Drawing_') or 'PaleAccent' in obj.name
        bm=bmesh.new();bm.from_mesh(obj.data);unseen=set(bm.verts);components=[]
        while unseen:
            seed=unseen.pop();stack=[seed];count=0
            while stack:
                v=stack.pop();count+=1
                for edge in v.link_edges:
                    other=edge.other_vert(v)
                    if other in unseen:unseen.remove(other);stack.append(other)
            components.append(count)
        meshes.append({'name':obj.name,'vertices':len(bm.verts),'faces':len(bm.faces),'boundary_edges':sum(e.is_boundary for e in bm.edges),'nonmanifold_edges':sum(not e.is_manifold for e in bm.edges),'zero_area_faces':sum(f.calc_area()<1e-10 for f in bm.faces),'component_vertices':components,'directional_uv':bool(obj.data.uv_layers),'intentional_open_ribbon':ribbon});bm.free()
        group=obj.vertex_groups.get('BuriedRoots')
        if group:
            vertices=[v for v in obj.data.vertices if any(g.group==group.index and g.weight>.5 for g in v.groups)];outside=[]
            for v in vertices:
                p=obj.matrix_world@v.co;hit,n,_,_=tree.find_nearest(p)
                if (p-hit).dot(n)>-.002:outside.append(v.index)
            roots.append({'object':obj.name,'sample_count':len(vertices),'outside_root_vertices':outside})
    images=[{'name':i.name,'packed':bool(i.packed_file),'relative_path':i.filepath,'dimensions':list(i.size)} for i in bpy.data.images if i.source=='FILE']
    after=hashlib.sha256(path.read_bytes()).hexdigest();assert before==after
    result={'id':ident,'accepted_immutable':index==1 and family in ('copper','violet'),'source_sha256':after,'metadata_hash_matches':meta['source_sha256']==after,'meshes':meshes,'images':images,'new_crystal_roots':roots}
    if family=='violet' and index==1:result['approved_exception']='Accepted source preserved unchanged; previously documented 9/24 root-ring vertices outside host. No newly authored roots are exempt.'
    solids=[m for m in meshes if not m['intentional_open_ribbon']];result['solid_issues']=[m['name'] for m in solids if m['boundary_edges'] or m['nonmanifold_edges'] or m['zero_area_faces'] or not m['directional_uv']]
    result['root_issues']=[r['object'] for r in roots if r['outside_root_vertices']];result['host_components']=len(next(m for m in meshes if m['name']==host.name)['component_vertices']);results.append(result)
    print('REOPENED='+ident,flush=True)
report={'family':family,'models':results};(SET/family/(family+'-validation.json')).write_text(json.dumps(report,indent=2))
summary={'family':family,'model_count':len(results),'solid_issues':{r['id']:r['solid_issues'] for r in results if r['solid_issues']},'new_root_issues':{r['id']:r['root_issues'] for r in results if r['root_issues']},'host_component_counts':{r['id']:r['host_components'] for r in results},'all_images_packed':all(i['packed'] for r in results for i in r['images']),'all_source_hashes_match':all(r['metadata_hash_matches'] for r in results),'accepted_exception':'Violet01 historical root-ring exception preserved' if family=='violet' else None}
(SET/family/(family+'-validation-summary.json')).write_text(json.dumps(summary,indent=2));print('SUMMARY='+json.dumps(summary),flush=True)
