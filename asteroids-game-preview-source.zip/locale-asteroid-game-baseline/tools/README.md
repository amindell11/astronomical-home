# Current-draft game baseline

This preview imports the historical 25-model draft into an isolated game capture. The owner has requested changes to Violet detail variety, Verdant exposure variety and Chalk forms. The full draft is not owner-approved. Its frozen Blender sources are preserved unchanged.

`export_preview.py` exports only visible mesh components from the frozen catalog. It retains separate material parts and fitted ink meshes, removes unused material slots from the export copy, and writes the exact mesh/material mapping in `assets/export-catalog.json`. It never saves a source `.blend`.

The existing Drawn/Surface shader's saturation control is confined to its separate paint-layer branch, which replaces plain base-map color. To reproduce the Blender materials without changing the shader, the exporter bakes each distinct material's Base Color into an unlit export swatch. No lighting, AO or specular response is baked. Original paint PNGs are unchanged. Flat graphite and lavender accent colors remain separate material values.

The preview assets are staged under `Assets/Visuals/Environment/Asteroids/LocaleReview` in agent-5 only. The scratch scenario is `scratch/capture/LocaleAsteroidBaselineScenario.cs`. The supported coordinated capture runner stages that source for its run. No shipping spawn routing, settings or locale prefabs are changed.

The scenario composes a presentation-enabled Session for each existing locale prefab, uses the authored game ObserverCam and a Crimson ship at prefab scale, and shows all five current models at unchanged relative scale. It captures flight zoom15 and close zoom9 at1280 by720. Existing Drawn/Contour materials provide runtime outlines; mesh ink and pale accents retain their own materials. Blender Freestyle is not exported.

The exporter also emits four axis markers and the saved camera view/up vectors from each source. The scenario measures the imported axes, then maps each source view onto the actual game camera basis. The measured conversion is sourceX to UnityX, sourceY to UnityZ, sourceZ to UnityY. It asserts both view and up alignment before filming. The calibration object is destroyed before capture. The preview contour is a private3.2px material clone; shipping materials are unchanged.

The shared Capture owner returns frame directories, written into `results/capture/locale-asteroid-baseline-index.json`. Actual screenshots still determine whether orientation, scale, material fit and contours read correctly. Source/export checks alone do not validate the game appearance.
