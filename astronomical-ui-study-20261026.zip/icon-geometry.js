const IconGeometry = (() => {
  const names = ['Lasers','Turbo Lasers','Charge Lasers','Railgun','Missiles','Rippers','Concussion'];
  const ids = ['lasers','turbo-lasers','charge-lasers','railgun','missiles','rippers','concussion'];
  const polygon = pts => `<polygon points="${pts.map(p => p.map(n => Number(n.toFixed(4))).join(',')).join(' ')}"/>`;
  const slash = (x1,y1,x2,y2,w) => polygon([[x1-w/2,y1],[x1+w/2,y1],[x2+w/2,y2],[x2-w/2,y2]]);
  function segment(weight=1) {
    const angles=[-78,-46,-14,18];
    const point=(r,a)=>[32+r*Math.cos(a*Math.PI/180),32+r*Math.sin(a*Math.PI/180)];
    return angles.map(a=>point(25,a)).concat([...angles].reverse().map(a=>point(25-7*weight,a)));
  }
  function shape(id,weight=1) {
    const w=7*weight;
    switch(id) {
      case 'lasers': return slash(8,57,42,17,w)+slash(25,52,59,12,w);
      case 'turbo-lasers': return slash(8,51,38,15,w)+slash(23,48,42,25,w)+slash(29,58,59,22,w);
      case 'charge-lasers': return slash(10,58,20,46,w)+slash(25,40,31,33,w)+slash(36,27,53,7,w);
      case 'railgun': return slash(10,59,54,7,w)+slash(16,36,27,23,4.5*weight)+slash(39,41,50,28,4.5*weight);
      case 'missiles': {
        const body=[[0,-25],[4,-17],[4,7],[10,16],[3,14],[-3,14],[-10,16],[-4,7],[-4,-17]].map(([x,y])=>[x*weight,y]);
        return `<g transform="translate(32 31) rotate(50) scale(1.15)">${polygon(body)}${polygon([[-2.6*weight,20],[2.6*weight,20],[2.6*weight,29],[-2.6*weight,29]])}</g>`;
      }
      case 'rippers': return slash(8,40,18,25,6*weight)+slash(23,30,38,7,6*weight)+slash(33,57,46,38,6*weight)+slash(47,33,58,16,6*weight);
      case 'concussion': {
        const p=polygon(segment(weight));
        return `<g>${p}</g><g transform="rotate(120 32 32)">${p}</g><g transform="rotate(240 32 32)">${p}</g>`;
      }
      default: throw new Error(`Unknown weapon icon: ${id}`);
    }
  }
  function svg(id,weight=1,color='#F1EEE5') {
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="${color}" role="img" aria-label="${names[ids.indexOf(id)]}">${shape(id,weight)}</svg>`;
  }
  function uri(id,weight=1,color='#F1EEE5') {return 'data:image/svg+xml;charset=utf-8,'+encodeURIComponent(svg(id,weight,color));}
  return {names,ids,shape,segment,svg,uri};
})();
