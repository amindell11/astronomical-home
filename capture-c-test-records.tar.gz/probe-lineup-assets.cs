var catalog = UnityEditor.AssetDatabase.LoadAssetAtPath<Ships.Loadout.ItemCatalog>(Ships.Loadout.ItemCatalog.AssetPath);
var rows = new System.Collections.Generic.List<string>();
foreach (var ship in catalog.Chassis) {
    if (!ship) { rows.Add("MISSING SHIP"); continue; }
    var path = UnityEditor.AssetDatabase.GetAssetPath(ship);
    var childRigs = ship.GetComponentsInChildren<Ships.Presentation.ShipVisualRig>(true);
    rows.Add(ship.name + " | " + path + " | serialized rig=" + (ship.VisualRig ? ship.VisualRig.name : "NULL") + " | child rigs=" + childRigs.Length);
}
return string.Join("\n", rows);
