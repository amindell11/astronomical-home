var catalog = UnityEditor.AssetDatabase.LoadAssetAtPath<Ships.Loadout.ItemCatalog>(Ships.Loadout.ItemCatalog.AssetPath);
var rows = new System.Collections.Generic.List<string>();
foreach (var ship in catalog.Chassis) {
    if (ship.VisualRig) continue;
    rows.Add(ship.name);
    foreach (var renderer in ship.GetComponentsInChildren<UnityEngine.Renderer>(true)) {
        var path = renderer.name;
        var parent = renderer.transform.parent;
        while (parent && parent != ship.transform) { path = parent.name + "/" + path; parent = parent.parent; }
        rows.Add(path + " | " + renderer.GetType().Name);
    }
}
return string.Join("\n", rows);
