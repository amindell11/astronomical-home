#if UNITY_EDITOR
using System;
using System.Collections;
using System.IO;
using System.Linq;
using System.Text;
using Capture.Recording;
using Ships;
using Tests.PlayMode.Recording;
using UnityEditor;
using UnityEngine;
using Object = UnityEngine.Object;

public sealed class ValisColourProbe : CaptureScenario
{
    public override bool NeedsSession => false;
    public override IEnumerator Run()
    {
        var ship = AssetDatabase.LoadAssetAtPath<Ship>("Assets/Prefabs/Ships/Valis.prefab");
        var folder = Path.GetFullPath(Path.Combine(Application.dataPath, "../../../results/valis-colour-probe-firstuse"));
        Directory.CreateDirectory(folder);
        using var scope = (IDisposable)Capture.GetType().GetMethod("PrepareLineupNeutral").Invoke(Capture, new object[] { new[] { "Vanguard", "Crimson", "Nightshade", "Valis", "Bulwark" }.Select(name => AssetDatabase.LoadAssetAtPath<Ship>("Assets/Prefabs/Ships/" + name + ".prefab")).ToArray() });
        var camera = Resources.FindObjectsOfTypeAll<Camera>().Single(c => c.name == "Lineup camera");
        var light = Resources.FindObjectsOfTypeAll<Light>().Single(c => c.name == "Neutral key");
        var renderer = camera.transform.parent.GetComponentsInChildren<SkinnedMeshRenderer>(true).Single(r => r.name == "Valis");
        var dump = new StringBuilder();
        dump.AppendLine("initialSun=" + (RenderSettings.sun ? RenderSettings.sun.name : "null"));
        foreach (var material in renderer.sharedMaterials)
            dump.AppendLine(AssetDatabase.GetAssetPath(material) + " | shader=" + material.shader.name + " | paper=" + (material.HasProperty("_PaperColor") ? material.GetColor("_PaperColor").ToString("R") : "absent"));
        var block = new MaterialPropertyBlock(); renderer.GetPropertyBlock(block);
        dump.AppendLine("blockEmpty=" + block.isEmpty);
        File.WriteAllText(Path.Combine(folder, "materials.txt"), dump.ToString());
        var priorAsync = EditorSettings.asyncShaderCompilation;
        try
        {
            yield return Film("async", true, renderer);
            yield return Film("synchronous", false, renderer);
        }
        finally { EditorSettings.asyncShaderCompilation = priorAsync; }
    }
    private IEnumerator Film(string name, bool async, SkinnedMeshRenderer renderer)
    {
        using var recording = Capture.Prepare(new CaptureRequest("results/valis-colour-probe-firstuse", name, Commit, 1024, 256,
            measurements: new System.Collections.Generic.Dictionary<string, Func<double>> { ["shader_compiling"] = () => ShaderUtil.anythingCompiling ? 1 : 0 }));
        yield return recording.Ready;
        EditorSettings.asyncShaderCompilation = async;
        var unique = "probe"+Guid.NewGuid().ToString("N");
        var source = File.ReadAllText(Path.Combine(Application.dataPath,"Visuals/Shaders/DrawnSurface.shader"))
            .Replace("Astronomical/Drawn/Surface", "Hidden/"+unique)
            .Replace("return half4(MixFog(color, input.fog), 1);", "half3 "+unique+" = color; return half4(MixFog("+unique+", input.fog), 1);");
        var shader = ShaderUtil.CreateShaderAsset(source, false);
        var original = renderer.sharedMaterials;
        var copies = original.Select(material => new Material(material)).ToArray();
        foreach(var material in copies) if(material.shader.name == "Astronomical/Drawn/Surface") material.shader = shader;
        renderer.sharedMaterials=copies;
        var folder = Path.GetFullPath(Path.Combine(Application.dataPath, "../../../results/valis-colour-probe-firstuse"));
        File.WriteAllText(Path.Combine(folder, name + "-state.txt"), "gameViewAsync="+EditorSettings.asyncShaderCompilation+" callAsync="+ShaderUtil.allowAsyncCompilation+" compiled="+string.Join(",",copies.Select(material => ShaderUtil.IsPassCompiled(material,0))));
        try {
            recording.Start();
            for(var frame=0;frame<8;frame++) yield return null;
            Result=recording.Finish();
        }
        finally { renderer.sharedMaterials=original; foreach(var material in copies) Object.DestroyImmediate(material); Object.DestroyImmediate(shader); }
    }
    private static void Direct(Camera camera,string path)
    {
        var rt = new RenderTexture(1024,256,24,RenderTextureFormat.ARGB32,RenderTextureReadWrite.sRGB);
        var previous=RenderTexture.active;
        var previousTarget=camera.targetTexture;
        var image=new Texture2D(1024,256,TextureFormat.RGB24,false);
        try {
            camera.targetTexture=rt; camera.Render(); camera.Render(); RenderTexture.active=rt;
            image.ReadPixels(new Rect(0,0,1024,256),0,0); image.Apply();
            File.WriteAllBytes(path,image.EncodeToPNG());
        }
        finally { RenderTexture.active=previous; camera.targetTexture=previousTarget; Object.DestroyImmediate(image); Object.DestroyImmediate(rt); }
    }
}
#endif
