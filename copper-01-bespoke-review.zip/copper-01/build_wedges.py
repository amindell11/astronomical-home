import bpy,bmesh,math
from pathlib import Path
from mathutils import Vector
OUT=Path(__file__).resolve().parent
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.context.preferences.filepaths.save_version=0
scene=bpy.context.scene
parts=bpy.data.collections.new('Copper 01, editable components');scene.collection.children.link(parts)
author=bpy.data.collections.new('Editable rock construction');scene.collection.children.link(author)
review=bpy.data.collections.new('Review cameras and lights');scene.collection.children.link(review)
root=bpy.data.objects.new('Asteroid_Copper_01',None);parts.objects.link(root)
def material(name,color):
    mat=bpy.data.materials.new(name);mat.use_nodes=True
    shader=mat.node_tree.nodes['Principled BSDF'];shader.inputs['Base Color'].default_value=(*color,1)
    shader.inputs['Roughness'].default_value=.94;shader.inputs['Specular IOR Level'].default_value=.12
    return mat
slate=material('Slate host',(.085,.085,.115));cu=material('Copper fracture',(.32,.125,.055));teal=material('Turquoise contact',(.045,.25,.23));clay=material('Neutral clay',(.32,.34,.36))
def mesh(name,vertices,faces,collection,mats=(slate,cu)):
    data=bpy.data.meshes.new(name+'Mesh');data.from_pydata(vertices,[],faces);data.update()
    for mat in mats:data.materials.append(mat)
    bm=bmesh.new();bm.from_mesh(data);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(data);bm.free()
    obj=bpy.data.objects.new(name,data);collection.objects.link(obj)
    if collection==parts:obj.parent=root
    return obj
def volume(name,bottom,top,ridges,roof,copper_sides=(),copper_roof=()):
    n=len(bottom);faces=[tuple(range(n-1,-1,-1))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
    faces += [tuple(n+i for i in face) for face in roof]
    obj=mesh(name,bottom+top+ridges,faces,author)
    for i in copper_sides:obj.data.polygons[1+i].material_index=1
    for i in copper_roof:obj.data.polygons[1+n+i].material_index=1
    bm=bmesh.new();bm.from_mesh(obj.data);bmesh.ops.triangulate(bm,faces=list(bm.faces));bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(obj.data);bm.free()
    return obj
left=volume('Dominant left shear slab',[
 (-1.85,-1.00,-.65),(-1.24,-1.12,-.76),(-.48,-.81,-.69),(.03,-.38,-.52),(-.17,.64,-.44),(-.64,1.03,-.45),(-1.66,.86,-.47),(-2.11,.25,-.41)],
 [(-1.24,-.99,.64),(-.75,-.89,.85),(.27,-.58,.77),(.58,-.08,.84),(.21,.73,1.03),(-.57,1.05,1.08),(-1.65,.77,.82),(-1.87,.20,.55)],
 [(-.65,.0,.99),(-.30,.55,1.11)],
 [(0,1,8),(1,2,3,8),(3,4,9,8),(4,5,9),(5,6,7,8,9),(7,0,8)],(0,7),(0,1,4,5))
right=volume('Displaced lower right blade',[
 (-.64,-1.13,-.65),(.16,-1.33,-.78),(1.12,-1.09,-.62),(2.07,-.68,-.50),(2.33,-.06,-.26),(1.87,.42,-.21),(.82,.42,-.28),(-.34,-.12,-.49)],
 [(-.34,-1.14,-.03),(.48,-1.15,.08),(1.33,-.87,.35),(2.19,-.40,.63),(2.29,.12,.82),(1.69,.53,.86),(.89,.29,.43),(-.13,-.23,.07)],
 [(.83,-.38,.50)],
 [(0,1,8),(1,2,3,8),(3,4,5,8),(5,6,8),(6,7,0,8)],(1,2),(1,2))
rear=volume('High rear right shoulder',[
 (-.25,-.05,-.51),(.55,-.08,-.56),(1.63,.21,-.44),(2.29,.48,-.17),(2.30,.88,.10),(1.70,1.24,-.10),(.45,1.27,-.48),(-.43,.62,-.50)],
 [(.14,.22,.57),(.68,.25,.80),(1.50,.35,.95),(2.20,.65,1.03),(2.14,.99,1.09),(1.43,1.21,1.19),(.48,1.22,1.09),(-.10,.72,.98)],
 [(.85,.73,1.12)],
 [(0,1,8,7),(1,2,3,8),(3,4,5,8),(5,6,7,8)])
toe=volume('Low broken left toe',[
 (-2.57,-.56,-.43),(-2.15,-1.00,-.59),(-1.55,-1.10,-.65),(-1.30,-.53,-.60),(-1.70,.40,-.39),(-2.37,.32,-.28)],
 [(-2.55,-.65,-.06),(-2.16,-1.00,.12),(-1.50,-.90,.19),(-1.23,-.43,.25),(-1.80,.36,.36),(-2.40,.27,.16)],[],[(0,1,2,3),(0,3,4,5)])
body=left.copy();body.data=left.data.copy();body.name='Rock_Host';parts.objects.link(body);body.parent=root
bpy.context.view_layer.objects.active=body;body.select_set(True)
for obj in (right,rear,toe):
    mod=body.modifiers.new('Fuse '+obj.name,'BOOLEAN');mod.operation='UNION';mod.solver='EXACT';mod.object=obj;bpy.ops.object.modifier_apply(modifier=mod.name)
body['construction']='Four individually laid out thick overlapping rock masses; full rear volume; hidden source volumes retained'
def fracture(name,center,u,v,outward,material_index=0):
    center,u,v,outward=map(Vector,(center,u,v,outward))
    inner=[center-u-v,center+u-v,center+u+v,center-u+v]
    cutter=mesh(name,[tuple(p) for p in inner+[p+outward for p in inner]],[(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)],author)
    for face in cutter.data.polygons:face.material_index=material_index
    mod=body.modifiers.new(name,'BOOLEAN');mod.operation='DIFFERENCE';mod.solver='EXACT';mod.object=cutter;bpy.ops.object.modifier_apply(modifier=mod.name)
fracture('Left toe oblique end',(-2.40,-.83,-.20),(.55,.04,-.06),(.0,.08,.55),(-.10,-.9,0))
fracture('Left shear crown break',(-.44,-.77,.78),(.37,.11,0),(.10,.10,.21),(0,-1,.10),1)
fracture('Left shoulder side break',(-1.70,.48,.66),(.22,.30,0),(0,-.04,.35),(-1,0,.10))
fracture('Right blade fractured edge',(1.89,-.73,.25),(.49,.22,.06),(0,.24,.82),(.15,-1,.05),1)
fracture('Right shoulder undercut',(2.16,.77,.52),(0,.36,.08),(.10,-.05,.44),(1,0,.02))
fracture('Rear slanted wall',(.52,1.15,.39),(.66,.04,.03),(.15,-.07,.42),(0,1,.10))
fracture('Oblique stepped wall shear',(-.335,-.64,.24),(.15,.10,0),(.37,.095,.73),(0,-1.4,-.03))
for obj in [body]+list(author.objects):
    for vertex in obj.data.vertices:
        vertex.co.x*=1.10;vertex.co.y*=.86;vertex.co.z*=.82
bm=bmesh.new();bm.from_mesh(body.data);bmesh.ops.triangulate(bm,faces=list(bm.faces));bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(body.data);bm.free()
def copper_sections():
    faces=[p for p in body.data.polygons if p.material_index==1]
    vertex_ids=sorted({i for p in faces for i in p.vertices});lookup={v:i for i,v in enumerate(vertex_ids)}
    normals={i:Vector() for i in vertex_ids}
    all_adjacency={tuple(sorted(e.vertices)):[] for e in body.data.edges}
    for face in body.data.polygons:
        ids=list(face.vertices)
        for a,b in zip(ids,ids[1:]+ids[:1]):all_adjacency[tuple(sorted((a,b)))].append(face)
    for face in faces:
        for i in face.vertices:normals[i]+=face.normal
    for i in normals:normals[i].normalize()
    upper=[body.data.vertices[i].co+normals[i]*.003 for i in vertex_ids]
    lower=[body.data.vertices[i].co-normals[i]*.045 for i in vertex_ids]
    exposed=[]
    for face in faces:
        source_ids=list(face.vertices);ids=[]
        for a,b in zip(source_ids,source_ids[1:]+source_ids[:1]):
            ids.append(lookup[a]);neighbors=all_adjacency[tuple(sorted((a,b)))];first,last=body.data.vertices[a].co,body.data.vertices[b].co
            length=(last-first).length;middle=(first+last)*.5
            is_roof_boundary=face.normal.z>.45 and middle.x<.70 and length>.42 and any(p.material_index==0 and p.normal.z>.35 for p in neighbors)
            if not is_roof_boundary:continue
            tangent=(last-first).normalized();inward=face.center-middle;inward-=tangent*inward.dot(tangent);inward.normalize()
            for t,d in [( .19,.024),(.32,.075),(.48,.032),(.63,.10),(.76,.043),(.88,.068)]:
                point=first.lerp(last,t)+inward*min(d,length*.075)
                ids.append(len(upper));upper.append(point+face.normal*.003);lower.append(point-face.normal*.045)
        exposed.append(ids)
    n=len(upper);polys=[];edges={}
    for ids in exposed:
        polys.append(tuple(ids));polys.append(tuple(i+n for i in ids[::-1]))
        for a,b in zip(ids,ids[1:]+ids[:1]):edges.setdefault(tuple(sorted((a,b))),[]).append((a,b))
    for uses in edges.values():
        if len(uses)==1:
            a,b=uses[0];polys.append((b,a,a+n,b+n))
    obj=mesh('Copper fitted fracture sections',[tuple(v) for v in upper+lower],polys,parts,(cu,))
    obj['attachment']='Same host triangles, shallow upper offset and buried thickness'
    return obj
copper=copper_sections()
for face in body.data.polygons:face.material_index=0
for obj in author.objects:obj.hide_render=True;obj.hide_set(True)
author.hide_render=True;author.hide_viewport=True

scene.render.engine='CYCLES';scene.cycles.samples=32;scene.cycles.use_denoising=True
scene.render.resolution_x=1100;scene.render.resolution_y=740;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG';scene.render.image_settings.color_mode='RGBA';scene.render.film_transparent=True
scene.world=bpy.data.worlds.new('Neutral studio');scene.world.use_nodes=True
scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.20,.23,.28,1);scene.world.node_tree.nodes['Background'].inputs[1].default_value=.45
scene.view_settings.view_transform='AgX';scene.view_settings.look='AgX - Medium High Contrast'
for name,location,power,size in [('Key',(-3,-4,7),900,3.5),('Fill',(4,-2,3),240,5),('Rim',(2,4,5),500,4)]:
    data=bpy.data.lights.new(name,'AREA');data.energy=power;data.shape='DISK';data.size=size
    light=bpy.data.objects.new(name,data);review.objects.link(light);light.location=location;light.rotation_euler=(-light.location).to_track_quat('-Z','Y').to_euler()
data=bpy.data.cameras.new('ReviewCamera');data.type='ORTHO';data.ortho_scale=6.35
camera=bpy.data.objects.new('ReviewCamera',data);review.objects.link(camera);scene.camera=camera
views={'hero':(-1.8,-9,5.1),'reverse':(3.3,7,4.4),'side':(6.8,-3.0,3.5)}
def aim(position):
    camera.location=position;camera.rotation_euler=(Vector((.05,0,.12))-camera.location).to_track_quat('-Z','Y').to_euler()
aim(views['hero'])
scene.render.use_freestyle=True
settings=bpy.context.view_layer.freestyle_settings
for line in list(settings.linesets):settings.linesets.remove(line)
line=settings.linesets.new('Outer drawn contour')
for prop in ('select_silhouette','select_border','select_crease','select_edge_mark','select_material_boundary','select_contour','select_suggestive_contour','select_ridge_valley'):setattr(line,prop,False)
line.select_external_contour=True;line.linestyle.color=(.003,.004,.009);line.linestyle.thickness=5.5;line.linestyle.caps='ROUND'
noise=line.linestyle.thickness_modifiers.new('Hand pressure','NOISE');noise.amplitude=1.1;noise.period=35;noise.seed=7
for screen in bpy.data.screens:
    for area in screen.areas:
        if area.type=='VIEW_3D':
            area.spaces.active.region_3d.view_perspective='CAMERA';area.spaces.active.shading.type='MATERIAL'
            area.spaces.active.shading.use_scene_world=True;area.spaces.active.shading.use_scene_lights=True
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'copper-clay.blend'),relative_remap=False)
for mode in ('clay','zones'):
    bpy.context.view_layer.material_override=clay if mode=='clay' else None;scene.render.use_freestyle=mode=='zones'
    copper.hide_render=mode=='clay'
    scene.render.filepath=str(OUT/('copper-'+mode+'-hero.png'));bpy.ops.render.render(write_still=True)
    print('RENDER='+scene.render.filepath,flush=True)
bpy.context.view_layer.material_override=clay;scene.render.use_freestyle=False;copper.hide_render=True;aim(views['reverse'])
scene.render.filepath=str(OUT/'copper-clay-reverse.png');bpy.ops.render.render(write_still=True)
print('RENDER='+scene.render.filepath,flush=True)
