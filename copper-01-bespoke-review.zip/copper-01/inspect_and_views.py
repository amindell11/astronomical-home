import bpy,bmesh,json,hashlib
from pathlib import Path
from mathutils import Vector
OUT=Path(__file__).resolve().parent
bpy.ops.wm.open_mainfile(filepath=str(OUT/'copper-painted.blend'))
scene=bpy.context.scene
parts=bpy.data.collections['Copper 01, editable components']
report={'source':'copper-painted.blend','meshes':[],'images':[],'scope':'One bespoke Copper art proof, no runtime or production exports'}
for obj in parts.objects:
    if obj.type!='MESH':continue
    bm=bmesh.new();bm.from_mesh(obj.data)
    unseen=set(bm.verts);components=[]
    while unseen:
        seed=unseen.pop();stack=[seed];count=0
        while stack:
            vertex=stack.pop();count+=1
            for edge in vertex.link_edges:
                other=edge.other_vert(vertex)
                if other in unseen:unseen.remove(other);stack.append(other)
        components.append(count)
    report['meshes'].append({'name':obj.name,'vertices':len(bm.verts),'faces':len(bm.faces),'boundary_edges':sum(e.is_boundary for e in bm.edges),'nonmanifold_edges':sum(not e.is_manifold for e in bm.edges),'zero_area_faces':sum(f.calc_area()<1e-10 for f in bm.faces),'connected_component_vertex_counts':components,'uv_layers':list(obj.data.uv_layers.keys()),'intentional_open_ribbon':bool(obj.get('intentional_open_ribbon',False))})
    bm.free()
for image in bpy.data.images:
    if image.source=='FILE':report['images'].append({'name':image.name,'packed':bool(image.packed_file),'path':image.filepath,'dimensions':list(image.size)})
report['source_sha256']=hashlib.sha256((OUT/'copper-painted.blend').read_bytes()).hexdigest()
(OUT/'source-check.json').write_text(json.dumps(report,indent=2))
def render(name,target,scale,view):
    camera=scene.camera;camera.data.ortho_scale=scale
    camera.location=Vector(target)+Vector(view).normalized()*10;camera.rotation_euler=(Vector(target)-camera.location).to_track_quat('-Z','Y').to_euler()
    scene.render.filepath=str(OUT/name);bpy.ops.render.render(write_still=True);print('RENDER='+scene.render.filepath,flush=True)
render('copper-painted-close.png',(-.05,-.18,.22),3.7,(-1.8,-9,5.1))
render('copper-painted-side.png',(.05,0,.12),6.35,(6.8,-3,3.5))
render('copper-painted-reverse.png',(.05,0,.12),6.35,(3.3,7,4.4))
