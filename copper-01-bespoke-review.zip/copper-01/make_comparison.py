from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parent
font=ImageFont.truetype('C:/Windows/Fonts/segoeui.ttf',24)
small=ImageFont.truetype('C:/Windows/Fonts/segoeui.ttf',18)
board=Image.new('RGB',(1600,820),(39,46,58));draw=ImageDraw.Draw(board)
draw.text((35,22),'Copper 01, Blender geometry study',font=font,fill=(236,236,231))
def place(filename,box,label):
    image=Image.open(ROOT/filename).convert('RGBA')
    if image.getextrema()[3][0]<255:image=image.crop(image.getchannel('A').getbbox())
    x,y,w,h=box;image.thumbnail((w,h),Image.Resampling.LANCZOS)
    if filename.startswith('reference'):
        image=image.resize((w,round(w*image.height/image.width)),Image.Resampling.LANCZOS)
    board.paste(image,(x+(w-image.width)//2,y+(h-image.height)//2),image)
    draw.text((x,y+h+12),label,font=small,fill=(226,229,233))
place('reference-copper.png',(40,100,720,370),'Original approved concept')
place('copper-clay-hero.png',(840,100,720,370),'Actual model, neutral clay')
place('copper-zones-hero.png',(40,555,340,200),'Plain material regions')
place('copper-clay-reverse.png',(440,555,340,200),'Actual model, reverse')
place('reference-copper.png',(950,595,150,100),'Reference, 150 px')
place('copper-clay-hero.png',(1250,595,150,100),'Clay, 150 px')
board.save(ROOT/'copper-reference-clay.png')
