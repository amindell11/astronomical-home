from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parent
font=ImageFont.truetype('C:/Windows/Fonts/segoeui.ttf',27)
small=ImageFont.truetype('C:/Windows/Fonts/segoeui.ttf',20)
def canvas(size,title):
    board=Image.new('RGB',size,(39,46,58));draw=ImageDraw.Draw(board)
    draw.text((32,22),title,font=font,fill=(239,239,233));return board,draw
def place(board,draw,filename,box,label,native=False):
    image=Image.open(ROOT/filename).convert('RGBA')
    if not native and image.getextrema()[3][0]<255:image=image.crop(image.getchannel('A').getbbox())
    x,y,w,h=box
    if not native:
        scale=min(w/image.width,h/image.height);image=image.resize((round(image.width*scale),round(image.height*scale)),Image.Resampling.LANCZOS)
    board.paste(image,(x+(w-image.width)//2,y+(h-image.height)//2),image)
    draw.text((x,y+h+12),label,font=small,fill=(225,229,233))
board,draw=canvas((1800,790),'Copper 01, bespoke Blender art proof')
for x,filename,label in [(30,'reference-copper.png','Original approved concept'),(625,'copper-clay-hero.png','New geometry, clay'),(1220,'copper-painted-hero.png','Actual painted model')]:
    place(board,draw,filename,(x,100,550,330),label)
place(board,draw,'reference-copper.png',(185,565,150,110),'Reference at 150 px')
place(board,draw,'copper-clay-hero.png',(780,565,150,110),'Clay at 150 px')
place(board,draw,'copper-painted-150.png',(1375,565,150,110),'Native 150 px canvas',True)
draw.text((32,742),'Separate copper and turquoise pieces, directional paint, outer contour and selective graphite.',font=small,fill=(189,199,211))
board.save(ROOT/'copper-painted-comparison.png')
board,draw=canvas((1700,1140),'Copper 01, actual model views')
for filename,box,label in [('copper-painted-hero.png',(35,100,780,400),'Hero'),('copper-painted-reverse.png',(885,100,780,400),'Reverse'),('copper-painted-side.png',(35,650,780,400),'Side'),('copper-painted-close.png',(885,650,780,400),'Fracture detail')]:place(board,draw,filename,box,label)
board.save(ROOT/'copper-views.png')
