import bpy,bmesh,math,sys
from pathlib import Path
from mathutils import Vector
from mathutils.geometry import closest_point_on_tri
from mathutils.bvhtree import BVHTree
OUT=Path(__file__).resolve().parent
bpy.ops.wm.open_mainfile(filepath=str(OUT/'copper-clay.blend'))
bpy.context.preferences.filepaths.save_version=0
scene=bpy.context.scene;parts=bpy.data.collections['Copper 01, editable components'];root=bpy.data.objects['Asteroid_Copper_01']
body=bpy.data.objects['Rock_Host'];copper=bpy.data.objects['Copper fitted fracture sections']
def mapped(name,filename,saturation,value):
    mat=bpy.data.materials.new(name);mat.use_nodes=True
    nodes=mat.node_tree.nodes;shader=nodes.get('Principled BSDF');shader.inputs['Roughness'].default_value=.94;shader.inputs['Specular IOR Level'].default_value=.12
    image=bpy.data.images.load(str(OUT/'paint'/filename));image.pack();image.filepath='//paint/'+filename
    texture=nodes.new('ShaderNodeTexImage');texture.image=image;texture.extension='REPEAT';texture.interpolation='Linear'
    uv=nodes.new('ShaderNodeUVMap');uv.uv_map='DirectionalPaintUV'
    tone=nodes.new('ShaderNodeHueSaturation');tone.inputs['Saturation'].default_value=saturation;tone.inputs['Value'].default_value=value
    mat.node_tree.links.new(uv.outputs['UV'],texture.inputs['Vector']);mat.node_tree.links.new(texture.outputs['Color'],tone.inputs['Color']);mat.node_tree.links.new(tone.outputs['Color'],shader.inputs['Base Color'])
    return mat
slate=mapped('Painted slate, approved Violet swatch','slate-paint.png',.48,.52)
rust=mapped('Painted copper fracture','copper-paint.png',.9,.56)
patina=mapped('Painted turquoise crust','turquoise-paint.png',.78,.42)
def uv_map(obj,axis,span):
    uv=obj.data.uv_layers.new(name='DirectionalPaintUV');axis=Vector(axis).normalized()
    for face in obj.data.polygons:
        normal=face.normal.normalized();grain=axis-normal*axis.dot(normal)
        if grain.length<.1:grain=Vector((1,0,.1))-normal*Vector((1,0,.1)).dot(normal)
        grain.normalize();cross=normal.cross(grain).normalized()
        for index in face.loop_indices:
            point=obj.data.vertices[obj.data.loops[index].vertex_index].co
            across,along=point.dot(cross),point.dot(grain)
            uv.data[index].uv=((across+along)/(span*math.sqrt(2))+.5,(-across+along)/(span*math.sqrt(2))+.5)
    obj['paint_mapping']='Brush direction follows projected physical fracture axis on actual surface faces'
uv_map(body,(.75,.55,.7),4.3);body.data.materials.clear();body.data.materials.append(slate)
for face in body.data.polygons:face.material_index=0
bpy.ops.object.select_all(action='DESELECT');copper.select_set(True);bpy.context.view_layer.objects.active=copper
bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.mesh.separate(type='LOOSE');bpy.ops.object.mode_set(mode='OBJECT')
coppers=[o for o in parts.objects if o.name.startswith('Copper fitted')]
for i,obj in enumerate(sorted(coppers,key=lambda o:sum(v.co.x for v in o.data.vertices)/len(o.data.vertices))):
    obj.name='Copper_Fracture_'+str(i+1).zfill(2)
    mean_x=sum(v.co.x for v in obj.data.vertices)/len(obj.data.vertices)
    uv_map(obj,(.70,.30,1) if mean_x<.3 else (.65,1,.80),4.0)
    obj.data.materials.clear();obj.data.materials.append(rust)
    for face in obj.data.polygons:face.material_index=0
    obj.hide_render=False

def mesh(name,vertices,faces,mat):
    data=bpy.data.meshes.new(name+'Mesh');data.from_pydata(vertices,[],faces);data.update();data.materials.append(mat)
    bm=bmesh.new();bm.from_mesh(data);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(data);bm.free()
    obj=bpy.data.objects.new(name,data);parts.objects.link(obj);obj.parent=root
    return obj
adjacent={tuple(sorted(e.vertices)):[] for e in body.data.edges}
for face in body.data.polygons:
    ids=list(face.vertices)
    for a,b in zip(ids,ids[1:]+ids[:1]):adjacent[tuple(sorted((a,b)))].append(face)
used_patch_edges=set()
def patch(name,anchor,width):
    anchor=Vector(anchor);candidates=[]
    for edge in body.data.edges:
        key=tuple(sorted(edge.vertices));faces=adjacent[key]
        if key in used_patch_edges or len(faces)!=2:continue
        a,b=[body.data.vertices[i].co.copy() for i in edge.vertices];length=(b-a).length;middle=(a+b)*.5
        if length<.55 or faces[0].normal.angle(faces[1].normal)<math.radians(18):continue
        for face in faces:
            if face.normal.z<.30 or face.area<.10:continue
            c=body.data.vertices[next(i for i in face.vertices if i not in key)].co.copy()
            altitude=(c-a).cross((b-a).normalized()).length
            if altitude>.24:candidates.append(((middle-anchor).length_squared,key,a,b,c,face.normal.copy(),altitude))
    _,key,a,b,c,normal,altitude=min(candidates,key=lambda item:item[0]);used_patch_edges.add(key)
    tangent=(b-a).normalized();length=(b-a).length
    projection=(c-a).dot(tangent)/length;inward=(c-a-tangent*(c-a).dot(tangent)).normalized()
    profile=[(.17,.05),(.27,.01),(.41,.05),(.54,.02),(.69,.04),(.82,.09),(.78,.55),(.70,.82),(.61,.61),(.51,1.00),(.40,.77),(.29,.93),(.21,.53)]
    width_limits=[]
    for along,depth in profile:
        fractions=[1]
        if projection>0:fractions.append(along/projection)
        if projection<1:fractions.append((1-along)/(1-projection))
        width_limits.append(altitude*min(fractions)*.82/depth)
    width=min(width,min(width_limits));points=[a.lerp(b,along)+inward*width*depth for along,depth in profile]
    n=len(points);upper=[p+normal*.009 for p in points];lower=[p-normal*.026 for p in points]
    obj=mesh(name,[tuple(v) for v in upper+lower],[tuple(range(n)),tuple(range(2*n-1,n-1,-1))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)],patina)
    obj['attachment']='Contained in one host triangle, near-flush exposed surface, buried solid thickness'
    uv_map(obj,(.75,.55,.7),1.15)
    print('PATCH',name,'area',sum(p.area for p in obj.data.polygons),'edge',list(key),flush=True)
    return obj
patches=[
 patch('Turquoise_LeftToe',(-2.30,-.60,.12),.26),
 patch('Turquoise_LeftCleft',(-1.55,-.68,.18),.15),
 patch('Turquoise_UpperContact',(.20,-.10,.66),.18),
 patch('Turquoise_RightBlade',(1.26,-.71,.28),.25),
 patch('Turquoise_RightTip',(2.35,.12,.65),.23),
 patch('Turquoise_RearContact',(1.76,.86,.84),.13)]

ink=bpy.data.materials.new('Fitted graphite fracture strokes');ink.use_nodes=True
shader=ink.node_tree.nodes['Principled BSDF'];shader.inputs['Base Color'].default_value=(.018,.014,.027,1);shader.inputs['Roughness'].default_value=1
used_ink_edges=set()
def stroke(name,anchor,width,start=.12,end=.84):
    candidates=[];anchor=Vector(anchor)
    for edge in body.data.edges:
        key=tuple(sorted(edge.vertices));faces=adjacent[key]
        if key in used_ink_edges or len(faces)!=2:continue
        a,b=[body.data.vertices[i].co.copy() for i in edge.vertices];length=(b-a).length
        if length<.40 or faces[0].normal.angle(faces[1].normal)<math.radians(27):continue
        fraction=max(0,min(1,(anchor-a).dot(b-a)/(length*length)));nearest=a.lerp(b,fraction)
        candidates.append(((nearest-anchor).length_squared,key,a,b,faces))
    _,key,a,b,faces=min(candidates,key=lambda item:item[0]);used_ink_edges.add(key)
    normal=max(faces,key=lambda f:f.normal.z-f.normal.y*.5).normal.copy();tangent=(b-a).normalized();side=normal.cross(tangent).normalized()
    vertices=[]
    for t,w in [(start,.15),((start+end)*.33,.85),((start+end)*.63,1),(end,.04)]:
        point=a.lerp(b,t)+normal*.011
        vertices.extend([tuple(point-side*width*w),tuple(point+side*width*w)])
    obj=mesh(name,vertices,[(i,i+1,i+3,i+2) for i in (0,2,4)],ink)
    obj['attachment']='Tapered ribbon along selected actual fracture edge';obj['intentional_open_ribbon']=True
    return obj
for i,(anchor,width,start,end) in enumerate([
 ((-.26,-.43,.12),.014,.08,.90),
 ((-.48,-.62,.66),.011,.20,.77),
 ((.30,-.18,.40),.011,.08,.80),
 ((-1.35,-.80,-.10),.010,.16,.65),
 ((.68,-.64,.21),.009,.12,.74),
 ((1.74,-.45,.37),.011,.17,.80),
 ((1.03,.43,.78),.010,.26,.80),
 ((-.95,.37,.80),.009,.10,.65)]):stroke('Drawing_Fracture_'+str(i+1).zfill(2),anchor,width,start,end)
tree=BVHTree.FromObject(body,bpy.context.evaluated_depsgraph_get())
def roof_wall_stroke(name,path,width):
    targets=[Vector((x*1.10,y*.86,z*.82)) for x,y,z in path];samples=[]
    for first,last in zip(targets,targets[1:]):
        for j in range(12):samples.append(tree.find_nearest(first.lerp(last,j/12))[0])
    samples.append(tree.find_nearest(targets[-1])[0]);samples=[point for i,point in enumerate(samples) if i==0 or (point-samples[i-1]).length>1e-5];vertices=[]
    for i,point in enumerate(samples):
        normal=tree.find_nearest(point)[1];tangent=samples[min(i+1,len(samples)-1)]-samples[max(0,i-1)]
        tangent.normalize();side=normal.cross(tangent).normalized();t=i/(len(samples)-1)
        pressure=.08+.92*math.sin(math.pi*t)**.7*(.84+.16*math.sin(t*19))
        for sign in (-1,1):
            hit,n,_,_=tree.find_nearest(point+side*width*pressure*sign)
            vertices.append(tuple(hit+n*.011))
    obj=mesh(name,vertices,[(2*i,2*i+1,2*i+3,2*i+2) for i in range(len(samples)-1)],ink)
    obj['attachment']='Sparse roof-to-wall graphite path fitted to actual host surface';obj['intentional_open_ribbon']=True
roof_wall_stroke('Drawing_LeftRoofToWall',[(-.95,.26,.94),(-.72,.03,.98),(-.82,-.41,.92),(-.75,-.89,.85),(-.86,-.94,.48),(-.96,-.98,.13)],.010)
roof_wall_stroke('Drawing_RightRoofToWall',[(1.20,-.05,.68),(1.30,-.39,.52),(1.33,-.87,.35),(1.25,-.94,.10)],.009)
ink_subject=bpy.data.collections.new('Outer contour subject');scene.collection.children.link(ink_subject);ink_subject.objects.link(body)
for line in bpy.context.view_layer.freestyle_settings.linesets:
    line.select_by_collection=True;line.collection=ink_subject;line.collection_negation='INCLUSIVE'
scene.render.use_freestyle=True;bpy.context.view_layer.material_override=None
scene['proof']='Bespoke Copper art study, direct directional swatches on separately editable mineral geometry'
scene['outline']='Freestyle outer contour is render-only; selected internal graphite strokes are actual mesh ribbons'
for obj in parts.objects:obj.hide_render=False
bpy.ops.object.select_all(action='DESELECT');body.select_set(True);bpy.context.view_layer.objects.active=body
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'copper-painted.blend'),relative_remap=False)
def render(filename,target,scale,view):
    camera=scene.camera;camera.data.ortho_scale=scale
    camera.location=Vector(target)+Vector(view).normalized()*10;camera.rotation_euler=(Vector(target)-camera.location).to_track_quat('-Z','Y').to_euler()
    scene.render.filepath=str(OUT/filename);bpy.ops.render.render(write_still=True);print('RENDER='+scene.render.filepath,flush=True)
render('copper-painted-hero.png',(.05,0,.12),6.35,(-1.8,-9,5.1))
scene.render.resolution_x=150;scene.render.resolution_y=110
for line in bpy.context.view_layer.freestyle_settings.linesets:
    line.linestyle.thickness=2.4
    for mod in line.linestyle.thickness_modifiers:mod.amplitude=.4
render('copper-painted-150.png',(.05,0,.12),6.35,(-1.8,-9,5.1))
