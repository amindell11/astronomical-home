You are working in the git repository at C:\Users\amind\AppData\Local\Temp\claude\D--amind-git-astronomical-home\a239d6dc-e173-4021-b6a4-159998ea4700\scratchpad\cw-runs\b1\t2-tick-context__grok__2\repo. It is a C# 9 project; build and test it with the .NET SDK.

Give objective states the time spent in their current step.

1. Add `src/Game/Objectives/ObjectiveTick.cs`: a `public readonly struct ObjectiveTick` in namespace `Objectives`, with a constructor `ObjectiveTick(float deltaTime, float elapsed)` and get-only properties `DeltaTime` and `Elapsed`.
2. Replace `ObjectiveState.Tick(float deltaTime)` with `public abstract void Tick(in ObjectiveTick tick)`, and update every override under `src/Game/Objectives/States/`.
3. `ObjectiveTracker.Tick(float deltaTime)` keeps its public signature. The tracker keeps the seconds spent in the current step. Each call that ticks the current state first adds `deltaTime` to that total, then passes `new ObjectiveTick(deltaTime, elapsed)`. Every step change resets the total to 0: a completed state advancing, the fail criteria firing, `Fail()`, and `Restart()`. So the first tick a step receives has `Elapsed == DeltaTime`.

Keep all other behavior as it is. You may change files under `src/Game/Objectives/` and `src/Game/Objectives/States/` only.

Rules:
- Change only the files this task allows. Do not create, delete or edit anything else.
- Do not add comments.
- Do not commit, stash, branch, reset, checkout or otherwise change git state. Leave your changes uncommitted.
- Nobody will answer questions. If the task cannot be done as specified, stop and say why.
- Verify with: dotnet run --project tests/Checks

End your reply with exactly this block:
STATUS: DONE or BLOCKED
CHANGED: <comma-separated paths you changed, or none>
VERIFIED: <the command you ran and its last output line>
NOTICED: <anything outside the task that looks wrong, or none>
