You are working in the git repository at C:\Users\amind\AppData\Local\Temp\claude\D--amind-git-astronomical-home\a239d6dc-e173-4021-b6a4-159998ea4700\scratchpad\cw-runs\b1\t3-offer-tests__grok__1\repo. It is a C# 9 project; build and test it with the .NET SDK.

Write tests for `WeaponModOffers.Draw` and `WeaponMods` in a new file `tests/Checks/WeaponModOfferTests.cs`, as a `public static class WeaponModOfferTests`. Follow the runner's conventions in `tests/Checks/Runner.cs` and reuse the helpers in `tests/Checks/Fakes.cs`.

Cover each of these behaviors with at least one test:

1. `Draw` returns at most `count` mods.
2. `Draw` never returns the same mod twice.
3. `Draw` leaves out mods that `fits` rejects.
4. `Draw` skips null entries in the pool.
5. `Draw` returns every fitting mod when fewer than `count` fit.
6. `Draw` picks with `randomBelow`: the value it returns indexes the fitting mods that are still undrawn, in pool order.
7. `WeaponMods.Apply` divides a rate field's authored seconds by the field's factor, and multiplies every other field's authored value by its factor.
8. `WeaponMods.Rounds` adds the picked Magazine rounds to the authored count.

The tests must pass against the current code. Do not change anything under `src/`. The only file you may create or change is `tests/Checks/WeaponModOfferTests.cs`.

Rules:
- Change only the files this task allows. Do not create, delete or edit anything else.
- Do not add comments.
- Do not commit, stash, branch, reset, checkout or otherwise change git state. Leave your changes uncommitted.
- Nobody will answer questions. If the task cannot be done as specified, stop and say why.
- Verify with: dotnet run --project tests/Checks

End your reply with exactly this block:
STATUS: DONE or BLOCKED
CHANGED: <comma-separated paths you changed, or none>
VERIFIED: <the command you ran and its last output line>
NOTICED: <anything outside the task that looks wrong, or none>
