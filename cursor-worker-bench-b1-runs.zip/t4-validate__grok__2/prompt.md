You are working in the git repository at C:\Users\amind\AppData\Local\Temp\claude\D--amind-git-astronomical-home\a239d6dc-e173-4021-b6a4-159998ea4700\scratchpad\cw-runs\b1\t4-validate__grok__2\repo. It is a C# 9 project; build and test it with the .NET SDK.

Add this method to `MissionDefinition` in `src/Game/Objectives/MissionDefinition.cs`:

    public IReadOnlyList<string> Validate(IEnumerable<string> builtSteps)

`builtSteps` names the steps that have a state builder. Treat it as a set; it may contain duplicates. A null `builtSteps` throws `ArgumentNullException`.

The method returns every problem with the mission's table, using exactly these messages and in this order, or an empty list when there are none:

1. `missing initial step` when `InitialStep` is null or empty. In that case return this one problem and nothing else.
2. `no builder for '<step>'` for each step the table names that is not in `builtSteps`. The table names the initial step first, then each transition's key followed by its value, in the order `Transitions` enumerates. Report each step once, at its first mention.
3. `no builder for 'failed'` when `FailCriteria` is not null and `builtSteps` lacks `failed`, unless rule 2 already reported `failed`.
4. `unreachable step '<step>'` for each transition key that the walk never visits, in the order `Transitions` enumerates. The walk starts at `InitialStep` and follows `Transitions` until it reaches a step with no transition or a step it has already visited.
5. `cycle at '<step>'` when the walk reaches a step it has already visited; `<step>` is that step. Report at most one cycle.

The only file you may change is `src/Game/Objectives/MissionDefinition.cs`.

Rules:
- Change only the files this task allows. Do not create, delete or edit anything else.
- Do not add comments.
- Do not commit, stash, branch, reset, checkout or otherwise change git state. Leave your changes uncommitted.
- Nobody will answer questions. If the task cannot be done as specified, stop and say why.
- Verify with: dotnet run --project tests/Checks

End your reply with exactly this block:
STATUS: DONE or BLOCKED
CHANGED: <comma-separated paths you changed, or none>
VERIFIED: <the command you ran and its last output line>
NOTICED: <anything outside the task that looks wrong, or none>
