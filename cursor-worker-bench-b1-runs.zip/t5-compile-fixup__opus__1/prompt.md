You are working in the git repository at C:\Users\amind\AppData\Local\Temp\claude\D--amind-git-astronomical-home\a239d6dc-e173-4021-b6a4-159998ea4700\scratchpad\cw-runs\b1\t5-compile-fixup__opus__1\repo. It is a C# 9 project; build and test it with the .NET SDK.

I refactored `src/Game/Objectives/ObjectiveState.cs` so a state's type is a constructor argument instead of an overridden property. That change is uncommitted in the working tree and is intended: do not edit, revert or restore that file. A mismatch between it and HEAD is not staleness.

The build is now broken. Fix it. Each state under `src/Game/Objectives/States/` passes its existing type to the base constructor and drops its `StateType` override. Change nothing else: every state keeps its public constructors and behavior, and every other file stays as it is.

You may change files under `src/Game/Objectives/States/` only.

Rules:
- Change only the files this task allows. Do not create, delete or edit anything else.
- Do not add comments.
- Do not commit, stash, branch, reset, checkout or otherwise change git state. Leave your changes uncommitted.
- Nobody will answer questions. If the task cannot be done as specified, stop and say why.
- Verify with: dotnet run --project tests/Checks

End your reply with exactly this block:
STATUS: DONE or BLOCKED
CHANGED: <comma-separated paths you changed, or none>
VERIFIED: <the command you ran and its last output line>
NOTICED: <anything outside the task that looks wrong, or none>
