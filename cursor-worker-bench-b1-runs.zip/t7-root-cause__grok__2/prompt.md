You are working in the git repository at C:\Users\amind\AppData\Local\Temp\claude\D--amind-git-astronomical-home\a239d6dc-e173-4021-b6a4-159998ea4700\scratchpad\cw-runs\b1\t7-root-cause__grok__2\repo. It is a C# 9 project; build and test it with the .NET SDK.

`dotnet run --project tests/Checks` fails: `WeaponModTests.StackForIsRepeatable`. Chase the failure to its root cause and fix it there.

Do not change any test file. You may change files under `src/Game/` only.

Rules:
- Change only the files this task allows. Do not create, delete or edit anything else.
- Do not add comments.
- Do not commit, stash, branch, reset, checkout or otherwise change git state. Leave your changes uncommitted.
- Nobody will answer questions. If the task cannot be done as specified, stop and say why.
- Verify with: dotnet run --project tests/Checks

End your reply with exactly this block:
STATUS: DONE or BLOCKED
CHANGED: <comma-separated paths you changed, or none>
VERIFIED: <the command you ran and its last output line>
NOTICED: <anything outside the task that looks wrong, or none>
