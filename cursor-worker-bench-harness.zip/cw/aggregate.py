"""Cross-run facts the per-run gates don't show: outside-workspace paths, blocked commands, totals."""
import collections
import json
import sys
from pathlib import Path

batch = Path(sys.argv[1])
outside, rejected, tools = collections.Counter(), [], collections.Counter()
cost = wall = 0.0
runs = sorted(batch.glob("*__grok__*"))
for d in runs:
    r = json.loads((d / "result.json").read_text(encoding="utf-8"))
    cost += r["cost_usd"] or 0
    wall += r["wall_s"]
    run_dir = str(d).lower().replace("/", "\\")
    for p in r["outside_paths"]:
        q = p.lower().replace("/", "\\")
        if q.rstrip("\\") == run_dir:
            q = "<run dir, parent of the workspace>"
        elif q.startswith(run_dir):
            q = "<run dir>" + q[len(run_dir):]
        q = q.replace("c:\\users\\amind", "~")
        outside[q[:100]] += 1
    for line in (d / "transcript.jsonl").read_text(encoding="utf-8").splitlines():
        e = json.loads(line)
        if e.get("type") != "tool_call" or e.get("subtype") != "completed":
            continue
        for name, body in e["tool_call"].items():
            if not name.endswith("ToolCall"):
                continue
            tools[name] += 1
            res = body.get("result") or {}
            if "rejected" in res:
                args = body.get("args") or {}
                rejected.append((d.name.split("__")[0][:3], str(args.get("command") or args.get("path") or "?")[:80].replace("\n", " ")))

print(f"{len(runs)} runs, est cost ${cost:.2f}, total wall {wall / 60:.0f} min")
print("tool calls:", dict(tools))
print("outside paths:")
for p, n in outside.most_common(15):
    print(f"  {n}x {p}")
print(f"rejected commands: {len(rejected)}")
for t, c in rejected:
    print(f"  {t} {c}")
