"""Zip the harness and one batch's results (per-run metadata, transcripts, replies, diffs) for the evidence branch."""
import difflib
import json
import sys
import zipfile
from pathlib import Path

bench = Path(__file__).resolve().parent
batch = bench.parent / "cw-runs" / sys.argv[1]
out = Path(sys.argv[2])
out.mkdir(parents=True, exist_ok=True)

with zipfile.ZipFile(out / "cursor-worker-bench-harness.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in sorted(bench.rglob("*")):
        if p.is_file() and "__pycache__" not in p.parts:
            z.write(p, Path("cw") / p.relative_to(bench))

with zipfile.ZipFile(out / f"cursor-worker-bench-{sys.argv[1]}-runs.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for run in sorted(d for d in batch.iterdir() if (d / "result.json").exists()):
        for name in ("run.json", "result.json", "final.txt", "prompt.md", "transcript.jsonl", "reply.txt", "stderr.log"):
            if (run / name).exists():
                z.write(run / name, f"{run.name}/{name}")
        res = json.loads((run / "result.json").read_text(encoding="utf-8"))
        patch = []
        for rel in res["files"]["changed"] + res["files"]["added"] + res["files"]["deleted"]:
            old = (run / "snap" / rel).read_text(encoding="utf-8", errors="replace").splitlines(True) if (run / "snap" / rel).exists() else []
            new = (run / "repo" / rel).read_text(encoding="utf-8", errors="replace").splitlines(True) if (run / "repo" / rel).exists() else []
            patch += difflib.unified_diff(old, new, f"a/{rel}", f"b/{rel}")
        z.writestr(f"{run.name}/worker.diff", "".join(patch))
    if (batch / "report.md").exists():
        z.write(batch / "report.md", "report.md")
print(sorted((p.name, p.stat().st_size) for p in out.iterdir()))
