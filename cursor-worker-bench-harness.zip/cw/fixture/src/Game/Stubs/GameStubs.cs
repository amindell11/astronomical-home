using System;
using System.Collections.Generic;
using Combat.Weapons.Mods;
using UnityEngine;

namespace Ships
{
    public class Ship : MonoBehaviour
    {
        public event Action JumpRequested;

        public void RequestJump() => JumpRequested?.Invoke();
    }
}

namespace Objectives
{
    public interface IExtractionZone
    {
        bool IsPlayerInZone { get; }
    }

    public interface IKeyTracker
    {
        bool PlayerHasKey { get; }
    }
}

namespace Combat.Weapons
{
    public class WeaponComponent : MonoBehaviour
    {
        private readonly HashSet<WeaponModField> fields = new();

        public WeaponComponent(params WeaponModField[] supported)
        {
            foreach (var field in supported) fields.Add(field);
        }

        public WeaponMods Mods { get; private set; } = WeaponMods.None;

        public void SetMods(WeaponMods mods) => Mods = mods ?? throw new ArgumentNullException(nameof(mods));

        public virtual bool Supports(WeaponModField field) => fields.Contains(field);
    }
}
