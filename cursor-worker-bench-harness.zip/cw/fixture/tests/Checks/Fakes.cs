using System;
using System.Collections.Generic;
using Combat.Weapons;
using Combat.Weapons.Mods;
using Objectives;
using Objectives.States;
using UnityEngine;

namespace Checks
{
    public sealed class FakeKeys : IKeyTracker
    {
        public bool PlayerHasKey { get; set; }
    }

    public sealed class FakeZone : IExtractionZone
    {
        public bool IsPlayerInZone { get; set; }
    }

    public sealed class FakeHostiles : IHostileTracker
    {
        public bool HostilesCleared { get; set; }
    }

    public static class Missions
    {
        public static Dictionary<string, Func<ObjectiveState>> DefaultBuilders(FakeKeys keys, FakeHostiles hostiles) => new()
        {
            ["explore"] = () => new ExploreState(keys),
            ["key"] = () => new KeyAcquiredState(),
            ["extraction"] = () => new ClearHostilesState(hostiles),
            ["extracted"] = () => new ExtractedState(),
            ["failed"] = () => new FailedState(),
        };
    }

    public static class Mods
    {
        public static WeaponMod Make(string displayName, WeaponModField field, float amount, params WeaponComponent[] fits)
        {
            var mod = ScriptableObject.CreateInstance<WeaponMod>();
            mod.name = displayName;
            mod.Configure(displayName, field, amount, fits);
            return mod;
        }
    }
}
