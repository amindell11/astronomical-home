using System.Collections.Generic;
using Objectives;

namespace Checks
{
    public static class ObjectiveTrackerTests
    {
        public static void DefaultMissionWalksToExtracted()
        {
            var keys = new FakeKeys();
            var hostiles = new FakeHostiles();
            var tracker = new ObjectiveTracker(MissionDefinition.CreateDefault(), Missions.DefaultBuilders(keys, hostiles));
            var seen = new List<string>();
            tracker.OnStepChanged += seen.Add;

            tracker.Tick(0.1f);
            Check.Equal(ObjectiveType.Explore, tracker.CurrentState, "before key");

            keys.PlayerHasKey = true;
            tracker.Tick(0.1f);
            tracker.Tick(0.1f);
            Check.Equal("extraction", tracker.CurrentStep, "after key ack");

            hostiles.HostilesCleared = true;
            tracker.Tick(0.1f);
            Check.Equal(ObjectiveType.Extracted, tracker.CurrentState, "end");
            Check.Sequence(new[] { "key", "extraction", "extracted" }, seen, "steps");
        }

        public static void FailCriteriaMovesToFailed()
        {
            var dead = false;
            var tracker = new ObjectiveTracker(
                MissionDefinition.CreateDefault(() => dead),
                Missions.DefaultBuilders(new FakeKeys(), new FakeHostiles()));

            tracker.Tick(0.1f);
            dead = true;
            tracker.Tick(0.1f);
            Check.Equal(ObjectiveType.Failed, tracker.CurrentState, "state");
        }

        public static void FailIsNoOpInTerminalState()
        {
            var keys = new FakeKeys { PlayerHasKey = true };
            var hostiles = new FakeHostiles { HostilesCleared = true };
            var tracker = new ObjectiveTracker(MissionDefinition.CreateDefault(), Missions.DefaultBuilders(keys, hostiles));
            for (var i = 0; i < 4; i++) tracker.Tick(0.1f);
            Check.Equal(ObjectiveType.Extracted, tracker.CurrentState, "extracted");

            tracker.Fail();
            Check.Equal(ObjectiveType.Extracted, tracker.CurrentState, "still extracted");
        }

        public static void KeyAcquiredCompletesImmediately()
        {
            var state = new Objectives.States.KeyAcquiredState();
            state.Enter();
            Check.True(state.IsComplete, "complete on enter");
        }
    }
}
