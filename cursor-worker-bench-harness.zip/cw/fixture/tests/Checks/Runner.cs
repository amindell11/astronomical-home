using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace Checks
{
    /// <summary>
    /// Zero-dependency test runner: every public static parameterless void method on a class whose
    /// name ends in "Tests" is a test. A test fails by throwing. Pass a substring to filter by name.
    /// </summary>
    public static class Runner
    {
        public static int Main(string[] args)
        {
            var filter = args.Length > 0 ? args[0] : null;
            var tests = Assembly.GetExecutingAssembly().GetTypes()
                .Where(t => t.IsClass && t.Name.EndsWith("Tests", StringComparison.Ordinal))
                .SelectMany(t => t.GetMethods(BindingFlags.Public | BindingFlags.Static)
                    .Where(m => m.ReturnType == typeof(void) && m.GetParameters().Length == 0)
                    .Select(m => (Name: t.Name + "." + m.Name, Method: m)))
                .Where(x => filter == null || x.Name.Contains(filter))
                .OrderBy(x => x.Name, StringComparer.Ordinal)
                .ToList();

            var failed = 0;
            foreach (var (name, method) in tests)
            {
                try
                {
                    method.Invoke(null, null);
                    Console.WriteLine("PASS " + name);
                }
                catch (TargetInvocationException e)
                {
                    failed++;
                    Console.WriteLine("FAIL " + name + ": " + e.InnerException?.Message);
                }
            }

            Console.WriteLine($"{tests.Count - failed} passed, {failed} failed");
            return failed == 0 && tests.Count > 0 ? 0 : 1;
        }
    }

    public sealed class CheckFailed : Exception
    {
        public CheckFailed(string message) : base(message) { }
    }

    public static class Check
    {
        public static void Equal<T>(T expected, T actual, string what = "value")
        {
            if (!EqualityComparer<T>.Default.Equals(expected, actual))
                throw new CheckFailed($"{what}: expected <{expected}>, got <{actual}>");
        }

        public static void Near(float expected, float actual, float tolerance = 1e-5f, string what = "value")
        {
            if (Math.Abs(expected - actual) > tolerance)
                throw new CheckFailed($"{what}: expected <{expected}> ± {tolerance}, got <{actual}>");
        }

        public static void True(bool condition, string what)
        {
            if (!condition) throw new CheckFailed(what + ": expected true");
        }

        public static void False(bool condition, string what)
        {
            if (condition) throw new CheckFailed(what + ": expected false");
        }

        public static void Sequence<T>(IEnumerable<T> expected, IEnumerable<T> actual, string what = "sequence")
        {
            var e = expected.ToList();
            var a = actual.ToList();
            if (!e.SequenceEqual(a))
                throw new CheckFailed($"{what}: expected [{string.Join(", ", e)}], got [{string.Join(", ", a)}]");
        }

        public static TException Throws<TException>(Action action, string what = "action") where TException : Exception
        {
            try
            {
                action();
            }
            catch (TException e)
            {
                return e;
            }
            catch (Exception e)
            {
                throw new CheckFailed($"{what}: expected {typeof(TException).Name}, got {e.GetType().Name}");
            }
            throw new CheckFailed($"{what}: expected {typeof(TException).Name}, nothing thrown");
        }
    }
}
