using Combat.Weapons;
using Combat.Weapons.Mods;

namespace Checks
{
    public static class WeaponModTests
    {
        public static void NoneReadsAuthoredValues()
        {
            Check.Near(2f, WeaponMods.None.Apply(WeaponModField.Damage, 2f), what: "damage");
            Check.Near(0.5f, WeaponMods.None.Apply(WeaponModField.FireRate, 0.5f), what: "fire rate seconds");
            Check.Equal(6, WeaponMods.None.Rounds(6), "rounds");
        }

        public static void StackSumsOnlyFittingPicks()
        {
            var gun = new WeaponComponent(WeaponModField.Damage, WeaponModField.FireRate);
            var stack = new WeaponModStack();
            stack.Add(Mods.Make("dmg a", WeaponModField.Damage, 0.25f));
            stack.Add(Mods.Make("dmg b", WeaponModField.Damage, 0.25f));
            stack.Add(Mods.Make("heat", WeaponModField.HeatCapacity, 0.5f));

            var mods = stack.For(gun, gun);
            Check.Near(1.5f, mods.Factor(WeaponModField.Damage), what: "damage factor");
            Check.Near(1f, mods.Factor(WeaponModField.HeatCapacity), what: "heat factor");
        }

        public static void EffectLineReadsFieldAndAmount()
        {
            Check.Equal("+25% damage", Mods.Make("d", WeaponModField.Damage, 0.25f).Effect, "percent");
            Check.Equal("+2 rounds", Mods.Make("m", WeaponModField.Magazine, 2f).Effect, "rounds");
            Check.Equal("+1 round", Mods.Make("m", WeaponModField.Magazine, 1f).Effect, "round");
        }
    }
}
