"""Print every tool call in a run whose args point outside the workspace, with what came back."""
import json
import sys
from pathlib import Path

run = Path(sys.argv[1])
ws = str(run / "repo").lower()
pending = {}
for i, line in enumerate((run / "transcript.jsonl").read_text(encoding="utf-8").splitlines()):
    e = json.loads(line)
    if e.get("type") == "assistant":
        text = "".join(b.get("text", "") for b in (e.get("message") or {}).get("content") or [] if b.get("type") == "text")
        if text.strip():
            pending["last_text"] = text.strip()[-300:]
    if e.get("type") != "tool_call" or e.get("subtype") != "completed":
        continue
    for name, body in e["tool_call"].items():
        if not name.endswith("ToolCall"):
            continue
        args = body.get("args") or {}
        target = str(args.get("path") or args.get("targetDirectory") or args.get("command") or args.get("globPattern") or "")
        absolute = ":" in target[:3] or target.startswith("/")
        if absolute and not target.lower().replace("/", "\\").startswith(ws) or "cw-runs" in target and ws not in target.lower():
            res = json.dumps(body.get("result"))
            print(f"[{i}] {name} {target[-140:]}")
            print(f"     pattern={args.get('pattern') or args.get('globPattern')} result[{len(res)}]: {res[:400]}")
            print(f"     preceding text: {pending.get('last_text', '')[-250:]!r}")
