Add a weapon mod field `Spread` to `src/Game/Combat/Weapons/Mods/WeaponModField.cs`.

A Spread bonus widens projectile spread. It scales the authored value up, the way Damage does, so it is not a rate field. Give it the next pinned value after the existing fields, label it `spread` in `Label`, and keep `WeaponModFields.Count` equal to the number of fields.

The only file you may change is `src/Game/Combat/Weapons/Mods/WeaponModField.cs`.
