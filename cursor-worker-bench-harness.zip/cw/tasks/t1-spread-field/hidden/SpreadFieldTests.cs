using System;
using Combat.Weapons;
using Combat.Weapons.Mods;

namespace Hidden
{
    public static class SpreadFieldTests
    {
        public static void SpreadIsPinnedAfterBlastRadius() => Check.Equal(8, (int)WeaponModField.Spread, "Spread value");

        public static void ExistingValuesKeepTheirPins()
        {
            Check.Equal(0, (int)WeaponModField.FireRate, "FireRate");
            Check.Equal(1, (int)WeaponModField.Damage, "Damage");
            Check.Equal(2, (int)WeaponModField.HeatCapacity, "HeatCapacity");
            Check.Equal(3, (int)WeaponModField.Cooling, "Cooling");
            Check.Equal(4, (int)WeaponModField.Magazine, "Magazine");
            Check.Equal(5, (int)WeaponModField.ReloadSpeed, "ReloadSpeed");
            Check.Equal(6, (int)WeaponModField.ChargeSpeed, "ChargeSpeed");
            Check.Equal(7, (int)WeaponModField.BlastRadius, "BlastRadius");
        }

        public static void CountMatchesFields()
        {
            Check.Equal(9, WeaponModFields.Count, "Count");
            Check.Equal(Enum.GetValues(typeof(WeaponModField)).Length, WeaponModFields.Count, "Count vs enum");
        }

        public static void LabelIsSpread() => Check.Equal("spread", WeaponModField.Spread.Label(), "label");

        public static void SpreadIsNotARate() => Check.False(WeaponModField.Spread.IsRate(), "IsRate");

        public static void OtherLabelsUnchanged()
        {
            Check.Equal("fire rate", WeaponModField.FireRate.Label(), "fire rate");
            Check.Equal("blast radius", WeaponModField.BlastRadius.Label(), "blast radius");
            Check.True(WeaponModField.ReloadSpeed.IsRate(), "reload is rate");
            Check.False(WeaponModField.Damage.IsRate(), "damage not rate");
        }

        public static void StackScalesSpreadUp()
        {
            var gun = new WeaponComponent(WeaponModField.Spread);
            var stack = new WeaponModStack();
            stack.Add(Mods.Make("wide", WeaponModField.Spread, 0.1f));
            var mods = stack.For(gun, gun);
            Check.Near(1.1f, mods.Factor(WeaponModField.Spread), what: "factor");
            Check.Near(2.2f, mods.Apply(WeaponModField.Spread, 2f), what: "applied");
        }

        public static void EffectLineNamesSpread() =>
            Check.Equal("+10% spread", Mods.Make("wide", WeaponModField.Spread, 0.1f).Effect, "effect");
    }
}
