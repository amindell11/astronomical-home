F = "src/Game/Combat/Weapons/Mods/WeaponModField.cs"


def _edit(t, old, new):
    assert old in t, old
    return t.replace(old, new)


def reference(ws):
    p = ws / F
    t = p.read_text(encoding="utf-8")
    t = _edit(t, "        BlastRadius = 7,\n", "        BlastRadius = 7,\n        Spread = 8,\n")
    t = _edit(t, "public const int Count = 8;", "public const int Count = 9;")
    t = _edit(t, '            WeaponModField.BlastRadius => "blast radius",\n',
              '            WeaponModField.BlastRadius => "blast radius",\n            WeaponModField.Spread => "spread",\n')
    p.write_text(t, encoding="utf-8")
    return "DONE", F, "none"
