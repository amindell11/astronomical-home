Give objective states the time spent in their current step.

1. Add `src/Game/Objectives/ObjectiveTick.cs`: a `public readonly struct ObjectiveTick` in namespace `Objectives`, with a constructor `ObjectiveTick(float deltaTime, float elapsed)` and get-only properties `DeltaTime` and `Elapsed`.
2. Replace `ObjectiveState.Tick(float deltaTime)` with `public abstract void Tick(in ObjectiveTick tick)`, and update every override under `src/Game/Objectives/States/`.
3. `ObjectiveTracker.Tick(float deltaTime)` keeps its public signature. The tracker keeps the seconds spent in the current step. Each call that ticks the current state first adds `deltaTime` to that total, then passes `new ObjectiveTick(deltaTime, elapsed)`. Every step change resets the total to 0: a completed state advancing, the fail criteria firing, `Fail()`, and `Restart()`. So the first tick a step receives has `Elapsed == DeltaTime`.

Keep all other behavior as it is. You may change files under `src/Game/Objectives/` and `src/Game/Objectives/States/` only.
