using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Objectives;
using Objectives.States;
using Ships;

namespace Hidden
{
    public sealed class Probe : ObjectiveState
    {
        public readonly List<(float Delta, float Elapsed)> Ticks = new();
        public bool Done;

        public Probe(ObjectiveType type) { StateType = type; }

        public override ObjectiveType StateType { get; }
        public override bool IsComplete => Done;
        public override void Tick(in ObjectiveTick tick) => Ticks.Add((tick.DeltaTime, tick.Elapsed));
    }

    public sealed class ProbeMission
    {
        public readonly Dictionary<string, List<Probe>> Built = new();
        public readonly ObjectiveTracker Tracker;

        public ProbeMission(Dictionary<string, string> transitions, Func<bool> fail = null)
        {
            var builders = new Dictionary<string, Func<ObjectiveState>>();
            foreach (var step in transitions.Keys.Concat(transitions.Values).Append("failed").Distinct())
            {
                var name = step;
                Built[name] = new List<Probe>();
                builders[name] = () =>
                {
                    var probe = new Probe(ObjectiveType.Explore);
                    Built[name].Add(probe);
                    return probe;
                };
            }
            Tracker = new ObjectiveTracker(new MissionDefinition("a", transitions, fail), builders);
        }

        public Probe Last(string step) => Built[step].Last();
    }

    public static class TickContextTests
    {
        private static void Ticks(Probe probe, params (float, float)[] expected)
        {
            Check.Equal(expected.Length, probe.Ticks.Count, "tick count");
            for (var i = 0; i < expected.Length; i++)
            {
                Check.Near(expected[i].Item1, probe.Ticks[i].Delta, 1e-4f, $"tick {i} delta");
                Check.Near(expected[i].Item2, probe.Ticks[i].Elapsed, 1e-4f, $"tick {i} elapsed");
            }
        }

        public static void ElapsedAccumulatesWithinAStep()
        {
            var m = new ProbeMission(new Dictionary<string, string> { ["a"] = "b" });
            m.Tracker.Tick(0.1f);
            m.Tracker.Tick(0.2f);
            m.Tracker.Tick(0.3f);
            Ticks(m.Last("a"), (0.1f, 0.1f), (0.2f, 0.3f), (0.3f, 0.6f));
        }

        public static void ElapsedRestartsWhenAStepAdvances()
        {
            var m = new ProbeMission(new Dictionary<string, string> { ["a"] = "b" });
            m.Tracker.Tick(0.1f);
            m.Last("a").Done = true;
            m.Tracker.Tick(0.2f);
            Check.Equal("b", m.Tracker.CurrentStep, "advanced");
            m.Tracker.Tick(0.25f);
            m.Tracker.Tick(0.25f);
            Ticks(m.Last("a"), (0.1f, 0.1f), (0.2f, 0.3f));
            Ticks(m.Last("b"), (0.25f, 0.25f), (0.25f, 0.5f));
        }

        public static void ElapsedRestartsOnFail()
        {
            var m = new ProbeMission(new Dictionary<string, string> { ["a"] = "b" });
            m.Tracker.Tick(0.4f);
            m.Tracker.Fail();
            m.Tracker.Tick(0.3f);
            Ticks(m.Last("failed"), (0.3f, 0.3f));
        }

        public static void ElapsedRestartsWhenFailCriteriaFires()
        {
            var fire = false;
            var m = new ProbeMission(new Dictionary<string, string> { ["a"] = "b" }, () =>
            {
                if (!fire) return false;
                fire = false;
                return true;
            });
            m.Tracker.Tick(0.4f);
            fire = true;
            m.Tracker.Tick(0.5f);
            Check.Equal("failed", m.Tracker.CurrentStep, "failed");
            m.Tracker.Tick(0.2f);
            Ticks(m.Last("failed"), (0.2f, 0.2f));
        }

        public static void ElapsedRestartsOnRestart()
        {
            var m = new ProbeMission(new Dictionary<string, string> { ["a"] = "b" });
            m.Tracker.Tick(0.5f);
            m.Tracker.Tick(0.5f);
            m.Tracker.Restart();
            m.Tracker.Tick(0.1f);
            Check.Equal(2, m.Built["a"].Count, "a rebuilt");
            Ticks(m.Last("a"), (0.1f, 0.1f));
        }

        public static void OldFloatTickIsGone()
        {
            var old = typeof(ObjectiveState).GetMethod("Tick", BindingFlags.Public | BindingFlags.Instance, null, new[] { typeof(float) }, null);
            Check.True(old == null, "ObjectiveState.Tick(float) removed");
        }

        public static void ObjectiveTickIsAReadonlyStruct()
        {
            var t = typeof(ObjectiveTick);
            Check.True(t.IsValueType, "value type");
            Check.True(t.IsPublic, "public");
            Check.True(t.GetCustomAttributes(false).Any(a => a.GetType().Name == "IsReadOnlyAttribute"), "readonly");
            var tick = new ObjectiveTick(0.25f, 1.5f);
            Check.Near(0.25f, tick.DeltaTime, what: "DeltaTime");
            Check.Near(1.5f, tick.Elapsed, what: "Elapsed");
            Check.True(t.GetProperty("DeltaTime").SetMethod == null, "DeltaTime get-only");
            Check.True(t.GetProperty("Elapsed").SetMethod == null, "Elapsed get-only");
        }

        public static void TrackerKeepsFloatTick()
        {
            var m = typeof(ObjectiveTracker).GetMethod("Tick", new[] { typeof(float) });
            Check.True(m != null && m.IsPublic, "ObjectiveTracker.Tick(float)");
        }

        public static void DefaultMissionStillWalksToExtracted()
        {
            var keys = new FakeKeys();
            var hostiles = new FakeHostiles();
            var tracker = new ObjectiveTracker(MissionDefinition.CreateDefault(), Missions.DefaultBuilders(keys, hostiles));
            var seen = new List<ObjectiveType>();
            tracker.OnStateChanged += (_, next) => seen.Add(next);
            tracker.Tick(0.1f);
            keys.PlayerHasKey = true;
            tracker.Tick(0.1f);
            tracker.Tick(0.1f);
            hostiles.HostilesCleared = true;
            tracker.Tick(0.1f);
            Check.Sequence(new[] { ObjectiveType.KeyAcquired, ObjectiveType.ClearHostiles, ObjectiveType.Extracted }, seen, "states");
        }

        public static void ExtractionJumpStillCommitsInZone()
        {
            var zone = new FakeZone();
            var hero = new Ship();
            var commits = 0;
            var state = new ExtractionJumpState(zone, hero, () => commits++);
            state.Enter();
            state.Tick(new ObjectiveTick(0.1f, 0.1f));
            hero.RequestJump();
            Check.False(state.IsComplete, "outside zone");
            zone.IsPlayerInZone = true;
            hero.RequestJump();
            Check.True(state.IsComplete, "committed");
            Check.Equal(1, commits, "commits");
        }

        public static void StatesStillReportTheirTypes()
        {
            Check.Equal(ObjectiveType.KeyAcquired, new KeyAcquiredState().StateType, "key");
            Check.Equal(ObjectiveType.Completed, new CompletedState().StateType, "completed");
            Check.Equal(ObjectiveType.ClearHostiles, new ClearHostilesState(new FakeHostiles()).StateType, "clear");
            var key = new KeyAcquiredState();
            key.Tick(new ObjectiveTick(0.1f, 0.1f));
            Check.True(key.IsComplete, "key complete");
        }
    }
}
