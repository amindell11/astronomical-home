Write tests for `WeaponModOffers.Draw` and `WeaponMods` in a new file `tests/Checks/WeaponModOfferTests.cs`, as a `public static class WeaponModOfferTests`. Follow the runner's conventions in `tests/Checks/Runner.cs` and reuse the helpers in `tests/Checks/Fakes.cs`.

Cover each of these behaviors with at least one test:

1. `Draw` returns at most `count` mods.
2. `Draw` never returns the same mod twice.
3. `Draw` leaves out mods that `fits` rejects.
4. `Draw` skips null entries in the pool.
5. `Draw` returns every fitting mod when fewer than `count` fit.
6. `Draw` picks with `randomBelow`: the value it returns indexes the fitting mods that are still undrawn, in pool order.
7. `WeaponMods.Apply` divides a rate field's authored seconds by the field's factor, and multiplies every other field's authored value by its factor.
8. `WeaponMods.Rounds` adds the picked Magazine rounds to the authored count.

The tests must pass against the current code. Do not change anything under `src/`. The only file you may create or change is `tests/Checks/WeaponModOfferTests.cs`.
