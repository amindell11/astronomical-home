import shutil

OFFERS = "src/Game/Combat/Weapons/Mods/WeaponModOffers.cs"
MODS = "src/Game/Combat/Weapons/Mods/WeaponMods.cs"

MUTANTS = {
    "m1_count_off_by_one": (OFFERS, "offer.Count < count", "offer.Count <= count"),
    "m2_draws_duplicates": (OFFERS, "fitting.RemoveAt(index);", ""),
    "m3_ignores_fits": (OFFERS, "if (mod && fits(mod))", "if (mod)"),
    "m4_keeps_nulls": (OFFERS, "if (mod && fits(mod))", "if (mod == null || fits(mod))"),
    "m5_reversed_index": (OFFERS, "var index = randomBelow(fitting.Count);", "var index = fitting.Count - 1 - randomBelow(fitting.Count);"),
    "m6_rate_multiplies": (MODS, "field.IsRate() ? authored / Factor(field)", "field.IsRate() ? authored * Factor(field)"),
    "m7_rounds_ignored": (MODS, "public int Rounds(int authored) => authored + rounds;", "public int Rounds(int authored) => authored;"),
    "m8_bonus_added": (MODS, ": authored * Factor(field);", ": authored + bonus[(int)field];"),
}


def check(ctx):
    test_file = ctx["ws"] / "tests/Checks/WeaponModOfferTests.cs"
    if not test_file.exists():
        return {"ok_own_tests_pass_clean": False, "ok_mutants_killed": False, "killed": 0, "mutants": len(MUTANTS),
                "survivors": list(MUTANTS)}
    clean = ctx["run_tests"]("tests/Checks", ctx["verify"], "WeaponModOfferTests")
    own_tests = clean["passed"] + clean["failed"]
    survivors = []
    for name, (rel, old, new) in MUTANTS.items():
        mdir = ctx["verify"].parent / f"mutant_{name}"
        if mdir.exists():
            shutil.rmtree(mdir)
        ctx["copy_tree"](ctx["verify"], mdir)
        pristine = (ctx["fixture"] / rel).read_text(encoding="utf-8")
        assert old in pristine, name
        (mdir / rel).write_text(pristine.replace(old, new, 1), encoding="utf-8")
        res = ctx["run_tests"]("tests/Checks", mdir, "WeaponModOfferTests")
        if res["built"] and res["failed"] == 0:
            survivors.append(name)
        shutil.rmtree(mdir, ignore_errors=True)
    return {
        "ok_own_tests_pass_clean": clean["built"] and clean["failed"] == 0 and own_tests > 0,
        "ok_mutants_killed": not survivors,
        "own_tests": own_tests,
        "killed": len(MUTANTS) - len(survivors),
        "mutants": len(MUTANTS),
        "survivors": survivors,
    }


REFERENCE_TESTS = '''using System.Linq;
using Combat.Weapons;
using Combat.Weapons.Mods;

namespace Checks
{
    public static class WeaponModOfferTests
    {
        private static readonly WeaponMod A = Mods.Make("a", WeaponModField.Damage, 0.1f);
        private static readonly WeaponMod B = Mods.Make("b", WeaponModField.Damage, 0.1f);
        private static readonly WeaponMod C = Mods.Make("c", WeaponModField.Cooling, 0.1f);
        private static readonly WeaponMod D = Mods.Make("d", WeaponModField.Damage, 0.1f);

        public static void DrawCapsAtCount() =>
            Check.Equal(2, WeaponModOffers.Draw(new[] { A, B, C, D }, _ => true, 2, _ => 0).Count, "count");

        public static void DrawNeverRepeats() =>
            Check.Equal(3, WeaponModOffers.Draw(new[] { A, B, C }, _ => true, 3, _ => 0).Distinct().Count(), "distinct");

        public static void DrawLeavesOutRejected() =>
            Check.Sequence(new[] { A, B, D }, WeaponModOffers.Draw(new[] { A, B, C, D }, m => m.Field == WeaponModField.Damage, 5, _ => 0), "fitting");

        public static void DrawSkipsNulls() =>
            Check.Sequence(new[] { A }, WeaponModOffers.Draw(new[] { null, A, null }, _ => true, 3, _ => 0), "no nulls");

        public static void DrawReturnsAllWhenFewFit() =>
            Check.Equal(3, WeaponModOffers.Draw(new[] { A, B, C }, _ => true, 10, _ => 0).Count, "all");

        public static void DrawIndexesUndrawnInPoolOrder() =>
            Check.Sequence(new[] { C, A, D }, WeaponModOffers.Draw(new[] { A, B, C, D }, _ => true, 3, n => n == 4 ? 2 : n == 3 ? 0 : 1), "picks");

        public static void ApplyDividesRatesMultipliesOthers()
        {
            var gun = new WeaponComponent(WeaponModField.FireRate, WeaponModField.Damage);
            var stack = new WeaponModStack();
            stack.Add(Mods.Make("r", WeaponModField.FireRate, 1f));
            stack.Add(Mods.Make("d", WeaponModField.Damage, 0.5f));
            var mods = stack.For(gun, gun);
            Check.Near(0.25f, mods.Apply(WeaponModField.FireRate, 0.5f), what: "rate");
            Check.Near(3f, mods.Apply(WeaponModField.Damage, 2f), what: "damage");
        }

        public static void RoundsAddsMagazine()
        {
            var gun = new WeaponComponent(WeaponModField.Magazine);
            var stack = new WeaponModStack();
            stack.Add(Mods.Make("m", WeaponModField.Magazine, 2f));
            Check.Equal(8, stack.For(gun, gun).Rounds(6), "rounds");
        }
    }
}
'''


def reference(ws):
    (ws / "tests/Checks/WeaponModOfferTests.cs").write_text(REFERENCE_TESTS, encoding="utf-8")
    return "DONE", "tests/Checks/WeaponModOfferTests.cs", "none"
