Add this method to `MissionDefinition` in `src/Game/Objectives/MissionDefinition.cs`:

    public IReadOnlyList<string> Validate(IEnumerable<string> builtSteps)

`builtSteps` names the steps that have a state builder. Treat it as a set; it may contain duplicates. A null `builtSteps` throws `ArgumentNullException`.

The method returns every problem with the mission's table, using exactly these messages and in this order, or an empty list when there are none:

1. `missing initial step` when `InitialStep` is null or empty. In that case return this one problem and nothing else.
2. `no builder for '<step>'` for each step the table names that is not in `builtSteps`. The table names the initial step first, then each transition's key followed by its value, in the order `Transitions` enumerates. Report each step once, at its first mention.
3. `no builder for 'failed'` when `FailCriteria` is not null and `builtSteps` lacks `failed`, unless rule 2 already reported `failed`.
4. `unreachable step '<step>'` for each transition key that the walk never visits, in the order `Transitions` enumerates. The walk starts at `InitialStep` and follows `Transitions` until it reaches a step with no transition or a step it has already visited.
5. `cycle at '<step>'` when the walk reaches a step it has already visited; `<step>` is that step. Report at most one cycle.

The only file you may change is `src/Game/Objectives/MissionDefinition.cs`.
