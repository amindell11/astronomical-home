using System;
using System.Collections.Generic;
using Objectives;

namespace Hidden
{
    public static class ValidateTests
    {
        private static Dictionary<string, string> Table(params string[] pairs)
        {
            var t = new Dictionary<string, string>();
            for (var i = 0; i < pairs.Length; i += 2) t.Add(pairs[i], pairs[i + 1]);
            return t;
        }

        private static void Expect(MissionDefinition mission, IEnumerable<string> built, params string[] problems) =>
            Check.Sequence(problems, mission.Validate(built), "problems");

        public static void NullBuiltStepsThrows() =>
            Check.Throws<ArgumentNullException>(() => MissionDefinition.CreateDefault().Validate(null), "null builtSteps");

        public static void MissingInitialStepIsTheOnlyProblem()
        {
            Expect(new MissionDefinition("", Table("a", "b", "c", "d"), () => false), new string[0], "missing initial step");
            Expect(new MissionDefinition(null, Table("a", "b")), new[] { "a" }, "missing initial step");
        }

        public static void DefaultMissionIsClean()
        {
            var built = new[] { "explore", "key", "extraction", "extracted" };
            var problems = MissionDefinition.CreateDefault().Validate(built);
            Check.True(problems != null, "not null");
            Check.Equal(0, problems.Count, "count");
        }

        public static void FailCriteriaNeedsAFailedBuilder()
        {
            var built = new List<string> { "explore", "key", "extraction", "extracted" };
            Expect(MissionDefinition.CreateDefault(() => false), built, "no builder for 'failed'");
            built.Add("failed");
            Expect(MissionDefinition.CreateDefault(() => false), built);
        }

        public static void MissingBuildersInFirstMentionOrder() =>
            Expect(new MissionDefinition("a", Table("a", "b", "c", "b", "b", "d")), new[] { "a" },
                "no builder for 'b'", "no builder for 'c'", "no builder for 'd'", "unreachable step 'c'");

        public static void MissingInitialBuilderComesFirst() =>
            Expect(new MissionDefinition("a", Table("a", "b")), new string[0],
                "no builder for 'a'", "no builder for 'b'");

        public static void LoneInitialStepWithoutBuilder() =>
            Expect(new MissionDefinition("solo", null), new string[0], "no builder for 'solo'");

        public static void DuplicateBuiltStepsActAsASet() =>
            Expect(new MissionDefinition("a", Table("a", "b", "b", "c")), new[] { "a", "a", "b", "b" },
                "no builder for 'c'");

        public static void FailedInTableIsReportedOnce() =>
            Expect(new MissionDefinition("a", Table("a", "failed"), () => true), new[] { "a" },
                "no builder for 'failed'");

        public static void FailedNotNeededWithoutFailCriteria() =>
            Expect(new MissionDefinition("a", Table("a", "b")), new[] { "a", "b" });

        public static void UnreachableKeysInEnumerationOrder() =>
            Expect(new MissionDefinition("a", Table("a", "b", "x", "y", "b", "c", "z", "a")),
                new[] { "a", "b", "c", "x", "y", "z" },
                "unreachable step 'x'", "unreachable step 'z'");

        public static void CycleReportsFirstRevisitedStep() =>
            Expect(new MissionDefinition("a", Table("a", "b", "b", "c", "c", "b")), new[] { "a", "b", "c" },
                "cycle at 'b'");

        public static void SelfLoopIsACycle() =>
            Expect(new MissionDefinition("a", Table("a", "a")), new[] { "a" }, "cycle at 'a'");

        public static void CycleComesAfterUnreachable() =>
            Expect(new MissionDefinition("a", Table("a", "b", "b", "a", "q", "r")), new[] { "a", "b", "q", "r" },
                "unreachable step 'q'", "cycle at 'a'");

        public static void AllRulesInOrder() =>
            Expect(new MissionDefinition("a", Table("a", "b", "x", "b"), () => false), new[] { "a", "x" },
                "no builder for 'b'", "no builder for 'failed'", "unreachable step 'x'");

        public static void ValidateDoesNotChangeTheTable()
        {
            var mission = new MissionDefinition("a", Table("a", "b", "q", "r"));
            mission.Validate(new[] { "a" });
            Check.Equal(2, mission.Transitions.Count, "transitions");
            Check.True(mission.TryGetNext("a", out var next) && next == "b", "a -> b");
        }
    }
}
