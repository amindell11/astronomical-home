F = "src/Game/Objectives/MissionDefinition.cs"
ANCHOR = "        /// <summary>\n        /// Standard sequential single-mission flow:"
METHOD = '''        public IReadOnlyList<string> Validate(IEnumerable<string> builtSteps)
        {
            if (builtSteps == null) throw new ArgumentNullException(nameof(builtSteps));
            if (string.IsNullOrEmpty(InitialStep)) return new[] { "missing initial step" };

            var built = new HashSet<string>(builtSteps);
            var problems = new List<string>();
            var reported = new HashSet<string>();
            void Need(string step)
            {
                if (!built.Contains(step) && reported.Add(step)) problems.Add($"no builder for '{step}'");
            }
            Need(InitialStep);
            foreach (var t in Transitions)
            {
                Need(t.Key);
                Need(t.Value);
            }
            if (FailCriteria != null && !built.Contains("failed") && !reported.Contains("failed"))
                problems.Add("no builder for 'failed'");

            var visited = new HashSet<string>();
            string cycle = null;
            var step = InitialStep;
            while (true)
            {
                if (!visited.Add(step)) { cycle = step; break; }
                if (!Transitions.TryGetValue(step, out var next)) break;
                step = next;
            }
            foreach (var t in Transitions)
                if (!visited.Contains(t.Key)) problems.Add($"unreachable step '{t.Key}'");
            if (cycle != null) problems.Add($"cycle at '{cycle}'");
            return problems;
        }

'''


def reference(ws):
    p = ws / F
    t = p.read_text(encoding="utf-8")
    assert ANCHOR in t
    p.write_text(t.replace(ANCHOR, METHOD + ANCHOR), encoding="utf-8")
    return "DONE", F, "none"
