I refactored `src/Game/Objectives/ObjectiveState.cs` so a state's type is a constructor argument instead of an overridden property. That change is uncommitted in the working tree and is intended: do not edit, revert or restore that file. A mismatch between it and HEAD is not staleness.

The build is now broken. Fix it. Each state under `src/Game/Objectives/States/` passes its existing type to the base constructor and drops its `StateType` override. Change nothing else: every state keeps its public constructors and behavior, and every other file stays as it is.

You may change files under `src/Game/Objectives/States/` only.
