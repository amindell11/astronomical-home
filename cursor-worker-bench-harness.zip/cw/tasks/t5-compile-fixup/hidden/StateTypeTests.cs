using System;
using System.Reflection;
using Objectives;
using Objectives.States;
using Ships;

namespace Hidden
{
    public static class StateTypeTests
    {
        public static void EveryStateKeepsItsType()
        {
            Check.Equal(ObjectiveType.Explore, new ExploreState(new FakeKeys()).StateType, "explore");
            Check.Equal(ObjectiveType.KeyAcquired, new KeyAcquiredState().StateType, "key");
            Check.Equal(ObjectiveType.ClearHostiles, new ClearHostilesState(new FakeHostiles()).StateType, "clear");
            Check.Equal(ObjectiveType.ExtractionChallenge, new ExtractionJumpState(new FakeZone(), null, () => { }).StateType, "jump");
            Check.Equal(ObjectiveType.Extracted, new ExtractedState().StateType, "extracted");
            Check.Equal(ObjectiveType.Failed, new FailedState().StateType, "failed");
            Check.Equal(ObjectiveType.Completed, new CompletedState().StateType, "completed");
        }

        public static void NoStateRedeclaresStateType()
        {
            foreach (var t in new[] { typeof(ExploreState), typeof(KeyAcquiredState), typeof(ClearHostilesState), typeof(ExtractionJumpState),
                         typeof(ExtractedState), typeof(FailedState), typeof(CompletedState) })
                Check.True(t.GetProperty("StateType", BindingFlags.Public | BindingFlags.Instance | BindingFlags.DeclaredOnly) == null,
                    t.Name + " declares no StateType");
        }

        public static void OnEnterStillFires()
        {
            var fired = 0;
            new ExtractedState(() => fired++).Enter();
            new FailedState(() => fired++).Enter();
            new CompletedState(() => fired++).Enter();
            new ExtractionJumpState(new FakeZone(), null, () => { }, () => fired++).Enter();
            Check.Equal(4, fired, "onEnter calls");
        }

        public static void PublicConstructorsUnchanged()
        {
            void Has(Type t, params Type[] args) =>
                Check.True(t.GetConstructor(args) != null, $"{t.Name}({string.Join(", ", (object[])args)})");
            Has(typeof(ExploreState), typeof(IKeyTracker));
            Has(typeof(KeyAcquiredState));
            Has(typeof(ClearHostilesState), typeof(IHostileTracker));
            Has(typeof(ExtractionJumpState), typeof(IExtractionZone), typeof(Ship), typeof(Action), typeof(Action));
            Has(typeof(ExtractedState), typeof(Action));
            Has(typeof(FailedState), typeof(Action));
            Has(typeof(CompletedState), typeof(Action));
        }

        public static void BehaviorUnchanged()
        {
            var keys = new FakeKeys();
            var explore = new ExploreState(keys);
            Check.False(explore.IsComplete, "explore before key");
            keys.PlayerHasKey = true;
            Check.True(explore.IsComplete, "explore after key");
            Check.True(new KeyAcquiredState().IsComplete, "key immediate");
            Check.False(new CompletedState().IsComplete, "completed never completes");
            Check.Throws<ArgumentNullException>(() => new ClearHostilesState(null), "clear null");

            var zone = new FakeZone { IsPlayerInZone = true };
            var hero = new Ship();
            var jump = new ExtractionJumpState(zone, hero, () => { });
            jump.Enter();
            Check.Equal("PRESS F TO JUMP", jump.StatusLine, "status line");
            hero.RequestJump();
            Check.True(jump.IsComplete, "jump committed");
        }
    }
}
