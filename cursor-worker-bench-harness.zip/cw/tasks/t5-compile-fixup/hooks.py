import re

STATE = "src/Game/Objectives/ObjectiveState.cs"
OLD_CTOR = """        protected ObjectiveState(Action onEnter = null)
        {
            this.onEnter = onEnter;
        }

        public abstract ObjectiveType StateType { get; }"""
NEW_CTOR = """        protected ObjectiveState(ObjectiveType stateType, Action onEnter = null)
        {
            StateType = stateType;
            this.onEnter = onEnter;
        }

        public ObjectiveType StateType { get; }"""


def refactored(text):
    assert OLD_CTOR in text
    return text.replace(OLD_CTOR, NEW_CTOR)


def setup_uncommitted(ws):
    path = ws / STATE
    path.write_text(refactored(path.read_text(encoding="utf-8")), encoding="utf-8")


def check(ctx):
    expected = refactored((ctx["fixture"] / STATE).read_text(encoding="utf-8"))
    actual = (ctx["ws"] / STATE).read_text(encoding="utf-8")
    return {"ok_refactor_kept": actual == expected}


def reference(ws):
    for path in (ws / "src/Game/Objectives/States").glob("*.cs"):
        t = path.read_text(encoding="utf-8")
        m = re.search(r"\n\s*public override ObjectiveType StateType => ObjectiveType\.(\w+);", t)
        kind = f"ObjectiveType.{m.group(1)}"
        t = t.replace(m.group(0), "")
        cls = path.stem
        if ": base(" in t:
            t = t.replace(": base(", f": base({kind}, ", 1)
        elif re.search(rf"public {cls}\([^)]*\)\n", t):
            t = re.sub(rf"(public {cls}\([^)]*\))\n", rf"\1 : base({kind})\n", t, count=1)
        else:
            t = re.sub(rf"(class {cls} : ObjectiveState\n    {{\n)", rf"\1        public {cls}() : base({kind}) {{ }}\n\n", t, count=1)
        path.write_text(t, encoding="utf-8")
    return "DONE", "src/Game/Objectives/States/*.cs", "none"
