Make `KeyAcquiredState` hold for a fanfare. It takes a `float holdSeconds` constructor argument and completes only once the time ticked since `Enter` reaches `holdSeconds`.

Update the `"key"` builder in `tests/Checks/Fakes.cs` to pass `0.5f`. Do not edit any other test file. All tests in `tests/Checks` must pass when you are done.

You may change `src/Game/Objectives/States/KeyAcquiredState.cs` and `tests/Checks/Fakes.cs` only.
