`dotnet run --project tests/Checks` fails: `WeaponModTests.StackForIsRepeatable`. Chase the failure to its root cause and fix it there.

Do not change any test file. You may change files under `src/Game/` only.
