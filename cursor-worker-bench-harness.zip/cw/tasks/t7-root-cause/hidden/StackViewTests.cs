using Combat.Weapons;
using Combat.Weapons.Mods;

namespace Hidden
{
    public static class StackViewTests
    {
        public static void ForIsRepeatable()
        {
            var gun = new WeaponComponent(WeaponModField.Damage);
            var stack = new WeaponModStack();
            stack.Add(Mods.Make("dmg", WeaponModField.Damage, 0.25f));
            for (var i = 0; i < 3; i++)
                Check.Near(1.25f, stack.For(gun, gun).Factor(WeaponModField.Damage), what: $"view {i}");
        }

        public static void EarlierViewKeepsItsValuesAfterANewPick()
        {
            var gun = new WeaponComponent(WeaponModField.Damage);
            var stack = new WeaponModStack();
            stack.Add(Mods.Make("dmg a", WeaponModField.Damage, 0.25f));
            var before = stack.For(gun, gun);
            stack.Add(Mods.Make("dmg b", WeaponModField.Damage, 0.25f));
            var after = stack.For(gun, gun);
            Check.Near(1.25f, before.Factor(WeaponModField.Damage), what: "view handed out before the pick");
            Check.Near(1.5f, after.Factor(WeaponModField.Damage), what: "view after the pick");
        }

        public static void ViewsForDifferentMountsAreIndependent()
        {
            var cannon = new WeaponComponent(WeaponModField.Damage);
            var laser = new WeaponComponent(WeaponModField.Cooling);
            var stack = new WeaponModStack();
            stack.Add(Mods.Make("dmg", WeaponModField.Damage, 0.25f));
            stack.Add(Mods.Make("cool", WeaponModField.Cooling, 0.5f));
            var cannonMods = stack.For(cannon, cannon);
            var laserMods = stack.For(laser, laser);
            Check.Near(1.25f, cannonMods.Factor(WeaponModField.Damage), what: "cannon damage");
            Check.Near(1f, cannonMods.Factor(WeaponModField.Cooling), what: "cannon cooling");
            Check.Near(1.5f, laserMods.Factor(WeaponModField.Cooling), what: "laser cooling");
            Check.Near(1f, laserMods.Factor(WeaponModField.Damage), what: "laser damage");
        }

        public static void ClearedStackHandsOutNone()
        {
            var gun = new WeaponComponent(WeaponModField.Damage);
            var stack = new WeaponModStack();
            stack.Add(Mods.Make("dmg", WeaponModField.Damage, 0.25f));
            stack.For(gun, gun);
            stack.Clear();
            Check.True(ReferenceEquals(WeaponMods.None, stack.For(gun, gun)), "None after Clear");
            Check.Near(1f, WeaponMods.None.Factor(WeaponModField.Damage), what: "None unchanged");
        }

        public static void MagazineRoundsDoNotAccumulate()
        {
            var gun = new WeaponComponent(WeaponModField.Magazine, WeaponModField.Damage);
            var stack = new WeaponModStack();
            stack.Add(Mods.Make("mag", WeaponModField.Magazine, 2f));
            stack.Add(Mods.Make("dmg", WeaponModField.Damage, 0.25f));
            stack.For(gun, gun);
            var mods = stack.For(gun, gun);
            Check.Equal(8, mods.Rounds(6), "rounds");
            Check.Near(1.25f, mods.Factor(WeaponModField.Damage), what: "damage");
        }
    }
}
