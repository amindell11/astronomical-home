STACK = "src/Game/Combat/Weapons/Mods/WeaponModStack.cs"
TESTS = "tests/Checks/WeaponModTests.cs"

FIELD_OLD = "        private readonly List<WeaponMod> picks = new();\n"
FIELD_NEW = FIELD_OLD + "        private readonly float[] bonus = new float[WeaponModFields.Count];\n"
LOCAL = "            var bonus = new float[WeaponModFields.Count];\n"

VISIBLE_ANCHOR = "        public static void EffectLineReadsFieldAndAmount()"
VISIBLE_TEST = """        public static void StackForIsRepeatable()
        {
            var gun = new WeaponComponent(WeaponModField.Damage);
            var stack = new WeaponModStack();
            stack.Add(Mods.Make("dmg", WeaponModField.Damage, 0.25f));
            Check.Near(1.25f, stack.For(gun, gun).Factor(WeaponModField.Damage), what: "first view");
            Check.Near(1.25f, stack.For(gun, gun).Factor(WeaponModField.Damage), what: "second view");
        }

"""


def _edit(path, old, new):
    t = path.read_text(encoding="utf-8")
    assert old in t, (path, old)
    path.write_text(t.replace(old, new, 1), encoding="utf-8")


def setup_committed(ws):
    _edit(ws / STACK, FIELD_OLD, FIELD_NEW)
    _edit(ws / STACK, LOCAL, "")
    _edit(ws / TESTS, VISIBLE_ANCHOR, VISIBLE_TEST + VISIBLE_ANCHOR)


def reference(ws):
    _edit(ws / STACK, FIELD_NEW, FIELD_OLD)
    _edit(ws / STACK, "            var any = false;\n", "            var any = false;\n" + LOCAL)
    return "DONE", STACK, "none"


def guard_fix(ws):
    """The symptomatic fix the task tempts: clear the cached array on every call."""
    _edit(ws / STACK, "            var any = false;\n", "            var any = false;\n            System.Array.Clear(bonus, 0, bonus.Length);\n")
    return "DONE", STACK, "none"
