Extend weapon mods. There are five parts, and every one is required.

1. In `WeaponModStack` (`src/Game/Combat/Weapons/Mods/WeaponModStack.cs`) add:
   a. `public IReadOnlyList<WeaponMod> Picks`: the picks in pick order, as a live read-only view. Picks added after a caller took the view show through it, and callers cannot add or remove through it.
   b. `public bool Remove(WeaponMod mod)`: removes the most recent pick of `mod` and returns true. Returns false when `mod` is not currently picked. A null `mod` throws `ArgumentNullException`.
   c. `public event Action Changed`: raised once after every `Add`, after a `Remove` that removed a pick, and after a `Clear` that removed at least one pick. It is never raised otherwise, and handlers already see the new picks.
   d. `public IReadOnlyList<string> Summary()`: one line per distinct mod (the same `WeaponMod` object) among the current picks, ordered by each mod's earliest position in `Picks`. A line reads `<DisplayName>: <Effect>`, followed by ` x<n>` when that mod is currently picked n times and n is at least 2. Empty when there are no picks.
2. In `WeaponModFields` (`src/Game/Combat/Weapons/Mods/WeaponModField.cs`) add `public static WeaponModField Parse(string label)`. It returns the field whose `Label()` equals `label`, ignoring case and surrounding whitespace. Anything else, including null, throws an `ArgumentException` whose `Message` is exactly `unknown weapon mod field '<label>'`, where `<label>` is the argument exactly as passed and a null argument prints as `null`.
3. Do not use LINQ in any file under `src/`.
4. `WeaponModStack` stays `sealed`, and `For` keeps its current behavior.
5. Add `tests/Checks/WeaponModStackTests.cs` with a `public static class WeaponModStackTests` whose tests cover every rule in 1b, 1c and 1d.

You may change `src/Game/Combat/Weapons/Mods/WeaponModStack.cs` and `src/Game/Combat/Weapons/Mods/WeaponModField.cs`, and create `tests/Checks/WeaponModStackTests.cs`. Nothing else.
