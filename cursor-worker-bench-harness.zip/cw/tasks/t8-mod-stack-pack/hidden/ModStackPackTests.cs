using System;
using System.Collections.Generic;
using Combat.Weapons;
using Combat.Weapons.Mods;

namespace Hidden
{
    public static class ModStackPackTests
    {
        private static readonly WeaponMod A = Mods.Make("a", WeaponModField.Damage, 0.1f);
        private static readonly WeaponMod B = Mods.Make("b", WeaponModField.Cooling, 0.25f);
        private static readonly WeaponMod M = Mods.Make("mag", WeaponModField.Magazine, 2f);

        private static WeaponModStack Stack(params WeaponMod[] mods)
        {
            var s = new WeaponModStack();
            foreach (var m in mods) s.Add(m);
            return s;
        }

        public static void PicksInPickOrder() => Check.Sequence(new[] { B, A, B }, Stack(B, A, B).Picks, "picks");

        public static void PicksIsALiveReadOnlyView()
        {
            var s = new WeaponModStack();
            var view = s.Picks;
            s.Add(A);
            s.Add(B);
            Check.Equal(2, view.Count, "live count");
            Check.True(ReferenceEquals(B, view[1]), "live item");
            Check.False(view is List<WeaponMod>, "not the backing list");
            Check.True(view is ICollection<WeaponMod> c && c.IsReadOnly, "read-only collection");
        }

        public static void RemoveTakesTheMostRecentPick()
        {
            var s = Stack(A, B, A, B);
            Check.True(s.Remove(A), "removed");
            Check.Sequence(new[] { A, B, B }, s.Picks, "picks");
        }

        public static void RemoveReturnsFalseWhenNotPicked()
        {
            var s = Stack(A);
            Check.False(s.Remove(B), "never picked");
            Check.True(s.Remove(A), "picked");
            Check.False(s.Remove(A), "already removed");
            Check.Equal(0, s.Picks.Count, "empty");
        }

        public static void RemoveNullThrows() => Check.Throws<ArgumentNullException>(() => Stack(A).Remove(null), "null");

        public static void ChangedFollowsRealChangesOnly()
        {
            var s = new WeaponModStack();
            var seen = new List<int>();
            s.Changed += () => seen.Add(s.Picks.Count);
            s.Clear();
            s.Add(A);
            s.Add(B);
            s.Remove(M);
            s.Remove(A);
            s.Clear();
            s.Clear();
            Check.Sequence(new[] { 1, 2, 1, 0 }, seen, "Changed with the count each handler saw");
        }

        public static void SummaryCountsRepeatPicks() =>
            Check.Sequence(new[] { "a: +10% damage x3", "b: +25% cooling", "mag: +2 rounds" }, Stack(A, B, A, M, A).Summary(), "summary");

        public static void SummaryFollowsCurrentPicksOrder()
        {
            var s = Stack(A, B);
            s.Remove(A);
            s.Add(A);
            Check.Sequence(new[] { "b: +25% cooling", "a: +10% damage" }, s.Summary(), "order after re-pick");
            s.Add(B);
            Check.Sequence(new[] { "b: +25% cooling x2", "a: +10% damage" }, s.Summary(), "count after re-pick");
        }

        public static void SummaryKeepsSameNamedModsApart()
        {
            var first = Mods.Make("twin", WeaponModField.Damage, 0.1f);
            var second = Mods.Make("twin", WeaponModField.Damage, 0.1f);
            Check.Sequence(new[] { "twin: +10% damage", "twin: +10% damage" }, Stack(first, second).Summary(), "two objects");
        }

        public static void SummaryEmptyWithoutPicks()
        {
            Check.Equal(0, new WeaponModStack().Summary().Count, "new");
            var s = Stack(A);
            s.Remove(A);
            Check.Equal(0, s.Summary().Count, "after remove");
        }

        public static void ParseMatchesLabelsLoosely()
        {
            for (var i = 0; i < WeaponModFields.Count; i++)
            {
                var field = (WeaponModField)i;
                Check.Equal(field, WeaponModFields.Parse(field.Label()), field.ToString());
            }
            Check.Equal(WeaponModField.FireRate, WeaponModFields.Parse("  Fire RATE "), "case and whitespace");
            Check.Equal(WeaponModField.BlastRadius, WeaponModFields.Parse("BLAST RADIUS"), "upper");
        }

        public static void ParseRejectsWithExactMessage()
        {
            Check.Equal("unknown weapon mod field 'nope'",
                Check.Throws<ArgumentException>(() => WeaponModFields.Parse("nope"), "nope").Message, "nope");
            Check.Equal("unknown weapon mod field '  Fire  rate '",
                Check.Throws<ArgumentException>(() => WeaponModFields.Parse("  Fire  rate "), "inner space").Message, "as passed");
            Check.Equal("unknown weapon mod field 'null'",
                Check.Throws<ArgumentException>(() => WeaponModFields.Parse(null), "null").Message, "null");
            Check.Equal("unknown weapon mod field ''",
                Check.Throws<ArgumentException>(() => WeaponModFields.Parse(""), "empty").Message, "empty");
        }

        public static void StackStaysSealed() => Check.True(typeof(WeaponModStack).IsSealed, "sealed");

        public static void ForStillSumsFittingPicks()
        {
            var gun = new WeaponComponent(WeaponModField.Damage, WeaponModField.Magazine);
            var s = Stack(A, B, A, M);
            var mods = s.For(gun, gun);
            Check.Near(1.2f, mods.Factor(WeaponModField.Damage), what: "damage");
            Check.Near(1f, mods.Factor(WeaponModField.Cooling), what: "cooling not fitted");
            Check.Equal(8, mods.Rounds(6), "rounds");
            Check.True(ReferenceEquals(WeaponMods.None, new WeaponModStack().For(gun, gun)), "None when empty");
        }
    }
}
