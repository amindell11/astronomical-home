import re
import shutil

STACK = "src/Game/Combat/Weapons/Mods/WeaponModStack.cs"
FIELD = "src/Game/Combat/Weapons/Mods/WeaponModField.cs"
TESTS = "tests/Checks/WeaponModStackTests.cs"

REFERENCE_STACK = '''using System;
using System.Collections.Generic;

namespace Combat.Weapons.Mods
{
    public sealed class WeaponModStack
    {
        private readonly List<WeaponMod> picks = new();

        public WeaponModStack()
        {
            Picks = picks.AsReadOnly();
        }

        public event Action Changed;

        public IReadOnlyList<WeaponMod> Picks { get; }

        public void Add(WeaponMod mod)
        {
            if (!mod) throw new ArgumentNullException(nameof(mod));
            picks.Add(mod);
            Changed?.Invoke();
        }

        public bool Remove(WeaponMod mod)
        {
            if (!mod) throw new ArgumentNullException(nameof(mod));
            var index = picks.LastIndexOf(mod);
            if (index < 0) return false;
            picks.RemoveAt(index);
            Changed?.Invoke();
            return true;
        }

        public void Clear()
        {
            if (picks.Count == 0) return;
            picks.Clear();
            Changed?.Invoke();
        }

        public IReadOnlyList<string> Summary()
        {
            var order = new List<WeaponMod>();
            var counts = new Dictionary<WeaponMod, int>();
            foreach (var mod in picks)
            {
                if (counts.TryGetValue(mod, out var n)) counts[mod] = n + 1;
                else
                {
                    counts[mod] = 1;
                    order.Add(mod);
                }
            }
            var lines = new List<string>(order.Count);
            foreach (var mod in order)
                lines.Add(counts[mod] > 1 ? $"{mod.DisplayName}: {mod.Effect} x{counts[mod]}" : $"{mod.DisplayName}: {mod.Effect}");
            return lines;
        }

        public WeaponMods For(WeaponComponent mount, WeaponComponent prefab)
        {
            var any = false;
            var bonus = new float[WeaponModFields.Count];
            var rounds = 0;
            foreach (var mod in picks)
            {
                if (!mod.Fits(mount, prefab)) continue;
                any = true;
                if (mod.Field == WeaponModField.Magazine) rounds += mod.Rounds;
                else bonus[(int)mod.Field] += mod.Amount;
            }
            return any ? new WeaponMods(bonus, rounds) : WeaponMods.None;
        }
    }
}
'''

PARSE_ANCHOR = "        public static string Label(this WeaponModField field) => field switch"
PARSE = '''        public static WeaponModField Parse(string label)
        {
            var key = label?.Trim();
            for (var i = 0; i < Count; i++)
            {
                var field = (WeaponModField)i;
                if (string.Equals(field.Label(), key, System.StringComparison.OrdinalIgnoreCase)) return field;
            }
            throw new System.ArgumentException($"unknown weapon mod field '{label ?? "null"}'");
        }

'''

MUTANTS = {
    "m1_removes_first_pick": ("var index = picks.LastIndexOf(mod);", "var index = picks.IndexOf(mod);"),
    "m2_remove_always_true": ("if (index < 0) return false;", "if (index < 0) return true;"),
    "m3_remove_null_quiet": ("        public bool Remove(WeaponMod mod)\n        {\n            if (!mod) throw new ArgumentNullException(nameof(mod));",
                             "        public bool Remove(WeaponMod mod)\n        {\n            if (!mod) return false;"),
    "m4_changed_on_failed_remove": ("if (index < 0) return false;", "if (index < 0) { Changed?.Invoke(); return false; }"),
    "m5_changed_on_empty_clear": ("if (picks.Count == 0) return;", "if (picks.Count == 0) { Changed?.Invoke(); return; }"),
    "m6_no_changed_on_add": ("            picks.Add(mod);\n            Changed?.Invoke();", "            picks.Add(mod);"),
    "m7_never_counts": ("counts[mod] > 1 ?", "counts[mod] > 99 ?"),
    "m8_line_per_pick": ("                if (counts.TryGetValue(mod, out var n)) counts[mod] = n + 1;\n                else\n",
                         "                if (counts.TryGetValue(mod, out var n)) { counts[mod] = n + 1; order.Add(mod); }\n                else\n"),
    "m9_changed_before_add": ("            picks.Add(mod);\n            Changed?.Invoke();", "            Changed?.Invoke();\n            picks.Add(mod);"),
}

REFERENCE_TESTS = '''using System;
using System.Collections.Generic;
using Combat.Weapons.Mods;

namespace Checks
{
    public static class WeaponModStackTests
    {
        private static readonly WeaponMod A = Mods.Make("a", WeaponModField.Damage, 0.1f);
        private static readonly WeaponMod B = Mods.Make("b", WeaponModField.Cooling, 0.25f);

        private static WeaponModStack Stack(params WeaponMod[] mods)
        {
            var s = new WeaponModStack();
            foreach (var m in mods) s.Add(m);
            return s;
        }

        public static void RemoveTakesMostRecentPick()
        {
            var s = Stack(A, B, A);
            Check.True(s.Remove(A), "removed");
            Check.Sequence(new[] { A, B }, s.Picks, "picks");
        }

        public static void RemoveReportsAbsence()
        {
            var s = Stack(A);
            Check.False(s.Remove(B), "never picked");
            Check.True(s.Remove(A), "picked");
            Check.False(s.Remove(A), "already removed");
        }

        public static void RemoveNullThrows() => Check.Throws<ArgumentNullException>(() => Stack().Remove(null), "null");

        public static void ChangedFiresAfterRealChangesOnly()
        {
            var s = new WeaponModStack();
            var counts = new List<int>();
            s.Changed += () => counts.Add(s.Picks.Count);
            s.Clear();
            s.Add(A);
            s.Remove(B);
            s.Remove(A);
            s.Add(A);
            s.Clear();
            Check.Sequence(new[] { 1, 0, 1, 0 }, counts, "changed");
        }

        public static void SummaryCountsAndOrders()
        {
            var s = Stack(A, B, A);
            Check.Sequence(new[] { "a: +10% damage x2", "b: +25% cooling" }, s.Summary(), "summary");
            s.Remove(A);
            s.Remove(A);
            s.Add(A);
            Check.Sequence(new[] { "b: +25% cooling", "a: +10% damage" }, s.Summary(), "after removals");
            Check.Equal(0, Stack().Summary().Count, "empty");
        }
    }
}
'''


def reference(ws):
    (ws / STACK).write_text(REFERENCE_STACK, encoding="utf-8")
    p = ws / FIELD
    t = p.read_text(encoding="utf-8")
    assert PARSE_ANCHOR in t
    p.write_text(t.replace(PARSE_ANCHOR, PARSE + PARSE_ANCHOR), encoding="utf-8")
    (ws / TESTS).write_text(REFERENCE_TESTS, encoding="utf-8")
    return "DONE", f"{STACK}, {FIELD}, {TESTS}", "none"


def check(ctx):
    linq = [p.relative_to(ctx["ws"]).as_posix() for p in (ctx["ws"] / "src").rglob("*.cs")
            if re.search(r"System\.Linq", p.read_text(encoding="utf-8", errors="replace"))]
    out = {"ok_no_linq_in_src": not linq, "linq_files": linq}
    if not (ctx["ws"] / TESTS).exists():
        return dict(out, ok_tests_kill_mutants=False, killed=0, mutants=len(MUTANTS))

    def against(stack_text, name):
        mdir = ctx["verify"].parent / f"m8_{name}"
        if mdir.exists():
            shutil.rmtree(mdir)
        ctx["copy_tree"](ctx["verify"], mdir)
        (mdir / STACK).write_text(stack_text, encoding="utf-8")
        res = ctx["run_tests"]("tests/Checks", mdir, "WeaponModStackTests")
        shutil.rmtree(mdir, ignore_errors=True)
        return res

    clean = against(REFERENCE_STACK, "clean")
    if not (clean["built"] and clean["failed"] == 0 and clean["passed"] > 0):
        return dict(out, ok_tests_kill_mutants=False, killed=0, mutants=len(MUTANTS),
                    note="worker tests do not pass against the reference stack", clean=clean)
    survivors = []
    for name, (old, new) in MUTANTS.items():
        assert old in REFERENCE_STACK, name
        res = against(REFERENCE_STACK.replace(old, new, 1), name)
        if res["built"] and res["failed"] == 0:
            survivors.append(name)
    return dict(out, ok_tests_kill_mutants=not survivors, killed=len(MUTANTS) - len(survivors),
                mutants=len(MUTANTS), survivors=survivors)
