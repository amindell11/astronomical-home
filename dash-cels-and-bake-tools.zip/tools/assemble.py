"""Cut the dash flipbook sheets from hand-drawn cels, on the tuner's timing.

usage: assemble.py <cels_dir> <frames.json> <settings.json> <out_dir>
Sheets keep the layout of the vector bake: same cells, frame counts and anchors.
"""
import json
import os
import sys

import cv2
import numpy as np

cels_dir, frames_path, settings_path, out_dir = sys.argv[1:5]
S = json.load(open(settings_path, encoding="utf-8"))
REC = json.load(open(frames_path, encoding="utf-8"))
PPU, SS, STEP = 96.0, 3, 1000.0 / 60.0
GUARD_MS, POP_MS = 400.0, 83.0
NAVY = np.array([0x26, 0x16, 0x0d], np.float32)          # BGR


def bgr(h):
    h = h.lstrip("#")
    return np.array([int(h[4:6], 16), int(h[2:4], 16), int(h[0:2], 16)], np.float32) / 255.0


SMEAR_PAL = [bgr(S["cCore"]), bgr(S["cMid"]), bgr(S["cRim"])]
FLARE_PAL = [bgr(S["cCore"]), bgr(S["cFlareMid"]), bgr(S["cFlareRim"])]
DRAWN = [np.array([255, 255, 255], np.float32), np.array([255, 240, 143], np.float32), np.array([255, 109, 31], np.float32)]


def load_cel(name, cell_w, cell_h, pad, palette):
    """Key the navy out, snap the drawing to three flat colours, return premultiplied RGBA at SS x cell size."""
    im = cv2.imread(os.path.join(cels_dir, name), cv2.IMREAD_COLOR).astype(np.float32)
    im = cv2.resize(im, ((cell_w + 2 * pad) * SS, (cell_h + 2 * pad) * SS), interpolation=cv2.INTER_AREA)
    im = im[pad * SS:-pad * SS, pad * SS:-pad * SS]
    bg = np.median(np.concatenate([im[:6].reshape(-1, 3), im[-6:].reshape(-1, 3)]), axis=0)
    solid = (np.linalg.norm(im - bg, axis=2) > 55).astype(np.uint8)
    solid = cv2.morphologyEx(solid, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    dist = np.stack([np.linalg.norm(im - c, axis=2) for c in DRAWN], axis=2)
    label = cv2.medianBlur(np.argmin(dist, axis=2).astype(np.uint8), 5)
    out = np.zeros(im.shape[:2] + (4,), np.float32)
    for i, c in enumerate(palette):
        out[(label == i) & (solid > 0), :3] = c
    out[..., 3] = solid
    out[..., :3] *= out[..., 3:]
    return out


def warp(img, ax, ay, sx, sy):
    """Scale about the anchor (ax, ay), in SS pixels: sx across the ship, sy along it."""
    m = np.float32([[sx, 0, ax * (1 - sx)], [0, sy, ay * (1 - sy)]])
    return cv2.warpAffine(img, m, (img.shape[1], img.shape[0]), flags=cv2.INTER_LINEAR)


def glow(img, color, alpha, blur_ship_px, sx=1.0, sy=1.0, ax=0, ay=0):
    """Additive blurred silhouette, as the tuner draws it: colour with no alpha."""
    sil = img[..., 3]
    if sx != 1.0 or sy != 1.0:
        sil = warp(sil, ax, ay, sx, sy)
    sil = cv2.GaussianBlur(sil, (0, 0), blur_ship_px / 70.0 * PPU * SS)
    out = np.zeros_like(img)
    out[..., :3] = sil[..., None] * color * alpha
    return out


def over_(top, bottom):
    return top + bottom * (1 - top[..., 3:])


def down(img, w, h):
    return np.clip(cv2.resize(img, (w, h), interpolation=cv2.INTER_AREA) * 255.0 + 0.5, 0, 255).astype(np.uint8)


def ease_out(u):
    u = min(1.0, max(0.0, u))
    return 1 - (1 - u) * (1 - u)


def ease_in_out(u):
    u = min(1.0, max(0.0, u))
    return u * u * (3 - 2 * u)


def fade_out(u):
    u = min(1.0, max(0.0, u))
    return 1 - u ** S["fadeCurve"]


def guard_amount(ms):
    if ms < GUARD_MS:
        return 1.0 if S["swellMs"] <= 0 else min(1.0, ms / S["swellMs"])
    return fade_out((ms - GUARD_MS) / S["cutMs"]) if S["cutMs"] > 0 else 0.0


def smear_scale(ms):
    """(scale along, alpha) of the smear at ms, or None once it has gone."""
    hold, rem, fade = S["holdMs"], S["remnantMs"], S["fadeMs"]
    if ms < hold:
        return (0.25 + 0.75 * ease_out(ms / S["growMs"]) if ms < S["growMs"] else 1.0), 1.0
    if ms < hold + rem:
        return 1 + (S["remnantScale"] - 1) * ease_in_out((ms - hold) / max(1.0, rem)), 1.0
    if ms < hold + rem + fade:
        a = fade_out((ms - hold - rem) / fade)
        return S["remnantScale"] * (0.6 + 0.4 * a), a
    return None


def side(sc):
    return 0.45 + 0.55 * sc


def sheet(cells, cols, cell_w, cell_h):
    rows = (len(cells) + cols - 1) // cols
    out = np.zeros((rows * cell_h, cols * cell_w, 4), np.uint8)
    for i, c in enumerate(cells):
        r, k = divmod(i, cols)
        out[r * cell_h:(r + 1) * cell_h, k * cell_w:(k + 1) * cell_w] = c
    return out


def flare_size(frame):
    xs = [p[0] for p in frame[0]["pts"]]
    ys = [p[1] for p in frame[0]["pts"]]
    return max(xs) - min(xs), max(ys) - min(ys)


os.makedirs(out_dir, exist_ok=True)
N = 36

# ---- flares (under the hull) -------------------------------------------------------------------
UW, UH = 64, 164
flares = [load_cel("flares_%d.png" % i, UW, UH, 12, FLARE_PAL) for i in (1, 2, 3)]
ref_len, ref_wid = flare_size(REC["under"][8])
outlet_y = (0.30 - 0.270) * PPU * SS
half = UW * SS // 2
under_ss = []
for i in range(N):
    ln, wd = flare_size(REC["under"][i])
    cel = flares[(i // 2) % 3]
    out = np.zeros_like(cel)
    for x0 in (0, half):
        part = cel[:, x0:x0 + half]
        out[:, x0:x0 + half] = warp(part, half / 2.0, outlet_y, wd / ref_wid, ln / ref_len)
    under_ss.append(out)
cv2.imwrite(os.path.join(out_dir, "under.png"), sheet([down(u, UW, UH) for u in under_ss], 32, UW, UH))

# ---- smear and flare glow (over the hull) ------------------------------------------------------
OW, OH = 147, 521
full = [load_cel("smear_full_%d.png" % i, OW, OH, 20, SMEAR_PAL) for i in (1, 2, 3)]
grow = load_cel("smear_grow_1.png", OW, OH, 20, SMEAR_PAL)
rem = [load_cel("smear_remnant_%d.png" % i, OW, OH, 20, SMEAR_PAL) for i in (1, 2)]
nose_x, nose_y = OW * SS / 2.0, (0.787 - 0.5) * PPU * SS
grow_ref = smear_scale(1 * STEP + 0.5)[0]
rem_ref = S["remnantScale"]
under_top = int(round((0.270 + 0.787) * PPU * SS))
under_left = (OW - UW) * SS // 2
over_cells = []
for i in range(N):
    ms = i * STEP + 0.5
    cell = np.zeros((OH * SS, OW * SS, 4), np.float32)
    amt = guard_amount(ms)
    fl = np.zeros_like(cell)
    h = min(UH * SS, OH * SS - under_top)
    fl[under_top:under_top + h, under_left:under_left + UW * SS] = under_ss[i][:h]
    cell += glow(fl, FLARE_PAL[2], S["flareGlow"] * (0.3 + 0.7 * amt), 5)
    st = smear_scale(ms)
    if st:
        sc, a = st
        if ms < S["growMs"]:
            src, ref = grow, grow_ref
        elif ms < S["holdMs"] + S["remnantMs"] * 0.45:
            src, ref = full[(i // 2) % 3], 1.0
        else:
            src, ref = rem[0 if ms < S["holdMs"] + S["remnantMs"] + 60 else 1], rem_ref
        drawn = warp(src, nose_x, nose_y, side(sc) / side(ref), sc / ref)
        g = glow(drawn, SMEAR_PAL[2], S["smearGlow"] * 0.7 * a, 6)
        cell = over_(drawn * a, cell + g)
    over_cells.append(down(cell, OW, OH))
cv2.imwrite(os.path.join(out_dir, "over.png"), sheet(over_cells, 13, OW, OH))

# ---- launch burst ------------------------------------------------------------------------------
BW, BH = 222, 153
star = load_cel("burst_star_1.png", BW, BH, 12, SMEAR_PAL)
spikes = load_cel("burst_spikes_1.png", BW, BH, 12, SMEAR_PAL)
bx, by = BW * SS / 2.0, (0.797 - 0.4223) * PPU * SS


def pop_grow(ms):
    return 0.6 + 1.0 * ease_out(ms / POP_MS)


burst_cells = []
for i in range(5):
    ms = i * STEP + 0.5
    if ms < 33:
        k = pop_grow(ms) / pop_grow(1 * STEP + 0.5)
        d = warp(star, bx, by, k, k)
        cell = over_(d, glow(d, SMEAR_PAL[2], S["smearGlow"] * 0.7, 6))
    else:
        k = pop_grow(ms) / pop_grow(2 * STEP + 0.5)
        cell = warp(spikes, bx, by, k, k) * fade_out((ms - POP_MS * 0.4) / (POP_MS * 0.6))
    burst_cells.append(down(cell, BW, BH))
cv2.imwrite(os.path.join(out_dir, "burst.png"), sheet(burst_cells, 5, BW, BH))
print("wrote sheets to", out_dir)
