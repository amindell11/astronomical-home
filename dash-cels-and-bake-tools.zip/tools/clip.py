"""Real-speed clip of the baked dash over a game frame, ship at 70 px.

usage: clip.py <sheets_dir> <sprite0.png> <game_frame.png> <out.mp4> [compare_sheets_dir]
Plays three dashes at full speed, then one at quarter speed. With a second sheets dir, shows it on top for comparison.
"""
import math
import sys

import cv2
import numpy as np

sheets_dir, sprite_src, frame_src, out = sys.argv[1:5]
other = sys.argv[5] if len(sys.argv) > 5 else None
PPU, SHIP = 96.0, 70
K = SHIP / PPU
HEADING = -0.30
CRUISE, KICK, DECAY = 170.0, 620.0, 0.22
GUARD_MS, CUT_MS, CURVE = 400.0, 198.0, 0.8
LAYOUT = {"over": (147, 521, 13, 36, 0.787), "under": (64, 164, 32, 36, -0.270), "burst": (222, 153, 5, 5, 0.375)}


def sprite():
    im = cv2.imread(sprite_src, cv2.IMREAD_COLOR)
    h, w = im.shape[:2]
    mask = np.zeros((h + 2, w + 2), np.uint8)
    filled = im.copy()
    for seed in [(0, 0), (w - 1, 0), (0, h - 1), (w - 1, h - 1), (w // 2, 0), (w // 2, h - 1), (0, h // 2), (w - 1, h // 2)]:
        cv2.floodFill(filled, mask, seed, (255, 0, 255), (14, 14, 14), (14, 14, 14), cv2.FLOODFILL_FIXED_RANGE)
    alpha = np.where(mask[1:-1, 1:-1] > 0, 0, 255).astype(np.uint8)
    ys, xs = np.where(alpha > 0)
    rgba = np.dstack([im, alpha])[ys.min():ys.max() + 1, xs.min():xs.max() + 1].astype(np.float32) / 255.0
    rgba[..., :3] *= rgba[..., 3:]
    s = SHIP / rgba.shape[0]
    return cv2.resize(rgba, (round(rgba.shape[1] * s), SHIP), interpolation=cv2.INTER_AREA)


def cells(d, name):
    w, h, cols, n, ahead = LAYOUT[name]
    s = cv2.imread(d + "/" + name + ".png", cv2.IMREAD_UNCHANGED).astype(np.float32) / 255.0
    return [s[(i // cols) * h:(i // cols + 1) * h, (i % cols) * w:(i % cols + 1) * w] for i in range(n)], ahead


def place(frame, img, x, y, ahead_px, scale):
    """Draw a nose-up premultiplied image with its ship-centre row at (x, y), turned to the heading."""
    h, w = img.shape[:2]
    c, s = math.cos(HEADING + math.pi / 2) * scale, math.sin(HEADING + math.pi / 2) * scale
    m = np.float32([[c, -s, x - c * (w / 2.0) + s * ahead_px], [s, c, y - s * (w / 2.0) - c * ahead_px]])
    layer = cv2.warpAffine(img, m, (frame.shape[1], frame.shape[0]), flags=cv2.INTER_AREA if scale < 1 else cv2.INTER_LINEAR)
    frame[:] = layer[..., :3] + frame * (1 - layer[..., 3:])


def travelled(ms):
    u = ms / 1000.0
    return CRUISE * u + (KICK * DECAY * (1 - math.exp(-u / DECAY)) if ms > 0 else 0)


def draw(frame, sheets, x0, y0, ms):
    d = CRUISE * 0.45 + (travelled(ms) if ms >= 0 else CRUISE * ms / 1000.0)
    x, y = x0 + math.cos(HEADING) * d, y0 + math.sin(HEADING) * d
    lx, ly = x0 + math.cos(HEADING) * CRUISE * 0.45, y0 + math.sin(HEADING) * CRUISE * 0.45
    i = int(ms // (1000.0 / 60.0)) if ms >= 0 else -1
    (over, oa), (under, ua), (burst, ba) = sheets
    if 0 <= i < len(burst):
        place(frame, burst[i], lx, ly, ba * PPU, K)
    if 0 <= i < len(under):
        place(frame, under[i], x, y, ua * PPU, K)
    hull = SPRITE.copy()
    if ms >= 0:
        white = 1.0 if ms < GUARD_MS else max(0.0, 1 - min(1.0, (ms - GUARD_MS) / CUT_MS) ** CURVE)
        hull[..., :3] = hull[..., :3] * (1 - white) + hull[..., 3:] * white
    place(frame, hull, x, y, SHIP / 2.0, 1.0)
    if 0 <= i < len(over):
        place(frame, over[i], x, y, oa * PPU, K)


SPRITE = sprite()
bg = cv2.imread(frame_src, cv2.IMREAD_COLOR)[630:1080, 480:1440].astype(np.float32) / 255.0
sets = [[cells(sheets_dir, n) for n in ("over", "under", "burst")]]
if other:
    sets.insert(0, [cells(other, n) for n in ("over", "under", "burst")])
H = bg.shape[0] if len(sets) == 1 else bg.shape[0]
vw = cv2.VideoWriter(out, cv2.VideoWriter_fourcc(*"mp4v"), 60, (bg.shape[1], bg.shape[0]))
labels = ["vector bake", "hand-drawn cels"] if other else [""]
for speed, repeats in ((1.0, 3), (0.25, 1)):
    for _ in range(repeats):
        t = -450.0
        while t < 1400.0:
            f = bg.copy()
            for k, sheets in enumerate(sets):
                y0 = 330 if len(sets) == 1 else (200 if k == 0 else 400)
                draw(f, sheets, 90, y0, t)
                if labels[k]:
                    cv2.putText(f, labels[k], (14, y0 - 150 if k else 26), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0.42, 0.9, 1.0), 1, cv2.LINE_AA)
            if speed < 1:
                cv2.putText(f, "quarter speed", (bg.shape[1] - 130, 26), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0.42, 0.9, 1.0), 1, cv2.LINE_AA)
            vw.write(np.clip(f * 255, 0, 255).astype(np.uint8))
            t += 1000.0 / 60.0 * speed
vw.release()
print("wrote", out)
