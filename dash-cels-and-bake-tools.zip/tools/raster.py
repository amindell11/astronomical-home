"""Rasterise recorded tuner frames into flipbook sheets.

usage: raster.py <frames.json> <out_dir> [pixels_per_ship_length]
Each sheet is premultiplied RGBA with the nose pointing up: columns run across the ship, rows run backward.
Frames read left to right, top to bottom. sheets.json gives each cell's rectangle in ship lengths.
"""
import json
import math
import os
import sys

import cv2
import numpy as np

src, out_dir = sys.argv[1], sys.argv[2]
PPU = float(sys.argv[3]) if len(sys.argv) > 3 else 96.0
SS = 3
MAX_SIDE = 2048

data = json.load(open(src, encoding="utf-8"))


def rgb(hex_color):
    h = hex_color.lstrip("#")
    return np.array([int(h[i:i + 2], 16) / 255.0 for i in (0, 2, 4)], np.float32)


def bounds(frames):
    back0 = back1 = side = None
    for frame in frames:
        for p in frame:
            pad = 3 * p["blur"] + 0.03
            for x, y in p["pts"]:
                back0 = x - pad if back0 is None else min(back0, x - pad)
                back1 = x + pad if back1 is None else max(back1, x + pad)
                side = abs(y) + pad if side is None else max(side, abs(y) + pad)
    return back0, back1, side


def render(frame, back0, cell_w, cell_h, side):
    w, h = cell_w * SS, cell_h * SS
    scale = PPU * SS
    color = np.zeros((h, w, 3), np.float32)
    alpha = np.zeros((h, w), np.float32)
    for p in frame:
        # A point y to the ship's left lands left of the centre column; x backward runs down the rows.
        pts = np.array([[(side - y) * scale, (x - back0) * scale] for x, y in p["pts"]], np.float32)
        mask = np.zeros((h, w), np.uint8)
        cv2.fillPoly(mask, [np.round(pts * 16).astype(np.int32)], 255, lineType=cv2.LINE_AA, shift=4)
        cover = mask.astype(np.float32) / 255.0
        if p["blur"] > 0:
            cover = cv2.GaussianBlur(cover, (0, 0), p["blur"] * scale)
        cover *= p["alpha"]
        c = rgb(p["color"])
        if p["add"]:
            color += cover[..., None] * c
        else:
            color = cover[..., None] * c + color * (1 - cover[..., None])
            alpha = cover + alpha * (1 - cover)
    out = np.dstack([color[..., ::-1], alpha])
    out = cv2.resize(out, (cell_w, cell_h), interpolation=cv2.INTER_AREA)
    return np.clip(out * 255.0 + 0.5, 0, 255).astype(np.uint8)


meta = {"fps": data["fps"], "guardMs": data["guardMs"], "cutMs": data["cutMs"], "fadeCurve": data["fadeCurve"],
        "units": "ship lengths, measured from the ship centre (burst: from the launch point)", "sheets": {}}
os.makedirs(out_dir, exist_ok=True)
for name in ("under", "over", "burst"):
    frames = data[name]
    back0, back1, side = bounds(frames)
    cell_w, cell_h = math.ceil(2 * side * PPU), math.ceil((back1 - back0) * PPU)
    n = len(frames)
    cols = min(n, MAX_SIDE // cell_w)
    rows = math.ceil(n / cols)
    assert rows * cell_h <= MAX_SIDE, (name, cols, rows, cell_w, cell_h)
    sheet = np.zeros((rows * cell_h, cols * cell_w, 4), np.uint8)
    for i, frame in enumerate(frames):
        r, c = divmod(i, cols)
        sheet[r * cell_h:(r + 1) * cell_h, c * cell_w:(c + 1) * cell_w] = render(frame, back0, cell_w, cell_h, side)
    cv2.imwrite(os.path.join(out_dir, name + ".png"), sheet)
    meta["sheets"][name] = {"frames": n, "columns": cols, "rows": rows, "cellPx": [cell_w, cell_h],
                            "width": round(cell_w / PPU, 4), "length": round(cell_h / PPU, 4),
                            "centreAhead": round(-(back0 + cell_h / PPU / 2), 4)}
    print(name, sheet.shape, meta["sheets"][name])
json.dump(meta, open(os.path.join(out_dir, "sheets.json"), "w", encoding="utf-8"), indent=1)
