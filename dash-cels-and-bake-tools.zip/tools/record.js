// Runs the tuner's own draw code against a recording canvas context and writes every filled
// polygon per frame, in ship lengths. usage: node record.js <template.html> <settings.json> <out.json>
'use strict';
var fs = require('fs');
var html = fs.readFileSync(process.argv[2], 'utf8');
var settings = JSON.parse(fs.readFileSync(process.argv[3], 'utf8'));
var m = /<script>\s*\(function \(\) \{([\s\S]*)\}\)\(\);?\s*<\/script>/.exec(html);
if (!m) throw new Error('tuner script not found');
var body = m[1].replace('__SPRITE_W__', '0.643').replace('__SPRITE_H__', '1');
body = body.slice(0, body.indexOf('  function shipPos('));

function Recorder() {
  this.m = [1, 0, 0, 1, 0, 0];
  this.stack = [];
  this.globalAlpha = 1; this.globalCompositeOperation = 'source-over'; this.filter = 'none'; this.fillStyle = '#000';
  this.path = []; this.out = []; this.images = 0;
}
Recorder.prototype = {
  save: function () { this.stack.push([this.m.slice(), this.globalAlpha, this.globalCompositeOperation, this.filter]); },
  restore: function () { var s = this.stack.pop(); this.m = s[0]; this.globalAlpha = s[1]; this.globalCompositeOperation = s[2]; this.filter = s[3]; },
  translate: function (x, y) { var m = this.m; m[4] += m[0] * x + m[2] * y; m[5] += m[1] * x + m[3] * y; },
  rotate: function (a) { var m = this.m, c = Math.cos(a), s = Math.sin(a); this.m = [m[0] * c + m[2] * s, m[1] * c + m[3] * s, -m[0] * s + m[2] * c, -m[1] * s + m[3] * c, m[4], m[5]]; },
  pt: function (x, y) { var m = this.m; return [m[0] * x + m[2] * y + m[4], m[1] * x + m[3] * y + m[5]]; },
  beginPath: function () { this.path = []; },
  moveTo: function (x, y) { this.path.push(this.pt(x, y)); },
  lineTo: function (x, y) { this.path.push(this.pt(x, y)); },
  closePath: function () {},
  fill: function () {
    var blur = /blur\(([\d.]+)px\)/.exec(this.filter);
    this.out.push({ pts: this.path.map(function (p) { return [+p[0].toFixed(4), +p[1].toFixed(4)]; }), color: this.fillStyle,
      alpha: +this.globalAlpha.toFixed(4), add: this.globalCompositeOperation === 'lighter',
      blur: blur ? +blur[1] / 70 : 0, overHull: this.images > 0 });
  },
  drawImage: function () { this.images++; },
  clearRect: function () {}, fillRect: function () {}
};

var stubEl = { getContext: function () { return new Recorder(); }, width: 0, height: 0, addEventListener: function () {}, appendChild: function () {},
  style: {}, classList: { toggle: function () {}, add: function () {}, remove: function () {} } };
var doc = { getElementById: function () { return stubEl; }, createElement: function () { return Object.create(stubEl); }, querySelectorAll: function () { return []; } };
function Img() {}
var api = new Function('document', 'Image', 'localStorage', 'requestAnimationFrame', 'navigator', 'SETTINGS',
  body + '\n;for (var k in SETTINGS) S[k] = SETTINGS[k]; HEADING = Math.PI; ghostCanvas = document.createElement("canvas");' +
  '\nreturn { drawShip: drawShip, drawExtras: drawExtras, GUARD_MS: GUARD_MS, POP_MS: POP_MS, S: S };')(
  doc, Img, { getItem: function () { return null; }, setItem: function () {} }, function () {}, {}, settings);

var S = api.S, FPS = 60, step = 1000 / FPS;
var shipEnd = Math.max(S.holdMs + S.remnantMs + S.fadeMs, api.GUARD_MS + S.cutMs);
var shipFrames = Math.ceil(shipEnd / step), popFrames = Math.ceil(api.POP_MS / step);
var under = [], over = [], pop = [], i, r;
for (i = 0; i < shipFrames; i++) {
  r = new Recorder(); api.drawShip(r, 0, 0, i * step + 0.5);
  under.push(r.out.filter(function (p) { return !p.overHull; }));
  over.push(r.out.filter(function (p) { return p.overHull; }));
}
for (i = 0; i < popFrames; i++) { r = new Recorder(); api.drawExtras(r, 0, 0, i * step + 0.5); pop.push(r.out); }
fs.writeFileSync(process.argv[4], JSON.stringify({ fps: FPS, guardMs: api.GUARD_MS, cutMs: S.cutMs, fadeCurve: S.fadeCurve,
  units: 'ship lengths; +x backward from the ship centre (burst: from the launch point), +y sideways', under: under, over: over, burst: pop }));
console.log('frames', shipFrames, popFrames, 'polys', under[3].length, over[3].length, pop[0].length);
