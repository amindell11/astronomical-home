const fs=require('fs'),path=require('path'),assert=require('assert');
const checks=[];
for(const name of fs.readdirSync(path.join(__dirname,'svg'))){
 const source=fs.readFileSync(path.join(__dirname,'svg',name),'utf8');
 assert(source.includes('viewBox="0 0 64 64"'));
 assert.equal((source.match(/<path /g)||[]).length,1);
 assert(!/<(?:image|filter|script|text|mask)|\b(?:stroke|transform|opacity)=/.test(source));
 const d=source.match(/ d="([^"]+)"/)[1];
 const polys=d.split(' Z').filter(x=>x.trim()).map(x=>x.match(/-?\d+(?:\.\d+)?/g).map(Number)).map(a=>Array.from({length:a.length/2},(_,i)=>a.slice(i*2,i*2+2)));
 const points=polys.flat();
 assert(points.every(([x,y])=>x>=0&&y>=0&&x<=64&&y<=64));
 const rotating=['ram.svg','overdrive.svg'].includes(name);
 const opposite=rotating?([x,y])=>[64-x,64-y]:([x,y])=>[64-x,y];
 if(name!=='blink.svg') assert(points.every(p=>points.some(q=>q.every((v,i)=>Math.abs(v-opposite(p)[i])<.00003))));
 else { assert.equal(polys.length,2); assert.equal(polys[0].length,4); assert.equal(polys[1].length,8); }
 let area=0;
 for(const p of polys){
   const a=Math.abs(p.reduce((s,v,i)=>s+v[0]*p[(i+1)%p.length][1]-v[1]*p[(i+1)%p.length][0],0)/2);
   assert(a>0);area+=a;
   for(let i=0;i<p.length;i++){
     const a=p[i],b=p[(i+1)%p.length],angle=Math.atan2(Math.abs(b[1]-a[1]),Math.abs(b[0]-a[0]))*180/Math.PI;
     assert([0,40,90].some(v=>Math.abs(angle-v)<.001),name+' unexpected edge angle '+angle);
   }
 }
 checks.push({file:name,closedPieces:polys.length,symmetry:name==='blink.svg'?'Directional body and open echo':rotating?'180-degree rotation':'vertical mirror',boundsWithin64:true,angles:'0, 40, 90 degrees',area:+area.toFixed(2)});
}
assert.equal(checks.length,6);
for(const name of ['guard-dash.svg','stealth.svg','dash.svg']) assert.equal(fs.readFileSync(path.join(__dirname,'svg',name),'utf8'),fs.readFileSync(path.join(__dirname,'reference-anchors',name),'utf8'));
fs.writeFileSync(path.join(__dirname,'svg-checks.json'),JSON.stringify({passed:true,checks},null,2));
console.log(JSON.stringify({passed:true,checks}));
