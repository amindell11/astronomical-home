const fs = require('fs'), path = require('path');
const root = __dirname, angle = 40, t = Math.tan(angle*Math.PI/180);
const weight = 5.2, dy = weight/Math.cos(angle*Math.PI/180);
const diamond = (x,y,r) => [[x,y-r*t],[x+r,y],[x,y+r*t],[x-r,y]];
const chevron = (r,y) => [[-r,y+r*t],[0,y],[r,y+r*t],[r,y+r*t+dy],[0,y+dy],[-r,y+r*t+dy]];
const mirrorY = p => p.map(([x,y])=>[x,-y]);
const band = weight/Math.sin(angle*Math.PI/180);
const motion = p => p.map(([u,v])=>[u*Math.cos(angle*Math.PI/180)+v*Math.sin(angle*Math.PI/180),-u*Math.sin(angle*Math.PI/180)+v*Math.cos(angle*Math.PI/180)]);
const streak=(a,b,v,w=weight)=>[[a,v-w/2],[b,v-w/2],[b,v+w/2],[a,v+w/2]];
const stealth = [[-18/t,-4],[0,-22],[18/t,-4],[(18-dy)/t,-4],[0,-22+dy],[-(18-dy)/t,-4]];
const glyphs = [
 {id:'guard-dash',name:'Guard Dash',ship:'Vanguard',idea:'Protected movement',polys:[
   [[-23,5],[-23,-6],[0,-6-23*t],[23,-6],[23,5],[23-weight,5],[23-weight,-6+(dy-weight*t)],[0,-6-23*t+dy],[-23+weight,-6+(dy-weight*t)],[-23+weight,5]],
   diamond(0,9,12)]},
 {id:'ram',name:'Ram',ship:'Bulwark',idea:'Charge into contact',polys:[diamond(3,-3*t,16),motion(streak(-30,-15,-7)),motion(streak(-30,-15,7)),motion([[25,-11],[30,-11],[30,11],[25,11]])]},
 {id:'overdrive',name:'Overdrive',ship:'Valis',idea:'Long, sustained speed',polys:[motion([[-23,0],[-12,-6],[28,0],[-12,6]]),motion([[-25,-15],[-3,-10],[-3,-6],[-25,-10]]),motion([[-25,15],[-3,10],[-3,6],[-25,10]])]},
 {id:'blink',name:'Blink',ship:'Crimson',idea:'Vanish here, appear there',polys:[
   [[-19,-11*t],[-30,0],[-19,11*t],[-19,(11-band)*t],[-30+band,0],[-19,-(11-band)*t]],
   [[-6,-22],[3,-22+9*t],[3,22-9*t],[-6,22],[-15,22-9*t],[-15,-22+9*t]],
   [[-6,-14],[-10,-14+4*t],[-10,14-4*t],[-6,14],[-2,14-4*t],[-2,-14+4*t]],diamond(17,0,12)]},
 {id:'stealth',name:'Stealth',ship:'Nightshade',idea:'A concealed center',polys:[stealth,mirrorY(stealth)]},
 {id:'dash',name:'Dash',ship:'Junker',idea:'Basic movement',polys:[chevron(23,-13)]}
];
const n = v => +v.toFixed(5);
for (const g of glyphs) {
 const points=g.polys.flat(), ymin=Math.min(...points.map(p=>p[1])), ymax=Math.max(...points.map(p=>p[1]));
 const yc=(ymin+ymax)/2, xc=(Math.min(...points.map(p=>p[0]))+Math.max(...points.map(p=>p[0])))/2;
 g.polys=g.polys.map(p=>p.map(([x,y])=>[n(x-xc+32),n(y-yc+32)]));
 g.d=g.polys.map(p=>'M '+p.map(q=>q.join(' ')).join(' L ')+' Z').join(' ');
 const pts=g.polys.flat();g.bounds=[Math.min(...pts.map(p=>p[0])),Math.min(...pts.map(p=>p[1])),Math.max(...pts.map(p=>p[0])),Math.max(...pts.map(p=>p[1]))];
}
fs.mkdirSync(path.join(root,'svg'),{recursive:true});
for(const g of glyphs) fs.writeFileSync(path.join(root,'svg',g.id+'.svg'),`<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><path fill="#ffffff" d="${g.d}"/></svg>\n`);
const weaponsDir=path.join(root,'reference-weapons');
const weaponIds=['lasers','turbo-lasers','charge-lasers','railgun','missiles','rippers','concussion'];
const weapons=Object.fromEntries(weaponIds.map(id=>[id,{d:fs.readFileSync(path.join(weaponsDir,id+'.svg'),'utf8').match(/ d="([^"]+)"/)[1]}]));
const ink='#f3f2df', muted='#9caeba', bg='#0a1320';
const icon=(g,cx,cy,s=96)=>`<svg x="${cx-s/2}" y="${cy-s/2}" width="${s}" height="${s}" viewBox="0 0 64 64"><path fill="${ink}" d="${g.d}"/></svg>`;
const text=(x,y,s,size=14,color=muted,anchor='start')=>`<text x="${x}" y="${y}" font-family="Arial, sans-serif" font-size="${size}" fill="${color}" text-anchor="${anchor}">${s}</text>`;
const line=(y)=>`<path d="M 48 ${y} H 1452" stroke="#283746" stroke-width="1"/>`;
const ring=(cx,cy,r=39)=>`<circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${ink}" stroke-width="1.15"/>`;
const instrument=(g,cx,cy)=>ring(cx,cy)+icon(g,cx,cy,40)+icon(weapons.lasers,cx-122,cy,34)+icon(weapons.missiles,cx+122,cy,34)+`<path d="M ${cx-141.5} ${cy-33.8} A 39 39 0 0 0 ${cx-141.5} ${cy+33.8} M ${cx+141.5} ${cy-33.8} A 39 39 0 0 1 ${cx+141.5} ${cy+33.8}" fill="none" stroke="${ink}" stroke-width="1.15"/>`;
let board=`<svg xmlns="http://www.w3.org/2000/svg" width="1500" height="1060" viewBox="0 0 1500 1060"><rect width="1500" height="1060" fill="${bg}"/>`;
board+=text(48,48,'Keystones / movement and function',27,ink)+text(48,78,'Third pass / impact, speed and teleportation / Guard Dash and Stealth retained',14);
const centers=[180,465,750,1035,1320];
glyphs.slice(0,5).forEach((g,i)=>{const x=centers[i];board+=text(x,132,g.ship.toUpperCase(),12,muted,'middle')+icon(g,x,220,132)+text(x,325,g.name,21,ink,'middle')+text(x,352,g.idea,14,muted,'middle');});
board+=line(390)+text(48,423,'With the weapon instruments',16,ink)+text(48,447,'Neutral vector layout. Rings are separate from the glyphs; this is not an in-game capture.',13);
glyphs.slice(0,5).forEach((g,i)=>{const x=centers[i];board+=`<g transform="translate(${x} 516) scale(.75)">${instrument(g,0,0)}</g>`;});
board+=line(583)+text(48,618,'Small-size checks',16,ink);
[16,24,32,48].forEach((s,i)=>{const y=[648,690,736,793][i];board+=text(48,y+5,s+' px',13);glyphs.slice(0,5).forEach((g,j)=>board+=icon(g,centers[j],y,s));});
board+=line(828)+text(48,865,'Approved weapon family',16,ink);
weaponIds.forEach((id,i)=>{board+=icon(weapons[id],94+i*148,925,54)+text(94+i*148,981,id.replaceAll('-',' '),12,muted,'middle');});
board+=`<path d="M 1115 850 V 1000" stroke="#283746"/>`+icon(glyphs[5],1250,923,64)+text(1340,914,'Dash',18,ink,'middle')+text(1340,942,'Junker',13,muted,'middle');
board+=text(48,1032,'White masters on transparent backgrounds. Tint, cooldown rings and canopy effects belong to the game.',13)+'</svg>';
fs.writeFileSync(path.join(root,'keystone-motion-review.svg'),board);
fs.writeFileSync(path.join(root,'preview.html'),`<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Keystone glyph review</title><style>body{margin:0;background:${bg}}svg{display:block;width:100%;height:auto}</style>${board}</html>`);
fs.writeFileSync(path.join(root,'geometry-manifest.json'),JSON.stringify({status:'Third design pass, awaiting owner review; not integrated',motionAxisDegrees:angle,nominalPerpendicularWeight:weight,viewBox:'0 0 64 64',glyphs:glyphs.map(({d,polys,...g})=>g)},null,2));
console.log(JSON.stringify(glyphs.map(g=>({id:g.id,pieces:g.polys.length,bounds:g.bounds}))));
