const fs=require('fs'),path=require('path'),assert=require('assert');
const area=p=>p.reduce((s,a,i)=>{const b=p[(i+1)%p.length];return s+a[0]*b[1]-a[1]*b[0];},0)/2;
const checks=[];
for(const file of fs.readdirSync(path.join(__dirname,'svg'))){
 const source=fs.readFileSync(path.join(__dirname,'svg',file),'utf8');
 assert(source.includes('viewBox="0 0 64 64"'));
 assert.equal((source.match(/<path /g)||[]).length,1);
 assert(!/<(?:image|filter|script|text|mask)|\b(?:stroke|transform|opacity)=/.test(source));
 const polys=source.match(/ d="([^"]+)"/)[1].split(' Z').filter(x=>x.trim()).map(x=>x.match(/-?\d+(?:\.\d+)?/g).map(Number)).map(a=>Array.from({length:a.length/2},(_,i)=>a.slice(i*2,i*2+2)));
 assert(polys.flat().every(([x,y])=>x>=0&&y>=0&&x<=64&&y<=64));
 assert(polys.every(p=>Math.abs(area(p))>0));
 if(file==='blink.svg'){
   assert.equal(polys.length,4);
   assert(area(polys[1])*area(polys[2])<0,'Portal hole must have opposite winding');
 }
 if(file==='overdrive.svg'){
   const a=polys[0][0],b=polys[0][2],dx=b[0]-a[0],dy=b[1]-a[1],length=Math.hypot(dx,dy),ux=dx/length,uy=dy/length;
   assert(Math.abs(Math.atan2(-dy,dx)*180/Math.PI-40)<.001);
   for(const p of polys.flat()){
     const x=p[0]-a[0],y=p[1]-a[1],dot=x*ux+y*uy,ref=[a[0]+2*dot*ux-x,a[1]+2*dot*uy-y];
     assert(polys.flat().some(q=>Math.hypot(q[0]-ref[0],q[1]-ref[1])<.0001));
   }
 }
 if(['guard-dash.svg','stealth.svg','dash.svg'].includes(file)) assert.equal(source,fs.readFileSync(path.join(__dirname,'reference-anchors',file),'utf8'));
 checks.push({file,subpaths:polys.length,boundsWithin64:true,signedAreas:polys.map(p=>+area(p).toFixed(2))});
}
assert.equal(checks.length,6);
fs.writeFileSync(path.join(__dirname,'svg-checks.json'),JSON.stringify({passed:true,checks},null,2));
console.log(JSON.stringify({passed:true,checks}));
