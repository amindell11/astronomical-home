"""Cut the ram's flipbook sheets: drawn crescent and hit (with glow sheets), vector jets. Nose up, 96 px per ship length, 60 fps."""
import json, math, os, random
import cv2, numpy as np
S = json.load(open("settings.json"))
PPU, SS, STEP, PAD = 96.0, 3, 1000.0 / 60.0, 16
NAVY = np.array([0x26, 0x16, 0x0d], np.float32)
DRAWN = [np.array(c, np.float32) for c in ((255, 255, 255), (255, 240, 143), (255, 109, 31))]
def bgr(h): h = h.lstrip("#"); return np.array([int(h[4:6], 16), int(h[2:4], 16), int(h[0:2], 16)], np.float32) / 255.0
PAL = [bgr(S["cCore"]), bgr(S["cMid"]), bgr(S["cRim"])]
OUT = "sheets"; os.makedirs(OUT, exist_ok=True); meta = {}

def key(name):
    im = cv2.imread("cels2/" + name).astype(np.float32)
    solid = (np.linalg.norm(im - NAVY, axis=2) > 55).astype(np.uint8)
    solid = cv2.morphologyEx(solid, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    lab = cv2.medianBlur(np.argmin(np.stack([np.linalg.norm(im - d, axis=2) for d in DRAWN], 2), 2).astype(np.uint8), 5)
    out = np.zeros(im.shape[:2] + (4,), np.float32)
    for i, c in enumerate(PAL): out[(lab == i) & (solid > 0), :3] = c
    out[..., 3] = solid
    return out

def fit(cels, width_l, origin_frac):
    """Crop the takes to their shared box, scale so the box is width_l ship lengths wide, pad; return SS-res cells and the origin in SS px."""
    ys, xs = np.where(np.max([c[..., 3] for c in cels], axis=0) > 0)
    x0, x1, y0, y1 = xs.min(), xs.max() + 1, ys.min(), ys.max() + 1
    k = width_l * PPU * SS / (x1 - x0)
    w, h = int(round((x1 - x0) * k)), int(round((y1 - y0) * k))
    cw, ch = w + 2 * PAD * SS, h + 2 * PAD * SS
    cw += (-cw) % SS; ch += (-ch) % SS
    out = []
    for c in cels:
        cell = np.zeros((ch, cw, 4), np.float32)
        cell[PAD * SS:PAD * SS + h, PAD * SS:PAD * SS + w] = cv2.resize(c[y0:y1, x0:x1], (w, h), interpolation=cv2.INTER_AREA)
        out.append(cell)
    return out, (PAD * SS + w * origin_frac[0], PAD * SS + h * origin_frac[1])

def warp(img, ax, ay, k):
    m = np.float32([[k, 0, ax * (1 - k)], [0, k, ay * (1 - k)]])
    return cv2.warpAffine(img, m, (img.shape[1], img.shape[0]), flags=cv2.INTER_LINEAR)
def halo(img, alpha, blur):
    sil = cv2.GaussianBlur(img[..., 3], (0, 0), blur / 70.0 * PPU * SS)
    out = np.zeros_like(img); out[..., :3] = sil[..., None] * PAL[2] * alpha
    return out
def down(img): return np.clip(cv2.resize(img, (img.shape[1] // SS, img.shape[0] // SS), interpolation=cv2.INTER_AREA) * 255.0 + 0.5, 0, 255).astype(np.uint8)
def ease_out(u): u = min(1.0, max(0.0, u)); return 1 - (1 - u) ** 2
def fade_out(u): u = min(1.0, max(0.0, u)); return 1 - u ** S["fadeCurve"]
def sheet(name, cells, cols, origin, note):
    ch, cw = cells[0].shape[:2]; rows = (len(cells) + cols - 1) // cols
    out = np.zeros((rows * ch, cols * cw, 4), np.uint8)
    for i, c in enumerate(cells):
        r, k = divmod(i, cols); out[r * ch:(r + 1) * ch, k * cw:(k + 1) * cw] = c
    cv2.imwrite(os.path.join(OUT, name + ".png"), out)
    meta[name] = {"cellPx": [cw, ch], "columns": cols, "rows": rows, "frames": len(cells), "width": cw / PPU, "length": ch / PPU,
                  "originFromCellCentre": [(origin[0] / SS - cw / 2) / PPU, (ch / 2 - origin[1] / SS) / PPU], "note": note}

# ---- bow crescent: plays through the live window; the origin is the middle of its leading edge
cres, o = fit([key(n) for n in ("crescent_C.png", "crescent_C_2.png", "crescent_C_3.png")], 0.95, (0.5, 0.0))
main, glow = [], []
for i in range(30):
    ms = i * STEP + 0.5
    c = warp(cres[(i // 2) % 3], o[0], cres[0].shape[0] - PAD * SS, 0.55 + 0.45 * ease_out(ms / 50))
    main.append(down(c)); glow.append(down(halo(c, 0.6, 6)))
sheet("crescent", main, 10, o, "origin = top middle of the drawing (leading edge)")
sheet("crescent_glow", glow, 10, o, "additive")

# ---- hit: impact, full, fade; the origin is the contact point
hit, o = fit([key(n) for n in ("hit_impact_B.png", "hit_full_B.png", "hit_fade_B.png")], 3.0, (0.5, 0.62))
main, glow = [], []
N = int(math.ceil(S["hitMs"] / STEP))
for i in range(N):
    ms = i * STEP + 0.5
    if ms < 50: c = warp(hit[0], o[0], o[1], 0.7 + 0.3 * ease_out(ms / 50)); a = 1.0
    elif ms < 150: c = warp(hit[1], o[0], o[1], 1.0 + 0.08 * (ms - 50) / 100); a = 1.0
    else: a = fade_out((ms - 150) / (S["hitMs"] - 150)); c = warp(hit[2], o[0], o[1], 1.08 + 0.1 * (ms - 150) / (S["hitMs"] - 150)) * a
    g = halo(c, 0.6 * a, 7)
    if ms < 40 and S["hitFlash"] > 0:
        f = np.zeros(c.shape[:2], np.float32)
        cv2.circle(f, (int(o[0]), int(o[1])), int(S["hitFlash"] * PPU * SS * (0.6 + 0.4 * ms / 40)), 0.9, -1, cv2.LINE_AA)
        g[..., :3] += cv2.GaussianBlur(f, (0, 0), 3 / 70.0 * PPU * SS)[..., None]
    main.append(down(c)); glow.append(down(g))
sheet("hit", main, 6, o, "origin = contact point; drawn about 3 ship lengths wide across the three cels")
sheet("hit_glow", glow, 6, o, "additive, carries the white flash")

# ---- retro jets: six small teardrops on the hull for the 0.4 s brake; vector, they are about 8 x 3 px in game
JETS = {"jetCorners": (0.47, 0.114, 0.33), "jetPods": (0.29, 0.287, 0.0), "jetVents": (-0.136, 0.24, 1.32)}
def teardrop(ln, wd):
    w = wd / 2
    return [(0, -w * 0.55), (ln * 0.12, -w), (ln * 0.38, -w * 0.72), (ln, 0), (ln * 0.38, w * 0.72), (ln * 0.12, w), (0, w * 0.55)]
CW, CH = 96, 128                                   # 1.0 x 1.33 ship lengths, centred on the ship
for key_name, (fwd, side, rot) in JETS.items():
    rnd = random.Random(S["seed"]); cells = []
    for i in range(24):
        ms = i * STEP + 0.5
        amt = min(1.0, ms / 40) * min(1.0, max(0.0, (400 - ms) / 50))
        cell = np.zeros((CH * SS, CW * SS, 4), np.float32)
        flick = 0.85 + 0.3 * rnd.random() if i % 2 == 0 else flick
        for sgn in (-1, 1):
            ln, wd = S["jetLen"] * amt * flick, S["jetWidth"] * (0.6 + 0.4 * amt)
            ca, sa = math.cos(sgn * rot), math.sin(sgn * rot)
            for k, col in ((1.0, PAL[2]), (0.7, PAL[1]), (0.42, PAL[0])):
                pts = []
                for f, s_ in teardrop(ln * k, wd * k):
                    F, Sd = fwd + f * ca - s_ * sa, sgn * side + f * sa + s_ * ca
                    pts.append([(CW / 2 + Sd * PPU) * SS, (CH / 2 - F * PPU) * SS])
                if ln > 0.005: cv2.fillPoly(cell, [np.round(np.array(pts) * 8).astype(np.int32)], (float(col[0]), float(col[1]), float(col[2]), 1.0), cv2.LINE_AA, 3)
        cells.append(down(cell))
    sheet({"jetCorners": "jets_corners", "jetPods": "jets_pods", "jetVents": "jets_vents"}[key_name], cells, 12, (CW * SS / 2, CH * SS / 2), "origin = ship centre")
json.dump(meta, open(os.path.join(OUT, "meta.json"), "w"), indent=1)
print(json.dumps(meta, indent=1))
