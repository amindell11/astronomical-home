"""Bake the dash smear tuner: cut the ship sprite, crop a game frame, inline both into the template."""
import base64
import sys

import cv2
import numpy as np

sprite_src, frame_src, template, out = sys.argv[1:5]

im = cv2.imread(sprite_src, cv2.IMREAD_COLOR)
h, w = im.shape[:2]
mask = np.zeros((h + 2, w + 2), np.uint8)
filled = im.copy()
for seed in [(0, 0), (w - 1, 0), (0, h - 1), (w - 1, h - 1), (w // 2, 0), (w // 2, h - 1), (0, h // 2), (w - 1, h // 2)]:
    cv2.floodFill(filled, mask, seed, (255, 0, 255), (14, 14, 14), (14, 14, 14), cv2.FLOODFILL_FIXED_RANGE)
alpha = np.where(mask[1:-1, 1:-1] > 0, 0, 255).astype(np.uint8)
ys, xs = np.where(alpha > 0)
y0, y1, x0, x1 = ys.min(), ys.max() + 1, xs.min(), xs.max() + 1
rgba = np.dstack([im, alpha])[y0:y1, x0:x1]
print("ship bbox", rgba.shape)

SHIP_LEN = 82
scale = SHIP_LEN / rgba.shape[0]
premult = rgba.astype(np.float32)
premult[..., :3] *= premult[..., 3:4] / 255.0
small = cv2.resize(premult, (round(rgba.shape[1] * scale), SHIP_LEN), interpolation=cv2.INTER_AREA)
a = np.clip(small[..., 3:4], 1e-3, 255)
small[..., :3] = small[..., :3] * 255.0 / a
small = np.clip(small, 0, 255).astype(np.uint8)
ok, png = cv2.imencode(".png", small)
print("sprite", small.shape, len(png))

frame = cv2.imread(frame_src, cv2.IMREAD_COLOR)
crop = frame[630:1080, 480:1440]
ok, jpg = cv2.imencode(".jpg", crop, [cv2.IMWRITE_JPEG_QUALITY, 88])
print("bg", crop.shape, len(jpg))

html = open(template, encoding="utf-8").read()
html = html.replace("__SPRITE__", "data:image/png;base64," + base64.b64encode(png.tobytes()).decode())
html = html.replace("__BG__", "data:image/jpeg;base64," + base64.b64encode(jpg.tobytes()).decode())
html = html.replace("__SPRITE_W__", str(small.shape[1])).replace("__SPRITE_H__", str(small.shape[0]))
open(out, "w", encoding="utf-8").write(html)
print("wrote", out, len(html))
