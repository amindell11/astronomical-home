# Ram cels round 2

Built-in image generation was used for all cels. Twelve generations were made: the first three crescent passes were rejected for soft lighting, and each was retried once with the harder prompt recorded below. The nine saved PNGs are the raw generated outputs, copied without image editing.

## Saved crescent prompts (retry passes)

Each saved crescent used `style_B2.png` as Image 1, `context_crescent.png` as Image 2, and `layout_crescent.png` as Image 3, with this shared prompt followed by its design line:

> Use case: stylized-concept  
> Asset type: production-ready flat-color 2D VFX cel, 4:3 canvas matching the supplied 1024x768 layout  
> Input images: Image 1 supplies ONLY the jagged chunky brush silhouette language; IGNORE its background lighting and any gradients. Image 2 supplies ONLY subject orientation and placement context; DO NOT render its ship. Image 3 fixes the exact 4:3 canvas, center, footprint, and upward-facing placement; DO NOT trace its smooth placeholder.  
> OUTPUT ONLY ONE EFFECT on a completely uniform, perfectly flat #0d1626 background, edge-to-edge. The navy must be the exact same solid color in every background pixel: no vignette, no spotlight, no lighter center, no texture.  
> The effect must be hard-edged, posterized flat graphic art with ONLY these three solid fill colors: #ffffff, #8ff0ff, #1f6dff. No intermediate shades anywhere. No lighting model. No gradients inside any shape. No glow or blur.  
> Keep the effect centered high exactly where Image 3 places it, facing up, roughly the same total width. Strong chunky silhouette readable next to an 80-pixel ship.  
> Absolutely no ship, rock, target, object, text, border, watermark, outlines, thin lines, fine detail, transparency, antialias halos, shadows, bloom, or soft edges.

### `crescent_A.png`

> Crescent A: a SINGLE heavy arched brush blade, thickest in its center, visibly one dominant mass. From each horn, two or three short chunky tapered slash-flakes peel backward. Uneven ragged cuts and asymmetric rhythm; do not make multiple parallel arcs.

Take: A reads as one battered, forward-driving blade with a broad white crown and detached horn slashes.

### `crescent_B.png`

> Crescent B: a LAYERED bow shock of exactly three broken, offset arcs: short thick white front arc, medium pale-cyan arc, longest saturated-blue rear arc. Deliberate navy gaps separate them. Each arc has uneven breaks, chunky widths, and torn tapered ends; no smooth rings.

Take: B is the clearest layered shock, with three chunky broken bands and strong navy separation.

### `crescent_C.png`

> Crescent C: an original compressed battering-ram wave: blunt white central knuckle like a shield-bash leading edge, broad cyan swept shoulders, blue under-wave, plus only four short torn back-streaming tabs. A compact forceful bow shape, not a starburst and not clean geometry.

Take: C reads like a compact shield brow with a blunt central knuckle and recoiling lower tabs.

## Hit-impact prompts

Each impact used `style_B2.png` as Image 1, `context_hit_impact.png` as Image 2, and `layout_hit_impact.png` as Image 3, with this shared prompt followed by its design line:

> Use case: stylized-concept  
> Asset type: first-frame shield-bash impact VFX cel for a top-down 2D space game, 4:3 canvas matching supplied 1024x768 layout  
> Input images: Image 1 supplies ONLY the bold jagged flat-brush shape language; ignore its lighting, gradients, and background treatment. Image 2 supplies ONLY the collision story, contact point, facing, and placement; DO NOT render the visible ship or rock. Image 3 fixes the exact 4:3 frame, effect center, approximate width, scale, and upward orientation; redesign the placeholder completely.  
> Primary request: show the instant when a heavy flat-bowed ship's bow crescent detonates against a target above it. Draw ONLY the energy effect on background. The invisible impact contact is at upper-middle center. Force travels forward/upward and sideways.  
> Scene/backdrop: one perfectly uniform solid navy #0d1626 canvas, identical color edge-to-edge, no vignette or lighting.  
> Style/medium: hard-edged posterized hand-drawn action-game VFX; bold chunky flat-brush masses; ragged tapered slash shapes; heavy impact-frame silhouette.  
> Color palette: ONLY solid #ffffff, #8ff0ff, #1f6dff on #0d1626. No intermediate shades and no color blending.  
> Composition: preserve Image 3's 4:3 framing and rough footprint; a broad snapped bow arc across lower part of effect, white-hot core at center contact, explosive spikes and shards thrust upward and outward. Readable beside an 80-pixel ship; no fine detail or thin lines.  
> Absolute constraints: effect only; no ship; no rock; no target; no objects; no text; no border; no watermark; no smooth traced placeholder.  
> Avoid: gradient, glow, blur, bloom, shading, transparency, texture, soft edge, soft halo, outline, extra colors, lighting, smooth vector crescent.

### `hit_impact_A.png`

> Impact A: MOSTLY WHITE. One fat torn arc, with a compact white-hot central core and a jagged crown/starburst punching strongly forward/up from its center. Use cyan and blue only as chunky supporting undercuts at the arc shoulders. Five to seven stout irregular spikes, not a symmetrical sun.

Take: A lands as a white-dominant heavy crown with a strong central spear and braced arc shoulders.

### `hit_impact_B.png`

> Impact B: an explosive fan at the contact: broad wedges and chunky shards radiate upward and sideways; the original arc is barely holding together as two or three torn curved shoulder fragments. Large navy breaks separate the pieces. Weight the center white, with alternating cyan and blue fan shards.

Take: B is the loosest explosion, with large alternating fan wedges, detached debris, and only two surviving arc fragments.

### `hit_impact_C.png`

> Impact C: invent the strongest original shield-bash impact frame: a blunt white contact block splits the bow wave into two kicked-back jaws while three massive forward chisel-slashes spear up through the middle; blue recoil slabs and cyan splinters make a compact asymmetrical crush.

Take: C has the strongest ram identity, splitting the lower wave into jaws beneath three huge forward chisels.

## Hit-full prompts

Each later frame used its matching `hit_impact_*.png` as Image 1, `style_B2.png` as Image 2, `context_hit_full.png` as Image 3, and `layout_hit_full.png` as Image 4, with this shared prompt followed by its continuity line:

> Use case: stylized-concept  
> Asset type: follow-on hit-burst animation cel, a few frames after impact, for a top-down 2D space game  
> Input images: Image 1 is the matching FIRST IMPACT CEL and is the design-continuity anchor; evolve its exact motif a few frames later without tracing it. Image 2 supplies ONLY bold jagged flat-brush shape language; ignore its lighting, gradients, and background. Image 3 supplies ONLY collision context and placement; DO NOT render its ship or rock. Image 4 fixes the 4:3 frame, later-frame center, wider footprint, and upward orientation; redesign its placeholder.  
> Primary request: Draw ONLY the energy effect after the initial hit has expanded and begun breaking apart. It must clearly be the next animation frame after Image 1: wider, more open, more navy gaps, fewer connected masses, chunky fragments flying upward and outward, core starting to empty.  
> Scene/backdrop: perfectly uniform solid navy #0d1626, identical color edge-to-edge, no vignette, spotlight, or lighting.  
> Style/medium: hard-edged posterized hand-drawn action-game VFX; bold flat-brush chunks; ragged tapered slashes; strong silhouette at game scale.  
> Color palette: ONLY solid #ffffff, #8ff0ff, #1f6dff on #0d1626. No intermediate shades or blended colors.  
> Composition: match Image 4's rough center and wider total width. Keep forward/upward momentum, with pieces traveling to both upper corners and sides. More navy shows through than in Image 1. Readable next to an 80-pixel ship.  
> Absolute constraints: effect only; no ship; no rock; no target; no objects; no text; no border; no watermark; no smooth traced placeholder.  
> Avoid: gradient, glow, blur, bloom, shading, transparency, texture, soft edge, halo, outline, extra colors, lighting, tiny confetti, thin lines, perfectly radial symmetry.

### `hit_full_A.png`

> Full A continuity: preserve A's mostly-white fat arc and central crown identity, but snap the crown into 5–7 separated stout slash chunks; break the arc into three big curved plates drifting apart. The center becomes a navy bite/open void. Cyan and blue remain secondary shoulder fragments.

Take: A opens its white crown into separated slashes while the fat lower arc breaks into drifting plates around a navy center.

### `hit_full_B.png`

> Full B continuity: continue B's explosive fan. The fan is now stretched wider and fragmented: 7–10 large wedges/shards with generous navy gaps, outer pieces flung sideways, forward pieces farther up. Only two short broken arc fragments survive low on the sides; central contact area is mostly navy.

Take: B becomes a wide, airy wedge fan with the darkest and most open center of the three follow-on frames.

### `hit_full_C.png`

> Full C continuity: continue C's split jaws and three chisel-slashes. The two curved jaws recoil farther apart; each of the three big forward chisels fractures once into a leading chunk and trailing chunk, with cyan splinters and blue recoil slabs spreading outward. Open navy channel through the center.

Take: C preserves the split jaws and sends the chisel motif forward as paired leading and trailing chunks.

## Discarded crescent first-pass prompts

The rejected first passes shared the same reference order and the following base prompt:

> Use case: stylized-concept  
> Asset type: top-down 2D space-game VFX cel, 1024x768  
> Input images: Image 1 is the style reference only; Image 2 is the ship context showing placement and facing; Image 3 is the layout reference fixing canvas, center, scale, width, and upward orientation.  
> Primary request: Draw ONLY the ramming bow-crescent effect on a perfectly flat solid navy #0d1626 canvas. Do not draw or hint at the ship, rock, target, or any other object.  
> Style/medium: match Image 1's bold hand-painted action-game VFX language: flat-brush silhouettes, hard crisp edges, chunky readable masses, ragged tapered tips, and tapered slash cuts.  
> Composition/framing: preserve Image 3's 1024x768 framing and approximate placeholder center and overall width; effect faces upward and sits ahead of the invisible flat bow.  
> Color palette: exactly four RGB colors total: background #0d1626, pure white #ffffff, pale cyan #8ff0ff, saturated blue #1f6dff. Use only flat fills.  
> Constraints: effect only; bold enough to read beside an 80-pixel ship; no thin lines; no fine detail; no text; no border; no watermark.  
> Avoid: tracing the placeholder; smooth vector-perfect geometry; gradients; glow; blur; bloom; shading; transparency; texture; antialias-like soft halos; outlines; extra colors; ship; rock; target.

The A suffix asked for one strongly arched heavy brush blade with white/cyan horn slashes, the B suffix asked for two or three offset broken arcs with navy gaps, and the C suffix asked for a blunt central knuckle with swept shoulders and torn back-streaming tabs.

## Round 3: in-between takes

- `crescent_C_2.png` and `crescent_C_3.png` use `crescent_C.png` as the strict registration reference. They preserve the picked crescent's position, scale, arc, and main color layout while relocating small ragged notches, slashes, and breaks for a three-frame shiver cycle.
- `hit_fade_B.png` continues `hit_full_B.png`, with `hit_impact_B.png` supplying earlier motion context. The burst opens into sparse outward-flying blue/cyan slivers, one small white accent, and a mostly empty navy center.
- Each cel received one harder flat-color retry because the first take came back softly shaded. The selected retry outputs are saved raw and unedited. `board3.png` presents the three crescent frames above the three B-hit frames.
