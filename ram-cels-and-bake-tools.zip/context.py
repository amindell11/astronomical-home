"""Context frames: each layout drawn in place on the real Bulwark, nose up, so the image model can see what the shape is for."""
import cv2, numpy as np
NAVY = np.array([0x26, 0x16, 0x0d], np.float32)
im = cv2.imread("bulwark-top.png")
h, w = im.shape[:2]
mask = np.zeros((h + 2, w + 2), np.uint8); f = im.copy()
for seed in [(0, 0), (w - 1, 0), (0, h - 1), (w - 1, h - 1), (w // 2, 0), (w // 2, h - 1), (0, h // 2), (w - 1, h // 2)]:
    cv2.floodFill(f, mask, seed, (255, 0, 255), (14, 14, 14), (14, 14, 14), cv2.FLOODFILL_FIXED_RANGE)
alpha = np.where(mask[1:-1, 1:-1] > 0, 0, 255).astype(np.uint8)
ys, xs = np.where(alpha > 0)
ship = np.dstack([im, alpha])[ys.min():ys.max() + 1, xs.min():xs.max() + 1].astype(np.float32)

def context(layout, out, ppl, origin, rock):
    lay = cv2.imread("cels2/" + layout).astype(np.float32)
    canvas = np.tile(NAVY, (1024, 1024, 1))
    oy = 40 if not rock else 120                      # shift down so the ship fits under the effect
    s = ppl / ship.shape[0]
    sp = cv2.resize(ship, (round(ship.shape[1] * s), round(ppl)), interpolation=cv2.INTER_AREA)
    x0, y0 = int(origin[0] - sp.shape[1] / 2), int(origin[1] + oy)
    y1 = min(1024, y0 + sp.shape[0]); sp = sp[:y1 - y0]
    a = sp[..., 3:] / 255.0
    canvas[y0:y1, x0:x0 + sp.shape[1]] = sp[..., :3] * a + canvas[y0:y1, x0:x0 + sp.shape[1]] * (1 - a)
    if rock:
        rng = np.random.RandomState(3); pts = []
        for i in range(12):
            ang = i / 12 * np.pi * 2; r = 120 * (0.8 + 0.3 * rng.rand())
            pts.append([origin[0] + np.cos(ang) * r, origin[1] + oy - 125 + np.sin(ang) * r])
        cv2.fillPoly(canvas, [np.int32(pts)], (114, 106, 109), cv2.LINE_AA)
    fx = np.linalg.norm(lay - NAVY, axis=2) > 40
    region = canvas[oy:oy + 768]
    region[fx] = lay[fx]
    cv2.imwrite("cels2/" + out, canvas.astype(np.uint8))

context("layout_crescent.png", "context_crescent.png", 620.0, (512, 330), False)
context("layout_hit_impact.png", "context_hit_impact.png", 300.0, (512, 520), True)
context("layout_hit_full.png", "context_hit_full.png", 300.0, (512, 520), True)
ims = [cv2.resize(cv2.imread("cels2/" + n), (512, 512)) for n in ["context_crescent.png", "context_hit_impact.png", "context_hit_full.png"]]
cv2.imwrite("cels2/_context_preview.png", np.hstack(ims))
