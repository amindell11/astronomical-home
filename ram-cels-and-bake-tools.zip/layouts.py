"""Vector layout frames for the ram cels: nose up, flat navy, Vanguard's blue drawing palette (assemble re-colours)."""
import json, math, random
import cv2, numpy as np
S = json.load(open("settings.json"))
NAVY, RIM, MID, CORE = (0x26, 0x16, 0x0d), (255, 109, 31), (255, 240, 143), (255, 255, 255)
W, H = 1024, 768
meta = {}

def crescent(tip, radius, span_deg, thick, n=40):
    s = math.radians(span_deg) / 2
    outer, inner = [], []
    for i in range(n + 1):
        a = -s + 2 * s * i / n
        fwd, side, u = tip - radius + radius * math.cos(a), radius * math.sin(a), a / s
        outer.append((fwd, side)); inner.append((fwd - thick * (1 - u * u), side))
    return outer + inner[::-1]

def draw(img, pts, color, ppl, origin):
    p = np.array([[origin[0] + side * ppl, origin[1] - fwd * ppl] for fwd, side in pts], np.float32)
    cv2.fillPoly(img, [np.round(p * 8).astype(np.int32)], color, cv2.LINE_AA, 3)

def bands(img, tip, radius, span, thick, ppl, origin):
    draw(img, crescent(tip, radius, span, thick), RIM, ppl, origin)
    draw(img, crescent(tip, radius, span * 0.94, thick * 0.62), MID, ppl, origin)
    draw(img, crescent(tip, radius, span * 0.8, thick * 0.28), CORE, ppl, origin)

# bow crescent: origin is the bow's centre point
img = np.full((H, W, 3), NAVY, np.uint8); ppl, origin = 620.0, (W / 2, 330.0)
bands(img, S["cresGap"] + S["cresThick"], S["cresRadius"], S["cresSpan"], S["cresThick"], ppl, origin)
cv2.imwrite("cels/layout_crescent.png", img); meta["crescent"] = {"ppl": ppl, "origin": origin}

# hit: origin is the contact point; crescent at full hit size plus the forward spikes
def hit(name, grow, thick_k, spike_u):
    img = np.full((H, W, 3), NAVY, np.uint8); ppl, origin = 300.0, (W / 2, 520.0)
    rnd = random.Random(S["seed"]); arc = math.radians(S["hitArc"]); n = S["hitSpikes"]
    for i in range(n):
        ang = -arc / 2 + arc * i / (n - 1) + (rnd.random() - 0.5) * 0.2
        ln = S["hitSpikeLen"] * (0.5 + 0.5 * rnd.random())
        near, w = ln * (0.15 + 0.75 * spike_u), 0.05 * (1.2 - spike_u)
        far = near + ln * 0.55 * (1.2 - spike_u)
        c, s = math.cos(ang), math.sin(ang)
        tri = [(near, -w), (far, 0), (near, w)]
        draw(img, [(f * c - sd * s, f * s + sd * c) for f, sd in tri], MID if i % 2 else CORE, ppl, origin)
    if thick_k > 0:
        t = S["cresThick"] * grow * thick_k
        bands(img, S["cresGap"] + S["cresThick"] * grow * 0.5, S["cresRadius"] * grow, S["cresSpan"], t, ppl, origin)
    cv2.imwrite("cels/" + name, img); meta[name] = {"ppl": ppl, "origin": origin}
hit("layout_hit_impact.png", S["hitScale"] * 0.8, 1.6, 0.15)
hit("layout_hit_full.png", S["hitScale"], 1.0, 0.45)
hit("layout_hit_fade.png", S["hitScale"] * 1.05, 0.4, 0.85)
json.dump(meta, open("cels/layout_meta.json", "w"), indent=1)
print(meta)
