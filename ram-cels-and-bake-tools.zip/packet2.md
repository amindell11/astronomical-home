# Ram cels, round 2: design the shapes, do not trace the layouts

Round 1 traced the vector layouts and only roughened their edges. The owner said it "didn't really do much". This round you design the shapes.

## What these are

A top-down space game. Bulwark is a heavy, armoured ship with a flat bow plate. Its special move is a ram: it launches forward (up in every image here) and smashes bow-first into a target. Two effects are needed:

- **Bow crescent.** While it charges, a blade of light is pushed ahead of the flat bow, like the bow shock in front of something heavy moving fast, or the leading arc of a shield bash. `cels2/context_crescent.png` shows where it sits on the ship.
- **Hit burst.** At the moment of impact the crescent detonates at the contact point: a white-hot core, the arc snapping much larger, shards and spikes thrown forward and outward into the target, heavy slashes. Think of the impact frame of a shield bash in a hand-drawn 2D action game. `cels2/context_hit_impact.png` and `cels2/context_hit_full.png` show the ship, the rock it hits and where the burst sits.

In the context images the blue shape is only a placeholder marking position and rough width. It is not a drawing to copy. At game size the ship is about 80 px long, so shapes must be bold, chunky and readable from a distance: no fine detail, no thin lines.

## Style

`cels2/style_B2.png` is the owner's picked style: flat-brush shapes, ragged tapered edges, tapered white slashes, exactly three flat colours (pure white, pale cyan #8ff0ff, saturated blue #1f6dff) on flat navy #0d1626. Hard edges. No gradients, glow, blur, texture, outline, text or border. Keep the blue palette; it is re-coloured later.

## What to draw

Use your built-in image generation tool. Give it `cels2/style_B2.png` as the style reference and the named context image so it understands the subject. The output must contain ONLY the effect on flat navy: no ship, no rock. Keep the effect where the placeholder is in the matching `layout_*.png` (same frame size, same centre, facing up, roughly the same overall width), so it can be placed on the ship later. Inside that, the shape is yours.

1. Bow crescent, three different designs, from `context_crescent.png` / `layout_crescent.png`:
   - `cels2/crescent_A.png`: a single heavy brush blade, thick in the middle, with slashes peeling back off both horns.
   - `cels2/crescent_B.png`: a layered bow shock, two or three stacked arcs of different lengths, broken and uneven.
   - `cels2/crescent_C.png`: your own best idea for a ramming bow wave.
2. Hit burst, first frame, three different designs, from `context_hit_impact.png` / `layout_hit_impact.png`:
   - `cels2/hit_impact_A.png`: mostly white, a fat arc with a jagged starburst punching forward from its centre.
   - `cels2/hit_impact_B.png`: an explosive fan, wedges and shards radiating forward and sideways from the contact point, the arc barely holding together.
   - `cels2/hit_impact_C.png`: your own best idea for the impact frame.
3. Hit burst, a few frames later, from `context_hit_full.png` / `layout_hit_full.png`: `cels2/hit_full_A.png`, `hit_full_B.png`, `hit_full_C.png`, each the follow-on to the matching impact design: wider, breaking apart, pieces flying outward, more navy showing through.

If a take comes back soft, shaded, off-palette, or with a ship or rock in it, retry it once with a harder prompt. No more than 13 generations in total. Save the raw images unedited under the names above. Then build `cels2/board.png` on navy with plain white labels: row 1 the crescent context then A, B, C; row 2 the impact context then A, B, C; row 3 the full context then A, B, C. Write `cels2/notes.md` with the prompt used for each and one plain sentence on each take. Write only inside the `cels2` folder and delete nothing.
