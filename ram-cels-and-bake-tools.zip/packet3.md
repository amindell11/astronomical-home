# Ram cels, round 3: in-between takes for the owner's picks

The owner picked `cels2/crescent_C.png` for the bow crescent and `cels2/hit_impact_B.png` then `cels2/hit_full_B.png` for the hit. This round draws the extra frames needed to animate them. Same subject and style as round 2: a top-down space game, the heavy ship Bulwark ramming upward, flat-brush shapes in exactly three flat colours (pure white, pale cyan #8ff0ff, saturated blue #1f6dff) on flat navy #0d1626, hard edges, no gradients, glow, blur, texture, outline, text or border. Only the effect in frame, no ship or rock.

Use your built-in image generation tool, giving it the named picked image as the reference.

1. `cels2/crescent_C_2.png` and `cels2/crescent_C_3.png`, reference `cels2/crescent_C.png`: two more drawings of the same crescent by the same hand, as consecutive animation frames. Same position in frame, same size, same overall silhouette and colour layout; the ragged edges, slashes and small breaks land in different places. They are cycled with the original to make it shiver, so they must not jump in size or position.
2. `cels2/hit_fade_B.png`, references `cels2/hit_full_B.png` (and `cels2/hit_impact_B.png` for what came before): the next frame of the same burst as it dies. Same centre and facing. The pieces have flown further outward and shrunk to thin slivers, about half as many as in `hit_full_B.png`, mostly blue and cyan with very little white, lots of navy showing.

If a take changes size, position or palette, or comes back soft or shaded, retry it once with a harder prompt. No more than 6 generations in total. Save the raw images unedited under the names above. Then build `cels2/board3.png` on navy with plain white labels: row 1 crescent_C, crescent_C_2, crescent_C_3; row 2 hit_impact_B, hit_full_B, hit_fade_B. Append a short section to `cels2/notes.md`. Write only inside the `cels2` folder and delete nothing.
