"""Project the three frozen painted views and bake unlit per-component albedo.

Inputs paint/{hero,rear,underside}-painted.png and frozen projection source.
Outputs model/verdant-painted.blend, model/textures, paint-bake-report.json and actual mesh previews.
"""
from pathlib import Path
import bpy,bmesh,json,hashlib,math
from mathutils import Vector,Matrix
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'model';TEX=OUT/'textures';TEX.mkdir(exist_ok=True)
meta=json.loads((ROOT/'guides/projection-metadata.json').read_text())
source=ROOT/'model/verdant-projection-source.blend'
assert hashlib.sha256(source.read_bytes()).hexdigest()==meta['source_sha256']
bpy.ops.wm.open_mainfile(filepath=str(source))
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=1
scene.render.bake.margin=20;scene.render.bake.use_clear=False
objects=[o for o in scene.objects if o.type=='MESH' and not o.hide_render]
images={}
guide_images={}
id_images={};id_pixels={}
ids=json.loads((ROOT/'guides/component-ids.json').read_text())['objects']
guide_alpha={}
report={'source_sha256':meta['source_sha256'],'workflow':'Three explicit orthographic projections, per-face visibility assignment, unlit EMIT bake. No lighting/AO baked.','paint_sources':[],'components':[]}
for view in meta['views']:
    label=view['name'];path=ROOT/'paint'/(label+'-painted.png')
    image=bpy.data.images.load(str(path));image.pack();images[label]=image
    assert list(image.size)==[1536,1024],(label,list(image.size))
    guide=bpy.data.images.load(str(ROOT/'guides'/(label+'-unlit.png')))
    guide_images[label]=guide
    identifier=bpy.data.images.load(str(ROOT/'guides'/(label+'-component-ids.exr')))
    identifier.colorspace_settings.name='Non-Color';id_images[label]=identifier;id_pixels[label]=list(identifier.pixels)[::4]
    guide_alpha[label]=list(guide.pixels)[3::4]
    report['paint_sources'].append({'file':'paint/'+path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'dimensions':list(image.size)})
for index,obj in enumerate(objects):
    original=obj.data.materials[0]
    role=original.get('review_role','surface')
    fallback=original.node_tree.nodes.get('Principled BSDF').inputs['Base Color'].default_value[:]
    size=2048 if index==0 else (512 if role=='ochre' else 1024)
    target=bpy.data.images.new('VerdantAlbedo_%02d'%index,size,size,alpha=False)
    target.generated_color=fallback;target.colorspace_settings.name='sRGB'
    obj.data.materials.clear()
    for preferred,view in enumerate(meta['views']):
        label=view['name'];mat=bpy.data.materials.new(obj.name+' projection '+label);mat.use_nodes=True
        nodes=mat.node_tree.nodes;nodes.clear();links=mat.node_tree.links
        output=nodes.new('ShaderNodeOutputMaterial');emission=nodes.new('ShaderNodeEmission')
        base=nodes.new('ShaderNodeRGB');base.outputs[0].default_value=fallback;color=base.outputs[0]
        geometry=nodes.new('ShaderNodeNewGeometry')
        for which in [i for i in range(3) if i!=preferred]+[preferred]:
            label=meta['views'][which]['name']
            uv=nodes.new('ShaderNodeUVMap');uv.uv_map='Projection_'+label
            image=nodes.new('ShaderNodeTexImage');image.image=images[label];image.extension='EXTEND'
            mask=nodes.new('ShaderNodeTexImage');mask.image=id_images[label];mask.extension='CLIP';mask.interpolation='Closest'
            links.new(uv.outputs[0],image.inputs[0]);links.new(uv.outputs[0],mask.inputs[0])
            sub=nodes.new('ShaderNodeMath');sub.operation='SUBTRACT';sub.inputs[1].default_value=ids[obj.name];links.new(mask.outputs['Color'],sub.inputs[0])
            absolute=nodes.new('ShaderNodeMath');absolute.operation='ABSOLUTE';links.new(sub.outputs[0],absolute.inputs[0])
            equal=nodes.new('ShaderNodeMath');equal.operation='LESS_THAN';equal.inputs[1].default_value=.001;links.new(absolute.outputs[0],equal.inputs[0])
            dot=nodes.new('ShaderNodeVectorMath');dot.operation='DOT_PRODUCT';dot.inputs[1].default_value=meta['views'][which]['view_direction'];links.new(geometry.outputs['True Normal'],dot.inputs[0])
            front=nodes.new('ShaderNodeMath');front.operation='GREATER_THAN';front.inputs[1].default_value=.05;links.new(dot.outputs['Value'],front.inputs[0])
            valid=nodes.new('ShaderNodeMath');valid.operation='MULTIPLY';links.new(equal.outputs[0],valid.inputs[0]);links.new(front.outputs[0],valid.inputs[1])
            mix=nodes.new('ShaderNodeMixRGB');links.new(valid.outputs[0],mix.inputs[0]);links.new(color,mix.inputs[1]);links.new(image.outputs['Color'],mix.inputs[2]);color=mix.outputs[0]
        links.new(color,emission.inputs['Color']);links.new(emission.outputs[0],output.inputs[0])
        bake=nodes.new('ShaderNodeTexImage');bake.image=target;nodes.active=bake
        obj.data.materials.append(mat)
    assignments=obj.data.attributes['paint_view']
    missing=0;samples=0;unobserved=0
    for face in obj.data.polygons:
        which=assignments.data[face.index].value;face.material_index=which
        label=meta['views'][which]['name'];uv=obj.data.uv_layers['Projection_'+label]
        coords=[uv.data[i].uv for i in face.loop_indices]
        center=sum(coords,Vector((0,0)))/len(coords)
        assert 0<=center.x<=1 and 0<=center.y<=1,(obj.name,face.index,tuple(center))
        x=min(1535,max(0,int(center.x*1536)));y=min(1023,max(0,int(center.y*1024)))
        samples+=1
        if guide_alpha[label][y*1536+x]<.5:missing+=1
        covered=False
        for candidate in meta['views']:
            layer=obj.data.uv_layers['Projection_'+candidate['name']]
            point=sum((layer.data[i].uv for i in face.loop_indices),Vector((0,0)))/len(face.loop_indices)
            xx=min(1535,max(0,int(point.x*1536)));yy=min(1023,max(0,int(point.y*1024)))
            if abs(id_pixels[candidate['name']][yy*1536+xx]-ids[obj.name])<.001 and face.normal.dot(Vector(candidate['view_direction']))>.05:covered=True
        if not covered:unobserved+=1
    obj.data.uv_layers.active=obj.data.uv_layers['MineralAtlasUV'];obj.data.uv_layers.active.active_render=True
    bpy.ops.object.select_all(action='DESELECT');obj.select_set(True);bpy.context.view_layer.objects.active=obj
    bpy.ops.object.bake(type='EMIT')
    filename='verdant-%02d-albedo.png'%index;path=TEX/filename
    target.filepath_raw=str(path);target.file_format='PNG';target.save();target.pack();target.filepath='//textures/'+filename
    final=bpy.data.materials.new(obj.name+' fitted paint');final.use_nodes=True;final['review_role']=role
    nodes=final.node_tree.nodes;links=final.node_tree.links
    p=nodes.get('Principled BSDF');p.inputs['Roughness'].default_value=.94;p.inputs['Specular IOR Level'].default_value=.12
    texture=nodes.new('ShaderNodeTexImage');texture.image=target;texture.extension='EXTEND'
    uv=nodes.new('ShaderNodeUVMap');uv.uv_map='MineralAtlasUV';links.new(uv.outputs[0],texture.inputs[0]);links.new(texture.outputs['Color'],p.inputs['Base Color'])
    obj.data.materials.clear();obj.data.materials.append(final)
    for face in obj.data.polygons:face.material_index=0
    report['components'].append({'object':obj.name,'material_role':role,'albedo':'model/textures/'+filename,'size':size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'uv_center_samples':samples,'outside_guide_alpha_samples':missing,'unobserved_backing_centers_using_own_base_color':unobserved})
    print('BAKED='+obj.name,flush=True)

body=bpy.data.objects['Angular connected host']
parts=body.users_collection[0]
ink=bpy.data.materials.new('Selected graphite fracture strokes');ink.use_nodes=True;ink['review_role']='ink'
p=ink.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(.022,.025,.027,1);p.inputs['Roughness'].default_value=.97
adj={tuple(sorted(e.vertices)):[] for e in body.data.edges}
for face in body.data.polygons:
    ids=list(face.vertices)
    for a,b in zip(ids,ids[1:]+ids[:1]):adj[tuple(sorted((a,b)))].append(face)
used=set();view=Vector(meta['views'][0]['view_direction'])
for number,(anchor,width) in enumerate([((-1.7,.05,1.45),.018),((-1.2,.26,.74),.015),((.5,-1.25,.25),.018),((-2.5,-.85,.1),.012),((.1,.6,.9),.012),((1.6,-.8,.5),.014),((-2,.9,1.9),.010)]):
    anchor=Vector(anchor);choices=[]
    for key,faces in adj.items():
        if key in used or len(faces)!=2:continue
        a,b=[body.data.vertices[i].co.copy() for i in key];length=(b-a).length
        if length<.36 or faces[0].normal.angle(faces[1].normal)<math.radians(25):continue
        normal=max((f.normal.copy() for f in faces),key=lambda n:n.dot(view))
        if normal.dot(view)<.1:continue
        t=max(0,min(1,(anchor-a).dot(b-a)/(length*length)))
        choices.append(((anchor-a.lerp(b,t)).length_squared,key,a,b,normal))
    _,key,a,b,normal=min(choices,key=lambda v:v[0]);used.add(key)
    tangent=(b-a).normalized();side=normal.cross(tangent).normalized();verts=[]
    for t,pressure in [(.09,.08),(.29,.8),(.57,1),(.83,.05)]:
        point=a.lerp(b,t)+normal*.012
        verts.extend([point-side*width*pressure,point+side*width*pressure])
    data=bpy.data.meshes.new('Fracture ink %02d'%number);data.from_pydata(verts,[],[(0,1,3,2),(2,3,5,4),(4,5,7,6)]);data.materials.append(ink);data.update()
    drawing=bpy.data.objects.new('Drawing_Fracture_%02d'%number,data);parts.objects.link(drawing);drawing.parent=body.parent;drawing['intentional_open_ribbon']=True
    uv=data.uv_layers.new(name='MineralAtlasUV')

scene.cycles.samples=32;scene.render.resolution_x=900;scene.render.resolution_y=650
scene.view_settings.view_transform='AgX';scene.view_settings.look='AgX - Medium High Contrast'
scene.camera.matrix_world=Matrix(meta['views'][0]['camera_matrix_world']);scene.camera.data.ortho_scale=7.7
settings=bpy.context.view_layer.freestyle_settings
for line in list(settings.linesets):settings.linesets.remove(line)
line=settings.linesets.new('Selected external drawn contour')
for prop in ('select_silhouette','select_border','select_crease','select_edge_mark','select_material_boundary','select_contour','select_suggestive_contour','select_ridge_valley'):setattr(line,prop,False)
line.select_external_contour=True;line.linestyle.color=(.007,.009,.012);line.linestyle.thickness=3.0;line.linestyle.caps='ROUND'
noise=line.linestyle.thickness_modifiers.new('Uneven pressure','NOISE');noise.amplitude=.5;noise.period=25;noise.seed=7
scene.render.use_freestyle=True
scene['paint_workflow']='Three painted orthographic projections baked as unlit component albedo; no scene lighting baked'
scene['outline']='Freestyle in Blender; actual DrawnContour shader and joined-normal host shell in the game preview'
source=OUT/'verdant-painted.blend'
bpy.data.orphans_purge(do_local_ids=True,do_linked_ids=True,do_recursive=True)
bpy.ops.wm.save_as_mainfile(filepath=str(source),relative_remap=False)
report['painted_source_sha256']=hashlib.sha256(source.read_bytes()).hexdigest()
(ROOT/'paint-bake-report.json').write_text(json.dumps(report,indent=2))
def render(label):
    scene.render.filepath=str(OUT/('verdant-'+label+'.png'));bpy.ops.render.render(write_still=True);print('RENDER='+scene.render.filepath,flush=True)
render('painted-hero')
scene.render.resolution_x=150;scene.render.resolution_y=110;line.linestyle.thickness=1.8;render('painted-150')
scene.render.resolution_x=900;scene.render.resolution_y=650;line.linestyle.thickness=3.0
scene.camera.matrix_world=Matrix(meta['views'][1]['camera_matrix_world']);render('painted-reverse')
target=Vector((0,0,.4));scene.camera.location=target+Vector((7,-1,3.8)).normalized()*12;scene.camera.rotation_euler=(target-scene.camera.location).to_track_quat('-Z','Y').to_euler();render('painted-side')
print('PAINT_PROOF_COMPLETE',flush=True)
