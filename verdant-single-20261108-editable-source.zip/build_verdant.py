"""Author one angular Verdant fragment. Blender CLI; all output is adjacent to this script."""
from pathlib import Path
import bpy, bmesh, math, json, sys
from mathutils import Vector

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'model'
OUT.mkdir(exist_ok=True)
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.context.preferences.filepaths.save_version = 0
scene = bpy.context.scene
parts = bpy.data.collections.new('Editable geological components')
scene.collection.children.link(parts)
review = bpy.data.collections.new('Review cameras and lighting')
scene.collection.children.link(review)
parent = bpy.data.objects.new('Verdant, torn diagonal mineral fracture', None)
parts.objects.link(parent)

def material(name, color, role):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    p = m.node_tree.nodes.get('Principled BSDF')
    p.inputs['Base Color'].default_value = (*color, 1)
    p.inputs['Roughness'].default_value = .93
    p.inputs['Specular IOR Level'].default_value = .15
    m['review_role'] = role
    return m

slate = material('Charcoal host, flat construction guide', (.105,.115,.135), 'dark_host')
jade = material('Deep jade fracture, flat construction guide', (.055,.175,.115), 'mineral')
green = material('Green ledges, flat construction guide', (.16,.31,.18), 'mineral')
pale_green = material('Pale green laminae, flat construction guide', (.32,.43,.20), 'mineral')
cream = material('Broken cream crust, flat construction guide', (.56,.46,.31), 'cream')
ochre = material('Ochre deposits, flat construction guide', (.46,.27,.055), 'ochre')
clay = material('Neutral clay', (.32,.34,.36), 'clay')
palette = [slate,jade,green,pale_green,cream,ochre]

def mesh(name, vertices, faces, materials=None):
    data = bpy.data.meshes.new(name+'Mesh')
    data.from_pydata(vertices, [], faces)
    data.update()
    bm=bmesh.new();bm.from_mesh(data)
    bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))
    bm.to_mesh(data);bm.free()
    obj=bpy.data.objects.new(name,data);parts.objects.link(obj);obj.parent=parent
    for m in materials or palette:data.materials.append(m)
    return obj

# Each cross-section follows the torn surface from the near wall to the rear crown.
stations = [
    (-2.95,[-1.45,-1.02,-.78,-.42,-.05,.24,.54,.89],[.02,.12,-.02,-.30,-.02,.64,.88,.66]),
    (-2.47,[-1.74,-1.13,-.85,-.35,.16,.02,.56,1.30],[.24,.33,.02,-.27,.11,1.14,1.54,1.17]),
    (-1.84,[-1.81,-1.18,-.70,-.30,.27,.14,.70,1.46],[.40,.44,.01,-.13,.23,1.46,1.94,1.55]),
    (-1.10,[-1.59,-1.05,-.73,-.19,.29,.42,.91,1.43],[.37,.55,.21,.03,.45,1.43,1.78,1.42]),
    (-.37,[-1.63,-1.02,-.58,-.10,.35,.59,1.00,1.48],[.47,.66,.30,.15,.47,1.02,1.36,1.18]),
    (.41,[-1.52,-.97,-.53,.00,.43,.66,1.09,1.43],[.52,.65,.36,.23,.51,.81,1.07,.89]),
    (1.12,[-1.49,-.80,-.39,.10,.50,.81,1.16,1.44],[.55,.70,.43,.39,.62,.86,.95,.75]),
    (1.92,[-1.23,-.69,-.28,.21,.55,.91,1.20,1.39],[.54,.69,.53,.53,.69,.87,.85,.63]),
    (2.55,[-.99,-.52,-.14,.28,.61,.91,1.18,1.28],[.51,.63,.62,.68,.75,.84,.73,.55]),
    (2.92,[-.68,-.36,-.02,.25,.56,.79,.97,1.04],[.30,.43,.50,.56,.61,.65,.57,.38]),
]
# Unequal terminations keep geological sheets from sharing a single straight end.
x_offsets = [
    [-.08,.18,.25,.38,.41,.43,.72,.58],
    [-.03,.10,.02,-.12,.03,-.16,-.01,.05],
    [.03,-.08,.13,.02,-.09,-.10,.05,-.08],
    [-.04,.10,-.06,.08,.12,-.05,.02,.09],
    [.10,-.06,.08,-.04,-.05,.12,-.05,.04],
    [-.04,.08,-.04,.10,-.12,.06,.08,-.08],
    [.04,-.06,.09,-.08,.04,-.10,.05,.05],
    [-.10,.07,-.06,.08,-.04,.05,-.09,.05],
    [.02,-.05,.04,-.02,.07,.03,-.03,.01],
    [.10,.07,.02,-.03,-.12,-.07,-.19,-.21],
]
vertices=[]
R=13
for i,(x,ys,zs) in enumerate(stations):
    high=zs[6]+(.32 if i in (1,2,3) else .08)
    floor=zs[3]+[-.22,-.15,.18,-.15,.14,-.07,.1,0,0,0][i]
    ledge=[.01,-.16,.16,-.08,.12,-.10,.09,-.05,.01,0][i]
    profile=[
        (ys[0],zs[0]),(ys[1],zs[1]+ledge),
        (ys[2],zs[2]+ledge),(ys[3],floor),
        (ys[3]+.20,floor+.11),
        (ys[4]+.18,floor+.19),
        (ys[4]-.06,high*.40+ledge),
        (ys[4]+.18,high*.43+ledge),
        (ys[5]+.30,high*.62),
        (ys[5]-.16,high*.78+ledge*.4),
        (ys[5]+.10,high*.87+ledge*.4),
        (ys[6],high),(ys[7],zs[7]+.08)]
    offsets=[x_offsets[i][j] for j in (0,1,2,3,3,4,4,4,5,5,5,6,7)]
    if i==0:
        offsets=[-.20,.11,-.12,.38,.46,.61,.31,.46,.54,.18,.36,.55,.45]
    if i==1:
        offsets=[-.03,.10,.06,-.20,-.13,.14,-.05,.02,.13,-.07,-.02,-.01,.05]
    if i==2:
        profile[9]=(profile[9][0]-.22,profile[9][1]-.04)
        profile[10]=(profile[10][0]-.14,profile[10][1])
    if i==3:
        profile[9]=(profile[9][0]+.20,profile[9][1]-.16)
        profile[10]=(profile[10][0]+.17,profile[10][1]-.09)
    if i==5:
        profile[0]=(-1.15,.28);profile[1]=(-.66,.48)
    for j,((y,z),offset) in enumerate(zip(profile,offsets)):
        if i>=7 and j in range(5,11):
            t=(i-6)/3
            z=z*(1-t)+zs[min(7,3+(j-3)//2)]*t
        vertices.append((x+offset,y,z))
for i in range(6,10):
    a=Vector(vertices[i*R+3]);b=Vector(vertices[i*R+11])
    for j in range(4,11):
        p=Vector(vertices[i*R+j]);t=(j-3)/8
        p.y=a.y*(1-t)+b.y*t;p.z=a.z*(1-t)+b.z*t;vertices[i*R+j]=tuple(p)
for j in range(R):
    p=Vector(vertices[j]);p.x=-2.94+.18*p.z;vertices[j]=tuple(p)
    p=Vector(vertices[9*R+j]);p.x=2.84-.10*p.z;vertices[9*R+j]=tuple(p)
for j in range(4,R):
    p=Vector(vertices[R+j]);p.x=-2.40+.04*p.z;vertices[R+j]=tuple(p)
for j,z in [(6,.55),(7,.60)]:
    p=Vector(vertices[5*R+j]);p.z=z;vertices[5*R+j]=tuple(p)
faces=[];top_face_rows=[]
for i in range(len(stations)-1):
    for j in range(R-1):
        ids=(i*R+j,(i+1)*R+j,(i+1)*R+j+1,i*R+j+1)
        faces.append(ids);top_face_rows.append((i,j))

boundary=list(range(R)) + [i*R+R-1 for i in range(1,10)] + list(range(10*R-2,9*R-1,-1)) + [i*R for i in range(8,0,-1)]
top_count=len(faces)
middle=[];bottom=[]
for k,idx in enumerate(boundary):
    x,y,z=vertices[idx]
    center_y=-.01
    near=y<-.4
    middle.append(len(vertices))
    shift=[-.06,.05,-.03,.11,-.09,.03,.07,-.04][k%8]
    vertices.append((x*.975+shift,y*.96+shift*.25,-.32+(.10 if near else .04)+.065*math.sin(k*1.47)))
for k,idx in enumerate(boundary):
    x,y,z=vertices[idx]
    bottom.append(len(vertices))
    vertices.append((x*.87+.05,y*.79+.08,-.86))
for k,idx in enumerate(boundary):
    section=idx//R
    if section not in (0,9):continue
    p=Vector(vertices[middle[k]]);p.z=-.70 if section==0 else -.32
    p.x=-2.94+.18*p.z if section==0 else 2.84-.10*p.z;vertices[middle[k]]=tuple(p)
    p=Vector(vertices[bottom[k]]);p.x=-2.94+.18*p.z if section==0 else 2.84-.10*p.z;vertices[bottom[k]]=tuple(p)
for i in range(len(boundary)):
    j=(i+1)%len(boundary)
    if boundary[i]//R==boundary[j]//R and boundary[i]//R in (0,9):continue
    faces.extend([(boundary[i],middle[i],middle[j],boundary[j]),(middle[i],bottom[i],bottom[j],middle[j])])
for section in (0,9):
    a=boundary.index(section*R);b=boundary.index(section*R+R-1)
    faces.append(tuple(range(section*R,(section+1)*R))+(middle[b],bottom[b],bottom[a],middle[a]))
bottom_outline=[bottom[k] for k,v in enumerate(boundary) if v//R not in (0,9) or v%R in (0,R-1)]
faces.append(tuple(reversed(bottom_outline)))
used=sorted({v for face in faces for v in face});remap={v:i for i,v in enumerate(used)}
vertices=[vertices[v] for v in used];faces=[tuple(remap[v] for v in face) for face in faces]
body=mesh('Angular connected host',vertices,faces)
body['solid_role']='Connected substantial host, torn longitudinal opening'
attribute=body.data.attributes.new('GeologicalFace','INT','FACE')
for p in body.data.polygons:attribute.data[p.index].value=p.index
bm=bmesh.new();bm.from_mesh(body.data)
bmesh.ops.triangulate(bm,faces=list(bm.faces),quad_method='BEAUTY',ngon_method='BEAUTY')
bm.to_mesh(body.data);bm.free()

# Mineral faces are separate, thick-backed components fitted to the actual host surface.
def fitted(name, indices, mat, depth=.018, offset=.003):
    ids=set(indices)
    indices=[p.index for p in body.data.polygons if body.data.attributes['GeologicalFace'].data[p.index].value in ids]
    edges={}
    for fi in indices:
        loop=list(body.data.polygons[fi].vertices)
        for a,b in zip(loop,loop[1:]+loop[:1]):edges.setdefault(tuple(sorted((a,b))),[]).append(fi)
    remaining=set(indices);groups={};group=0
    while remaining:
        stack=[remaining.pop()]
        while stack:
            fi=stack.pop();groups[fi]=group;loop=list(body.data.polygons[fi].vertices)
            for a,b in zip(loop,loop[1:]+loop[:1]):
                for other in edges[tuple(sorted((a,b)))]:
                    if other in remaining:remaining.remove(other);stack.append(other)
        group+=1
    ids=sorted({(groups[fi],v) for fi in indices for v in body.data.polygons[fi].vertices})
    lookup={v:i for i,v in enumerate(ids)}
    normals={v:Vector() for v in ids}
    for fi in indices:
        p=body.data.polygons[fi]
        for v in p.vertices:normals[(groups[fi],v)]+=p.normal
    for n in normals.values():n.normalize()
    upper=[body.data.vertices[v[1]].co+normals[v]*offset for v in ids]
    lower=[body.data.vertices[v[1]].co-normals[v]*depth for v in ids]
    n=len(ids);polys=[];edges={}
    for fi in indices:
        source=list(body.data.polygons[fi].vertices)
        loop=[lookup[(groups[fi],v)] for v in source]
        polys.extend([tuple(loop),tuple(v+n for v in reversed(loop))])
        for a,b in zip(loop,loop[1:]+loop[:1]):edges.setdefault(tuple(sorted((a,b))),[]).append((a,b))
    for uses in edges.values():
        if len(uses)==1:
            a,b=uses[0];polys.append((b,a,a+n,b+n))
    if name in ('Broken green intermediate ledges','Unequal cream shoulder and crust remnants'):
        top=[body.data.vertices[v[1]].co.copy() for v in ids]
        top_faces=[tuple(lookup[(groups[fi],v)] for v in body.data.polygons[fi].vertices) for fi in indices]
        obj=mesh(name,top,top_faces,[mat]);obj['solid_role']='Constrained solid mineral skin with buried backing'
        mod=obj.modifiers.new('Constrained mineral thickness','SOLIDIFY');mod.solidify_mode='NON_MANIFOLD';mod.nonmanifold_thickness_mode='CONSTRAINTS';mod.thickness=.020;mod.offset=-.8;mod.use_even_offset=True
        bpy.context.view_layer.objects.active=obj;bpy.ops.object.modifier_apply(modifier=mod.name)
        return obj
    obj=mesh(name,upper+lower,polys,[mat]);obj['solid_role']='Fitted mineral component with buried backing'
    return obj

deep=[];medium=[];pale=[];crust=[]
for f,(i,j) in enumerate(top_face_rows):
    if j in (2,3,4,5) and i<8:
        (deep if j in (3,4) and i<5 else medium).append(f)
    if j==1 and i in (0,1,2,3,5,6):pale.append(f)
    if j==6 and i in (0,1,2,3,4,6):pale.append(f)
    if j==7 and i in (0,1,2,3,4,6):medium.append(f)
    if j in (8,9,10,11) and i in (0,1,2):crust.append(f)
    if (i,j) in [(3,9),(3,10),(4,7),(4,6),(5,11),(7,1),(6,0)]:crust.append(f)
fitted('Deep green shear interior',deep,jade)
fitted('Broken green intermediate ledges',medium,green)
fitted('Pale mineral laminae',pale,pale_green)
fitted('Unequal cream shoulder and crust remnants',crust,cream,.018)

# Exposed deposits stay within individual geological faces.
for n,fi in enumerate([3*12+10,4*12+10,5*12+8,4*12,6*12]):
    face=max((p for p in body.data.polygons if body.data.attributes['GeologicalFace'].data[p.index].value==fi),key=lambda p:p.area)
    p=[body.data.vertices[v].co.copy() for v in face.vertices]
    a=p[0]*.55+p[1]*.35+p[2]*.10
    b=p[0]*.25+p[1]*.20+p[2]*.55
    side=(p[1]-p[0]).normalized()
    points=[a-side*.04,a+side*.06,a.lerp(b,.42)+side*.09,b+side*.04,b-side*.03,a.lerp(b,.6)-side*.05]
    normal=face.normal
    obj=mesh('Ochre fracture deposit '+str(n+1),[v+normal*.012 for v in points]+[v-normal*.04 for v in points],[tuple(range(6)),tuple(range(11,5,-1))]+[(i,(i+1)%6,(i+1)%6+6,i+6) for i in range(6)],[ochre])
    obj['solid_role']='Near-flush ochre deposit'

for obj in parts.objects:
    if obj.type!='MESH':continue
    bm=bmesh.new();bm.from_mesh(obj.data)
    bmesh.ops.triangulate(bm,faces=list(bm.faces),quad_method='BEAUTY',ngon_method='BEAUTY')
    bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(obj.data);bm.free()
    bpy.ops.object.select_all(action='DESELECT');obj.select_set(True);bpy.context.view_layer.objects.active=obj
    bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.uv.smart_project(angle_limit=math.radians(48),island_margin=.035)
    bpy.ops.object.mode_set(mode='OBJECT');obj.data.uv_layers.active.name='MineralAtlasUV'

scene.render.engine='CYCLES';scene.cycles.samples=24;scene.cycles.use_denoising=True
scene.render.resolution_x=900;scene.render.resolution_y=650;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG';scene.render.image_settings.color_mode='RGBA';scene.render.film_transparent=True
scene.world=bpy.data.worlds.new('Neutral review world');scene.world.use_nodes=True
scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.24,.26,.30,1)
scene.world.node_tree.nodes['Background'].inputs[1].default_value=.45
scene.view_settings.view_transform='AgX';scene.view_settings.look='AgX - Medium High Contrast'
for name,location,power,size in [('Key',(-3,-4,8),950,4),('Fill',(4,-2,4),300,5),('Rear',(1,5,6),450,4)]:
    d=bpy.data.lights.new(name,'AREA');d.energy=power;d.shape='DISK';d.size=size
    o=bpy.data.objects.new(name,d);review.objects.link(o);o.location=location;o.rotation_euler=(-o.location).to_track_quat('-Z','Y').to_euler()
d=bpy.data.cameras.new('Orthographic reference camera');d.type='ORTHO';d.ortho_scale=7.7
camera=bpy.data.objects.new('Orthographic reference camera',d);review.objects.link(camera);scene.camera=camera
def aim(direction):
    target=Vector((0,0,.4));camera.location=target+Vector(direction).normalized()*12
    camera.rotation_euler=(target-camera.location).to_track_quat('-Z','Y').to_euler()
def render(name):
    scene.render.filepath=str(OUT/(name+'.png'));bpy.ops.render.render(write_still=True);print('RENDER='+scene.render.filepath,flush=True)
aim((-4.4,-8,5.5))
scene['review_status']='Geometry construction proof; paint not yet applied'
scene['reference']='../references/verdant-painted-target.png'
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'verdant-clay.blend'))
if '--check-only' in sys.argv:sys.exit(0)
bpy.context.view_layer.material_override=clay;render('verdant-clay-hero')
bpy.context.view_layer.material_override=None;render('verdant-zones-hero')
aim((4,7,5));bpy.context.view_layer.material_override=clay;render('verdant-clay-reverse')
aim((7,-1,3.8));render('verdant-clay-side')
print('GEOMETRY_PROOF_COMPLETE',flush=True)
