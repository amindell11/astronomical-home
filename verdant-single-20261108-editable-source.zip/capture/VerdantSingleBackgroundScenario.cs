#if UNITY_EDITOR
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Cameras;
using Capture.Recording;
using Capture.Views;
using NUnit.Framework;
using Substrate;
using Substrate.Services.Locales;
using Substrate.Sessions;
using Tests.PlayMode.Common;
using Tests.PlayMode.Recording;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
using Object = UnityEngine.Object;

public sealed class VerdantSingleBackgroundScenario : CaptureScenario
{
    private const string Assets = "Assets/Visuals/Environment/Asteroids/VerdantSingleReview";
    private readonly List<Material> ownedMaterials = new();
    private readonly List<CapturedView> captured = new();
    public override bool NeedsSession => false;
    public override GizmoCaptureProfile Profile => GizmoCaptureProfile.None;

    public override IEnumerator Run()
    {
        var catalog = JsonUtility.FromJson<ExportCatalog>(File.ReadAllText(Assets + "/export-catalog.json"));
        Assert.That(catalog.models.Length, Is.EqualTo(1));
        Import(catalog);
        var calibration = Object.Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>(Assets + "/" + catalog.orientation_basis));
        var basis = calibration.AddComponent<OrientationBasis>();
        var axisX = basis.X;
        var axisY = basis.Y;
        var axisZ = basis.Z;
        Object.DestroyImmediate(calibration);
        var model = catalog.models[0];
        var materials = catalog.materials.ToDictionary(m => m.key, MakeMaterial);
        var contourSource = AssetDatabase.LoadAssetAtPath<Material>("Assets/Visuals/Vfx/LayeredExplosion/Materials/AsteroidContour.mat");
        Assert.IsNotNull(contourSource);
        var contour = new Material(contourSource) { name = "Verdant variable review contour" };
        contour.SetFloat("_ContourPixels", 3.2f);
        contour.SetFloat("_ContourMinimum", .45f);
        contour.SetFloat("_UniformWidth", .4f);
        ownedMaterials.Add(contour);
        var root = new GameObject("Verdant single background comparison");
        var session = TestSession.Create(root, new SessionProfile
        {
            presentation = true,
            idleLocale = AssetDatabase.LoadAssetAtPath<LocaleSky>("Assets/Prefabs/Locales/Locale_6.prefab")
        });
        var savedTimeScale = Time.timeScale;
        try
        {
            yield return session.Compose();
            AddReviewLighting(root.transform);
            var backdrop = root.AddComponent<BackdropReview>();
            backdrop.Initialize();
            var observer = TestAssets.NewObserverCam();
            observer.transform.SetParent(root.transform, false);
            var pilotRoot = new GameObject("Stationary scale pilot");
            pilotRoot.transform.SetParent(root.transform, false);
            var pilot = pilotRoot.AddComponent<JumpTestCommander>();
            var ship = session.Units.SpawnShip(TestAssets.LoadCrimsonPrefab(), pilot, 0,
                session.Frame.Place(new Vector2(-.3f, -1.4f)), GamePlane.Rotation, null);
            observer.SetSubject(ship.transform);
            var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(Assets + "/" + model.fbx);
            Assert.IsNotNull(prefab, model.fbx);
            var rock = Object.Instantiate(prefab, root.transform);
            rock.name = model.id;
            var rig = rock.AddComponent<PreviewRig>();
            rig.Initialize(model, materials, contour);
            rock.transform.position = session.Frame.Place(new Vector2(3.5f, 1f));
            var sourceView = axisX * model.source_view[0] + axisY * model.source_view[1] + axisZ * model.source_view[2];
            var sourceUp = axisX * model.source_up[0] + axisY * model.source_up[1] + axisZ * model.source_up[2];
            var pose = Quaternion.LookRotation(Vector3.back, Vector3.up) * Quaternion.Inverse(Quaternion.LookRotation(sourceView, sourceUp));
            Assert.That(Vector3.Dot(pose * sourceView.normalized, Vector3.back), Is.GreaterThan(.999f));
            rock.transform.rotation = pose;
            rock.transform.localScale = Vector3.one;
            yield return new WaitForSecondsRealtime(.5f);
            Time.timeScale = 0f;
            var cameras = new Dictionary<string, (Vector3 position, Quaternion rotation, float zoom)>();
            using (var view = (IDisposable)Capture.GetType().GetMethod("PrepareGameTopdown").Invoke(Capture, new object[] { observer }))
            {
                foreach (var muted in new[] { false, true })
                {
                    backdrop.SetMuted(muted);
                    foreach (var framing in new[] { "flight", "close", "rotation" })
                    {
                        var zoom = framing == "flight" ? 15f : 5.4f;
                        var center = framing == "flight" ? Vector2.zero : new Vector2(1.4f, .4f);
                        observer.SetManualCenter(center);
                        observer.SetManualZoom(zoom);
                        observer.enabled = true;
                        rock.transform.rotation = pose;
                        yield return new WaitForSecondsRealtime(1.4f);
                        observer.enabled = false;
                        if (!muted) cameras.Add(framing, (observer.Cam.transform.position, observer.Cam.transform.rotation, observer.Cam.orthographicSize));
                        var fixedCamera = cameras[framing];
                        observer.Cam.transform.SetPositionAndRotation(fixedCamera.position, fixedCamera.rotation);
                        observer.Cam.orthographicSize = fixedCamera.zoom;
                        var label = $"verdant-single-{(muted ? "muted" : "original")}-{framing}";
                        var angle = 0f;
                        var pitch = 0f;
                        using var recording = Capture.Prepare(new CaptureRequest("results/capture", label, Commit, 1280, 720,
                            measurements: new Dictionary<string, Func<double>>
                            {
                                ["background_muted"] = () => muted ? 1 : 0,
                                ["observer_zoom"] = () => observer.Cam.orthographicSize,
                                ["asteroid_yaw"] = () => angle,
                                ["asteroid_tilt"] = () => pitch,
                                ["frozen_shader_time"] = () => Time.time
                            }));
                        yield return recording.Ready;
                        recording.Start();
                        var count = framing == "rotation" ? 180 : 10;
                        for (var frame = 0; frame < count; frame++)
                        {
                            var phase = framing == "rotation" ? frame / (count - 1f) : 0f;
                            angle = 65f * Mathf.Sin(phase * Mathf.PI * 2f);
                            pitch = 15f * Mathf.Sin(phase * Mathf.PI);
                            rock.transform.rotation = Quaternion.AngleAxis(pitch, Vector3.right) * Quaternion.AngleAxis(angle, Vector3.up) * pose;
                            yield return null;
                        }
                        Result = recording.Finish();
                        Assert.That(Result.FrameCount, Is.GreaterThan(1));
                        AssertPixels(Result.FrameDirectory);
                        captured.Add(new CapturedView
                        {
                            background = muted ? "muted" : "original",
                            framing = framing, zoom = zoom, frame_directory = Result.FrameDirectory,
                            model = model.id, frozen_time = Time.time, frame_count = Result.FrameCount,
                            camera_position = observer.Cam.transform.position,
                            asteroid_position = rock.transform.position,
                            ship_position = ship.transform.position,
                            recommended_playback_fps = 24
                        });
                    }
                }
            }
            foreach (var pair in captured.GroupBy(v => v.framing))
            {
                var a = pair.First();
                var b = pair.Last();
                Assert.That(a.camera_position, Is.EqualTo(b.camera_position), pair.Key);
                Assert.That(a.asteroid_position, Is.EqualTo(b.asteroid_position), pair.Key);
                Assert.That(a.ship_position, Is.EqualTo(b.ship_position), pair.Key);
                Assert.That(a.frozen_time, Is.EqualTo(b.frozen_time), pair.Key);
            }
            Time.timeScale = savedTimeScale;
            yield return session.Teardown();
            var output = Path.GetFullPath(Path.Combine(Application.dataPath, "../../..", "results/capture/verdant-single-background-index.json"));
            File.WriteAllText(output, JsonUtility.ToJson(new CaptureIndex
            {
                lighting = "Actual game camera and Verdant backdrop with neutral review lighting, new painted material gain 1",
                comparison = "A original RGB; B saturation 0.82, contrast 0.88 around linear 0.08, background only. Backdrop motion and shader clock frozen identically.",
                contour = "Joined contour-only normals, 3.2px, minimum0.45, uniform0.4; surface normals unchanged",
                views = captured.ToArray()
            }, true));
            Debug.Log("VERDANT_SINGLE_INDEX=" + output);
        }
        finally
        {
            Time.timeScale = savedTimeScale;
            Object.DestroyImmediate(root);
            foreach (var material in ownedMaterials) Object.DestroyImmediate(material);
        }
    }

    public sealed class BackdropReview : MonoBehaviour
    {
        private Renderer[] layers;
        private readonly List<(Renderer layer, Material original, Material clone)> replacements = new();
        private void Awake()
        {
            layers = Object.FindObjectsByType<Renderer>(FindObjectsInactive.Exclude, FindObjectsSortMode.None)
                .Where(r => r.enabled && r.sharedMaterial && (r.sharedMaterial.shader.name == "Locales/Planet" || r.sharedMaterial.shader.name == "Custom/Nebula")).ToArray();
        }
        public void Initialize()
        {
            Assert.That(layers.Length, Is.GreaterThan(0));
            foreach (var layer in layers)
            {
                var original = layer.sharedMaterial;
                var isPlanet = original.shader.name == "Locales/Planet";
                var foreground = !isPlanet && original.GetFloat("_NebulaForeground") > .5f;
                var shader = foreground ? original.shader
                    : AssetDatabase.LoadAssetAtPath<Shader>(Assets + "/Backdrop/" + (isPlanet ? "PlanetReview.shader" : "NebulaReview.shader"));
                Assert.IsNotNull(shader);
                var clone = new Material(shader) { name = original.name + " background review" };
                var expectedShader = foreground ? original.shader.name : "Review/Verdant/" + (isPlanet ? "Planet" : "Nebula");
                Assert.That(clone.shader.name, Is.EqualTo(expectedShader), clone.name + " before value copy");
                if (!foreground) Assert.IsTrue(clone.HasProperty("_ReviewMuted"), clone.name + " before value copy");
                for (var i = 0; i < original.shader.GetPropertyCount(); i++)
                {
                    var property = original.shader.GetPropertyName(i);
                    Assert.IsTrue(clone.HasProperty(property), clone.name + " missing " + property);
                    switch (original.shader.GetPropertyType(i))
                    {
                        case ShaderPropertyType.Float:
                        case ShaderPropertyType.Range:
                            clone.SetFloat(property, original.GetFloat(property));
                            break;
                        case ShaderPropertyType.Int:
                            clone.SetInteger(property, original.GetInteger(property));
                            break;
                        case ShaderPropertyType.Color:
                            clone.SetColor(property, original.GetColor(property));
                            break;
                        case ShaderPropertyType.Vector:
                            clone.SetVector(property, original.GetVector(property));
                            break;
                        case ShaderPropertyType.Texture:
                            clone.SetTexture(property, original.GetTexture(property));
                            clone.SetTextureScale(property, original.GetTextureScale(property));
                            clone.SetTextureOffset(property, original.GetTextureOffset(property));
                            break;
                        default:
                            throw new InvalidOperationException("Unsupported backdrop property type: " + property);
                    }
                }
                clone.shaderKeywords = original.shaderKeywords;
                clone.renderQueue = original.renderQueue;
                Assert.That(clone.shader, Is.EqualTo(shader));
                Assert.That(clone.shader.name, Is.EqualTo(expectedShader), clone.name + " after value copy");
                if (!foreground) Assert.IsTrue(clone.HasProperty("_ReviewMuted"), clone.name + " after value copy");
                clone.SetFloat(isPlanet ? "_RotationSpeed" : "_NebulaSpeed", 0f);
                layer.sharedMaterial = clone;
                replacements.Add((layer, original, clone));
            }
        }
        public void SetMuted(bool muted)
        {
            foreach (var entry in replacements)
                if (entry.clone.HasProperty("_ReviewMuted")) entry.clone.SetFloat("_ReviewMuted", muted ? 1f : 0f);
        }
        private void OnDestroy()
        {
            foreach (var entry in replacements)
            {
                if (entry.layer) entry.layer.sharedMaterial = entry.original;
                Object.DestroyImmediate(entry.clone);
            }
        }
    }

    [Serializable] private sealed class CapturedView
    {
        public string background;
        public string framing;
        public float zoom;
        public string frame_directory;
        public string model;
        public float frozen_time;
        public int frame_count;
        public Vector3 camera_position;
        public Vector3 asteroid_position;
        public Vector3 ship_position;
        public int recommended_playback_fps;
    }
    [Serializable] private sealed class CaptureIndex
    {
        public string lighting;
        public string comparison;
        public string contour;
        public CapturedView[] views;
    }

    private static void AddReviewLighting(Transform parent)
    {
        var keyRoot = new GameObject("Neutral asteroid review key");
        keyRoot.transform.SetParent(parent, false);
        keyRoot.transform.rotation = Quaternion.LookRotation(new Vector3(.38f, -.52f, .82f));
        var key = keyRoot.AddComponent<Light>();
        key.type = LightType.Directional;
        key.color = Color.white;
        key.intensity = 1.15f;
        key.shadows = LightShadows.Soft;
        key.shadowStrength = .65f;
        key.shadowBias = .04f;
        key.shadowNormalBias = .15f;
        RenderSettings.sun = key;
        RenderSettings.ambientMode = AmbientMode.Custom;
        RenderSettings.ambientIntensity = 1f;
        var probe = new SphericalHarmonicsL2();
        probe.AddAmbientLight(new Color(.55f, .55f, .55f));
        RenderSettings.ambientProbe = probe;
        Debug.Log("REVIEW_LIGHTING key=white,1.15 direction=(-.38,.52,-.82) SH=neutral,.55 shadowTint=(.56,.58,.62) threshold=.15");
    }

    private static void Import(ExportCatalog catalog)
    {
        foreach (var path in catalog.models.Select(m => m.fbx).Append(catalog.orientation_basis))
        {
            var importer = (ModelImporter)AssetImporter.GetAtPath(Assets + "/" + path);
            Assert.IsNotNull(importer, path);
            importer.globalScale = 1f;
            importer.useFileScale = true;
            importer.bakeAxisConversion = true;
            importer.importAnimation = false;
            importer.importCameras = false;
            importer.importLights = false;
            importer.isReadable = true;
            importer.materialImportMode = ModelImporterMaterialImportMode.None;
            importer.importNormals = ModelImporterNormals.Import;
            importer.importTangents = ModelImporterTangents.CalculateMikk;
            importer.SaveAndReimport();
        }
        foreach (var material in catalog.materials.Where(m => !string.IsNullOrEmpty(m.paint_path)))
        {
            var importer = (TextureImporter)AssetImporter.GetAtPath(Assets + "/" + material.paint_path);
            importer.sRGBTexture = true;
            importer.textureType = TextureImporterType.Default;
            importer.wrapMode = TextureWrapMode.Repeat;
            importer.maxTextureSize = 2048;
            importer.textureCompression = TextureImporterCompression.Uncompressed;
            importer.SaveAndReimport();
        }
    }

    private Material MakeMaterial(ExportMaterial data)
    {
        var template = AssetDatabase.LoadAssetAtPath<Material>(string.IsNullOrEmpty(data.paint_path)
            ? "Assets/Visuals/Environment/Asteroids/DrawnField/FieldGraphite.mat"
            : "Assets/Visuals/Environment/Asteroids/DrawnField/Shape01/Asteroid1Paint.mat");
        var material = new Material(template) { name = data.key };
        material.DisableKeyword("_NORMALMAP");
        material.DisableKeyword("_PAINT_LAYERS");
        material.DisableKeyword("_LIGHT_DRIVEN_PAINT");
        material.SetFloat("_UseRelief", 0f);
        material.SetFloat("_LineStrength", 0f);
        material.SetFloat("_WearStrength", 0f);
        material.SetFloat("_SpecularStrength", 0f);
        material.SetFloat("_SootStrength", 0f);
        material.SetFloat("_EmissionStrength", 0f);
        const float gain = 1f;
        material.SetColor("_BaseColor", new Color(data.color[0] * gain, data.color[1] * gain, data.color[2] * gain, data.color[3]));
        material.SetColor("_PaperColor", Color.white);
        material.SetFloat("_AmbientStrength", 1f);
        material.SetFloat("_ShadowThreshold", .15f);
        material.SetFloat("_ShadowSoftness", .16f);
        material.SetFloat("_CastShadowStrength", .55f);
        material.SetColor("_ShadowColor", new Color(.56f, .58f, .62f, 1f));
        material.SetTexture("_BaseMap", string.IsNullOrEmpty(data.paint_path) ? Texture2D.whiteTexture
            : AssetDatabase.LoadAssetAtPath<Texture2D>(Assets + "/" + data.paint_path));
        material.SetFloat("_TextureStrength", string.IsNullOrEmpty(data.paint_path) ? 0f : 1f);
        ownedMaterials.Add(material);
        return material;
    }

    private static void AssertPixels(string folder)
    {
        var paths = Directory.GetFiles(folder, "*.png").OrderBy(p => p).ToArray();
        var image = new Texture2D(2, 2);
        try
        {
            Assert.IsTrue(image.LoadImage(File.ReadAllBytes(paths[paths.Length / 2])));
            var colors = new HashSet<Color32>();
            var pixels = image.GetPixels32();
            for (var y = 180; y < 540; y += 3)
            for (var x = 160; x < 1120; x += 3) colors.Add(pixels[y * image.width + x]);
            Assert.That(colors.Count, Is.GreaterThan(100), "Game View must contain rendered scene content.");
        }
        finally { Object.DestroyImmediate(image); }
    }

    public sealed class PreviewRig : MonoBehaviour
    {
        private Dictionary<string, MeshRenderer> renderers;
        private Dictionary<string, MeshFilter> filters;
        private readonly List<Mesh> contourMeshes = new();
        private void Awake()
        {
            renderers = GetComponentsInChildren<MeshRenderer>(true).ToDictionary(r => r.name);
            filters = GetComponentsInChildren<MeshFilter>(true).ToDictionary(f => f.name);
        }
        public void Initialize(ExportModel model, Dictionary<string, Material> materials, Material contour)
        {
            Assert.That(renderers.Count, Is.EqualTo(model.parts.Length), model.id);
            foreach (var part in model.parts)
            {
                var renderer = renderers[part.name];
                var mesh = filters[part.name].sharedMesh;
                Assert.That(mesh.vertexCount, Is.GreaterThan(0));
                Assert.That(mesh.subMeshCount, Is.EqualTo(part.materials.Length), model.id + " " + part.name);
                renderer.sharedMaterials = part.materials.Select(key => materials[key]).ToArray();
                renderer.shadowCastingMode = part.ink ? ShadowCastingMode.Off : ShadowCastingMode.On;
                if (!part.contour) continue;
                var shell = new GameObject(part.name + " contour");
                shell.transform.SetParent(renderer.transform, false);
                var contourMesh = JoinedContour(mesh);
                contourMeshes.Add(contourMesh);
                shell.AddComponent<MeshFilter>().sharedMesh = contourMesh;
                var outline = shell.AddComponent<MeshRenderer>();
                outline.sharedMaterials = Enumerable.Repeat(contour, mesh.subMeshCount).ToArray();
                outline.shadowCastingMode = ShadowCastingMode.Off;
                outline.receiveShadows = false;
            }
        }
        private static Mesh JoinedContour(Mesh source)
        {
            var positions = source.vertices;
            var normals = source.normals;
            var uv = source.uv;
            Assert.That(normals.Length, Is.EqualTo(positions.Length));
            Assert.That(uv.Length, Is.EqualTo(positions.Length));
            var sums = new Dictionary<Vector3, Vector3>();
            var distinct = new HashSet<(Vector3 position, Vector3 normal, Vector2 uv)>();
            for (var i = 0; i < positions.Length; i++)
            {
                if (!distinct.Add((positions[i], normals[i], uv[i]))) continue;
                sums.TryGetValue(positions[i], out var sum);
                sums[positions[i]] = sum + normals[i];
            }
            for (var i = 0; i < positions.Length; i++)
            {
                Assert.That(sums[positions[i]].sqrMagnitude, Is.GreaterThan(.000001f), source.name);
                normals[i] = sums[positions[i]].normalized;
            }
            var result = Object.Instantiate(source);
            result.name = source.name + " joined contour normals";
            result.normals = normals;
            return result;
        }

        private void OnDestroy()
        {
            foreach (var mesh in contourMeshes) Object.DestroyImmediate(mesh);
        }
    }

    public sealed class OrientationBasis : MonoBehaviour
    {
        public Vector3 X { get; private set; }
        public Vector3 Y { get; private set; }
        public Vector3 Z { get; private set; }
        private void Awake()
        {
            var markers = GetComponentsInChildren<MeshRenderer>().ToDictionary(r => r.name, r => r.bounds.center);
            var origin = markers["AxisOrigin"];
            X = (markers["AxisX"] - origin).normalized;
            Y = (markers["AxisY"] - origin).normalized;
            Z = (markers["AxisZ"] - origin).normalized;
        }
    }

    [Serializable] public sealed class ExportCatalog { public ExportModel[] models; public ExportMaterial[] materials; public string orientation_basis; }
    [Serializable] public sealed class ExportModel { public string id; public string family; public int locale; public string fbx; public ExportPart[] parts; public float[] source_view; public float[] source_up; }
    [Serializable] public sealed class ExportPart { public string name; public string source_name; public bool ink; public bool contour; public string[] materials; }
    [Serializable] public sealed class ExportMaterial { public string key; public string source_name; public string review_role; public string paint_path; public float[] color; }
}
#endif
