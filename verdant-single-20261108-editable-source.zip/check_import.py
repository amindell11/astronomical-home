"""Reimport the actual FBX, compare material slots/UV geometry, and render that import."""
from pathlib import Path
import bpy,json,hashlib,itertools
from mathutils import Vector
from mathutils.kdtree import KDTree
ROOT=Path(__file__).resolve().parent
catalog=json.loads((ROOT/'export/export-catalog.json').read_text());model=catalog['models'][0]
source=ROOT/'model/verdant-painted.blend'
assert hashlib.sha256(source.read_bytes()).hexdigest()==model['source_sha256']
bpy.ops.wm.open_mainfile(filepath=str(source));scene=bpy.context.scene
def signature(obj):
    data=obj.data;data.calc_loop_triangles();uv=data.uv_layers[0]
    triangles=[]
    for tri in data.loop_triangles:
        corners=[]
        for loop in tri.loops:
            p=obj.matrix_world@data.vertices[data.loops[loop].vertex_index].co
            t=uv.data[loop].uv
            corners.append(tuple(p)+tuple(t))
        triangles.append(tuple(corners))
    return triangles
position_tolerance=.00005
uv_tolerance=.00002
def compare(expected,actual):
    assert len(expected)==len(actual),(len(expected),len(actual))
    tree=KDTree(len(expected))
    for i,tri in enumerate(expected):tree.insert(sum((Vector(v[:3]) for v in tri),Vector())/3,i)
    tree.balance();used=set();maximum_position=0;maximum_uv=0
    for tri in actual:
        center=sum((Vector(v[:3]) for v in tri),Vector())/3
        matches=[]
        for _,index,_ in tree.find_range(center,position_tolerance*2):
            if index in used:continue
            for order in itertools.permutations(tri):
                p=max((Vector(a[:3])-Vector(b[:3])).length for a,b in zip(expected[index],order))
                uv=max((Vector(a[3:])-Vector(b[3:])).length for a,b in zip(expected[index],order))
                if p<=position_tolerance and uv<=uv_tolerance:matches.append((p+uv,index,p,uv))
        assert matches,('No matching imported triangle',list(center),tri)
        _,index,p,uv=min(matches);used.add(index);maximum_position=max(maximum_position,p);maximum_uv=max(maximum_uv,uv)
    return maximum_position,maximum_uv
expected={part['name']:signature(bpy.data.objects[part['source_name']]) for part in model['parts']}
for obj in scene.objects:
    if obj.type=='MESH':obj.hide_render=True
before=set(bpy.data.objects)
bpy.ops.import_scene.fbx(filepath=str(ROOT/'export'/model['fbx']))
imported={o.name:o for o in set(bpy.data.objects)-before if o.type=='MESH'}
materials={m['key']:m for m in catalog['materials']}
checks=[]
for part in model['parts']:
    obj=imported[part['name']];actual=signature(obj)
    expected_keys=part['materials'];got=[m.name for m in obj.data.materials]
    assert got==expected_keys,(part['name'],got,expected_keys)
    maximum_position,maximum_uv=compare(expected[part['name']],actual)
    checks.append({'part':part['name'],'source_name':part['source_name'],'triangle_count':len(actual),'geometry_and_uv_match':True,'materials_match':True,'maximum_position_error':maximum_position,'maximum_uv_error':maximum_uv})
    for material,key in zip(obj.data.materials,expected_keys):
        data=materials[key];material.use_nodes=True
        p=material.node_tree.nodes.get('Principled BSDF');p.inputs['Roughness'].default_value=.94;p.inputs['Specular IOR Level'].default_value=.12
        if data['paint_path']:
            texture=material.node_tree.nodes.new('ShaderNodeTexImage');texture.image=bpy.data.images.load(str(ROOT/'export'/data['paint_path']))
            material.node_tree.links.new(texture.outputs['Color'],p.inputs['Base Color'])
        else:p.inputs['Base Color'].default_value=data['color']
scene.render.resolution_x=900;scene.render.resolution_y=650
scene.render.filepath=str(ROOT/'model/verdant-fbx-reimport.png');bpy.ops.render.render(write_still=True)
assert hashlib.sha256(source.read_bytes()).hexdigest()==model['source_sha256']
(ROOT/'import-check.json').write_text(json.dumps({'verdict':'PASS','source_sha256':model['source_sha256'],'fbx_sha256':hashlib.sha256((ROOT/'export'/model['fbx']).read_bytes()).hexdigest(),'position_tolerance':position_tolerance,'uv_tolerance':uv_tolerance,'parts':checks,'appearance_proof':'model/verdant-fbx-reimport.png'},indent=2))
print('IMPORT_CHECK_PASS',flush=True)
