"""Inspect the observed folded far end without modifying the frozen source."""
import bpy,json,sys
from pathlib import Path
from mathutils.bvhtree import BVHTree
from mathutils.geometry import intersect_ray_tri
ROOT=Path(__file__).resolve().parent
source=ROOT/(sys.argv[sys.argv.index('--source')+1] if '--source' in sys.argv else 'model/verdant-painted.blend')
bpy.ops.wm.open_mainfile(filepath=str(source))
host=bpy.data.objects['Angular connected host']
host_tree=BVHTree.FromObject(host,bpy.context.evaluated_depsgraph_get())
report=[]
for obj in bpy.context.scene.objects:
    if obj.type!='MESH' or obj.get('intentional_open_ribbon'):continue
    data=obj.data;tree=BVHTree.FromPolygons([v.co for v in data.vertices],[list(p.vertices) for p in data.polygons],all_triangles=True,epsilon=0)
    pairs=[];contacts=[]
    neighbors={v.index:set() for v in data.vertices}
    for edge in data.edges:
        a,b=edge.vertices;neighbors[a].add(b);neighbors[b].add(a)
    remaining=set(neighbors);components={};component=0
    while remaining:
        stack=[remaining.pop()]
        while stack:
            v=stack.pop();components[v]=component
            for other in neighbors[v]:
                if other in remaining:remaining.remove(other);stack.append(other)
        component+=1
    for a,b in tree.overlap(tree):
        if a>=b or set(data.polygons[a].vertices)&set(data.polygons[b].vertices):continue
        triangles=[[data.vertices[v].co for v in data.polygons[i].vertices] for i in (a,b)]
        crosses=False;points=[]
        for tri,other in [(triangles[0],triangles[1]),(triangles[1],triangles[0])]:
            for p,q in zip(tri,tri[1:]+tri[:1]):
                direction=q-p
                hit=intersect_ray_tri(*other,direction,p,True)
                if hit is not None:
                    t=(hit-p).dot(direction)/direction.length_squared
                    if 1e-5<t<1-1e-5:crosses=True;points.append(hit)
        if not crosses:continue
        signed=[]
        for point in points:
            hit,normal,_,_=host_tree.find_nearest(point);signed.append((point-hit).dot(normal))
        same=components[data.polygons[a].vertices[0]]==components[data.polygons[b].vertices[0]]
        (pairs if same else contacts).append({'faces':[a,b],'vertices':[list(data.polygons[a].vertices),list(data.polygons[b].vertices)],'centers':[list(data.polygons[a].center),list(data.polygons[b].center)],'crossing_signed_distance_from_host':signed})
    report.append({'object':obj.name,'nonadjacent_self_intersections':pairs,'contacts_between_closed_components':contacts})
output=ROOT/(sys.argv[sys.argv.index('--report')+1] if '--report' in sys.argv else 'far-end-inspection.json')
output.write_text(json.dumps(report,indent=2))
print(json.dumps(report))
if '--assert-clean' in sys.argv:assert not any(o['nonadjacent_self_intersections'] for o in report),'Actual triangle crossings remain'
