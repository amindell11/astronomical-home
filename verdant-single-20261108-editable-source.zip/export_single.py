"""Export only this painted review source and exact baked albedo for the scratch Unity scenario.

Blender CLI. Source bytes are never saved. Outputs export/export-catalog.json, models and paint.
"""
from pathlib import Path
import bpy,bmesh,json,hashlib,shutil
from mathutils import Vector
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'model/verdant-painted.blend'
OUT=ROOT/'export';(OUT/'models').mkdir(parents=True,exist_ok=True);(OUT/'paint').mkdir(exist_ok=True)
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before=digest(SOURCE)
bpy.ops.wm.open_mainfile(filepath=str(SOURCE))
objects=sorted([o for o in bpy.context.scene.objects if o.type=='MESH' and not o.hide_render],key=lambda o:o.name)
materials=[];parts=[];checks=[]
for index,obj in enumerate(objects):
    original=obj.name;ink=bool(obj.get('intentional_open_ribbon'))
    used=sorted({p.material_index for p in obj.data.polygons})
    assert len(used)==1,(original,used)
    mat=obj.data.materials[used[0]].copy()
    obj.data.materials.clear();obj.data.materials.append(mat)
    for p in obj.data.polygons:p.material_index=0
    bm=bmesh.new();bm.from_mesh(obj.data)
    remaining=set(bm.verts);volumes=[]
    while remaining:
        start=remaining.pop();stack=[start];group={start}
        while stack:
            v=stack.pop()
            for edge in v.link_edges:
                n=edge.other_vert(v)
                if n in remaining:remaining.remove(n);group.add(n);stack.append(n)
        faces={f for v in group for f in v.link_faces}
        volume=0
        for f in faces:
            a=f.verts[0].co
            for j in range(1,len(f.verts)-1):volume+=a.dot(f.verts[j].co.cross(f.verts[j+1].co))/6
        volumes.append(volume)
    stats={'name':original,'ink':ink,'boundary_edges':sum(e.is_boundary for e in bm.edges),'nonmanifold_edges':sum(not e.is_manifold for e in bm.edges),'zero_area_faces':sum(f.calc_area()<1e-10 for f in bm.faces),'signed_volumes':volumes,'uv_layers':[u.name for u in obj.data.uv_layers]}
    assert stats['zero_area_faces']==0,(original,stats)
    if not ink:
        assert stats['boundary_edges']==0 and stats['nonmanifold_edges']==0 and min(volumes)>0,(original,stats)
    if original=='Angular connected host':assert len(volumes)==1
    assert obj.data.uv_layers[0].name=='MineralAtlasUV',original
    checks.append(stats);bm.free()
    key='V_%02d'%index
    p=mat.node_tree.nodes.get('Principled BSDF')
    textures=[n.image for n in mat.node_tree.nodes if n.type=='TEX_IMAGE' and n.image]
    data={'key':key,'source_name':mat.name,'review_role':mat.get('review_role','ink' if ink else 'surface'),'paint_path':'','color':list(p.inputs['Base Color'].default_value)}
    if textures:
        assert len(textures)==1
        image=textures[0];assert image.packed_file is not None,original
        original_texture=ROOT/'model'/image.filepath.removeprefix('//')
        target=OUT/'paint'/original_texture.name;shutil.copy2(original_texture,target)
        data.update(paint_path='paint/'+target.name,color=[1,1,1,1],paint_sha256=digest(target),dimensions=list(image.size))
    materials.append(data)
    matrix=obj.matrix_world.copy();obj.parent=None;obj.matrix_world=matrix;obj.name='part_%03d'%index;mat.name=key
    parts.append({'name':obj.name,'source_name':original,'ink':ink,'contour':original=='Angular connected host','materials':[key]})
camera=bpy.context.scene.camera.matrix_world.to_quaternion()
bpy.ops.object.select_all(action='DESELECT')
for obj in objects:obj.hide_set(False);obj.select_set(True)
fbx=OUT/'models/verdant-single.fbx'
bpy.ops.export_scene.fbx(filepath=str(fbx),use_selection=True,object_types={'MESH'},use_mesh_modifiers=True,mesh_smooth_type='OFF',add_leaf_bones=False,bake_anim=False,path_mode='STRIP',axis_forward='-Z',axis_up='Y',global_scale=1,apply_unit_scale=True)
assert digest(SOURCE)==before
model={'id':'verdant-single','family':'verdant','locale':6,'fbx':'models/'+fbx.name,'source_sha256':before,'fbx_sha256':digest(fbx),'parts':parts,'source_view':list(camera@Vector((0,0,1))),'source_up':list(camera@Vector((0,1,0)))}
bpy.ops.wm.read_factory_settings(use_empty=True)
for name,point in [('AxisOrigin',(0,0,0)),('AxisX',(1,0,0)),('AxisY',(0,1,0)),('AxisZ',(0,0,1))]:
    bpy.ops.mesh.primitive_cube_add(size=.02,location=point);bpy.context.object.name=name
bpy.ops.object.select_all(action='SELECT')
bpy.ops.export_scene.fbx(filepath=str(OUT/'models/orientation-basis.fbx'),use_selection=True,object_types={'MESH'},use_mesh_modifiers=True,mesh_smooth_type='OFF',add_leaf_bones=False,bake_anim=False,path_mode='STRIP',axis_forward='-Z',axis_up='Y',global_scale=1,apply_unit_scale=True)
(OUT/'export-catalog.json').write_text(json.dumps({'models':[model],'materials':materials,'orientation_basis':'models/orientation-basis.fbx','color_workflow':'Exact per-component unlit projection-baked albedo, no gain or image changes'},indent=2))
(ROOT/'source-check.json').write_text(json.dumps({'verdict':'PASS','source_sha256':before,'host_components':1,'objects':checks,'active_albedo':'Packed, exact PNG bytes copied to export','original_geometry_source_sha256':json.loads((ROOT/'guides/projection-metadata.json').read_text())['source_sha256']},indent=2))
print('EXPORT_READY='+str(OUT/'export-catalog.json'),flush=True)
