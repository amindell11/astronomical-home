"""Freeze three orthographic paint guides and per-face camera assignments for this source."""
from pathlib import Path
import bpy,bmesh,json,math,hashlib
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'guides';OUT.mkdir(exist_ok=True)
bpy.ops.wm.open_mainfile(filepath=str(ROOT/'model/verdant-clay.blend'))
scene=bpy.context.scene;camera=scene.camera
scene.render.resolution_x=1536;scene.render.resolution_y=1024;scene.render.resolution_percentage=100
scene.render.film_transparent=True;scene.render.use_freestyle=False
scene.view_settings.view_transform='Standard';scene.view_settings.look='None';scene.view_settings.exposure=0
scene.world.color=(.12,.12,.12)
camera.data.ortho_scale=8.2
target=Vector((0,0,.4))
views=[('hero',(-4.4,-8,5.5)),('rear',(4,7,5)),('underside',(1,-3,-7))]
solids=[o for o in scene.objects if o.type=='MESH' and not o.hide_render]
original={o.name:list(o.data.materials) for o in solids}
meta={'image_size':[1536,1024],'background':'Transparent, projection ignores background','views':[],'objects':[]}
materials={}
for obj in solids:
    for mat in obj.data.materials:
        if mat.name in materials:continue
        flat=mat.copy();nodes=flat.node_tree.nodes;links=flat.node_tree.links
        p=nodes.get('Principled BSDF');emission=nodes.new('ShaderNodeEmission')
        emission.inputs['Color'].default_value=p.inputs['Base Color'].default_value
        links.new(emission.outputs[0],nodes.get('Material Output').inputs['Surface']);materials[mat.name]=flat
for obj in solids:
    for i,mat in enumerate(original[obj.name]):obj.data.materials[i]=materials[mat.name]
for label,direction in views:
    camera.location=target+Vector(direction).normalized()*12
    camera.rotation_euler=(target-camera.location).to_track_quat('-Z','Y').to_euler()
    bpy.context.view_layer.update()
    meta['views'].append({'name':label,'guide':label+'-unlit.png','camera_matrix_world':[list(r) for r in camera.matrix_world],'orthographic_scale':camera.data.ortho_scale,'target':list(target),'view_direction':list(Vector(direction).normalized())})
    for obj in solids:
        uv=obj.data.uv_layers.new(name='Projection_'+label)
        for loop in obj.data.loops:
            co=world_to_camera_view(scene,camera,obj.matrix_world@obj.data.vertices[loop.vertex_index].co)
            uv.data[loop.index].uv=(co.x,co.y)
    scene.render.filepath=str(OUT/(label+'-unlit.png'))
    bpy.ops.render.render(write_still=True)
    print('GUIDE='+scene.render.filepath,flush=True)
for obj in solids:
    for i,mat in enumerate(original[obj.name]):obj.data.materials[i]=mat

dep=bpy.context.evaluated_depsgraph_get()
for obj in solids:
    attr=obj.data.attributes.new('paint_view','INT','FACE')
    assignments=[]
    for face in obj.data.polygons:
        point=obj.matrix_world@face.center;normal=(obj.matrix_world.to_3x3()@face.normal).normalized()
        options=[]
        for index,(_,direction) in enumerate(views):
            d=Vector(direction).normalized();facing=normal.dot(d)
            hit,loc,_,_,hitobj,_=scene.ray_cast(dep,point+d*15,-d,distance=15.04)
            visible=hit and (loc-point).length<.018
            options.append((facing+(3 if visible and facing>.04 else 0),index))
        selected=max(options)[1];attr.data[face.index].value=selected;assignments.append(selected)
    obj.data.uv_layers.active=obj.data.uv_layers.get('MineralAtlasUV')
    bm=bmesh.new();bm.from_mesh(obj.data)
    remaining=set(bm.verts);volumes=[]
    while remaining:
        start=remaining.pop();stack=[start];group={start}
        while stack:
            v=stack.pop()
            for e in v.link_edges:
                n=e.other_vert(v)
                if n in remaining:remaining.remove(n);group.add(n);stack.append(n)
        polys={f for v in group for f in v.link_faces}
        volume=0
        for f in polys:
            a=f.verts[0].co
            for j in range(1,len(f.verts)-1):volume+=a.dot(f.verts[j].co.cross(f.verts[j+1].co))/6
        volumes.append(volume)
    stats={'boundary_edges':sum(e.is_boundary for e in bm.edges),'nonmanifold_edges':sum(not e.is_manifold for e in bm.edges),'zero_area_faces':sum(f.calc_area()<1e-10 for f in bm.faces),'component_signed_volumes':volumes}
    assert stats['boundary_edges']==0 and stats['nonmanifold_edges']==0 and stats['zero_area_faces']==0,(obj.name,stats)
    assert min(volumes)>0,(obj.name,volumes)
    bm.free()
    meta['objects'].append({'name':obj.name,'stats':stats,'vertices':[list(v.co) for v in obj.data.vertices],'faces':[list(p.vertices) for p in obj.data.polygons],'face_projection':assignments,'atlas_uv':[[list(obj.data.uv_layers['MineralAtlasUV'].data[i].uv) for i in p.loop_indices] for p in obj.data.polygons]})
camera.location=target+Vector(views[0][1]).normalized()*12
camera.rotation_euler=(target-camera.location).to_track_quat('-Z','Y').to_euler()
scene.view_settings.view_transform='AgX';scene.view_settings.look='AgX - Medium High Contrast'
path=ROOT/'model/verdant-projection-source.blend';bpy.ops.wm.save_as_mainfile(filepath=str(path))
meta['source']='../model/'+path.name;meta['source_sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
(OUT/'projection-metadata.json').write_text(json.dumps(meta,indent=2))
print('PROJECTION_GUIDES_COMPLETE='+str(OUT),flush=True)
