"""Copy the current planet/nebula shaders into the review asset folder with one final RGB grade.

Run with Python from any directory. Writes only the private review folder and shader-provenance.json.
The original shaders and cloud-bake pass remain unchanged. A is an exact early return.
"""
from pathlib import Path
import hashlib, json

ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[2]
ASSETS=REPO/'src/Asteroids3D/Assets'
SKY=ASSETS/'Visuals/Locales/Sky'
OUT=ASSETS/'Visuals/Environment/Asteroids/VerdantSingleReview/Backdrop'
OUT.mkdir(parents=True,exist_ok=True)
properties='''
        _ReviewMuted ("Review background B", Float) = 0
        _ReviewSaturation ("Review saturation", Float) = 0.82
        _ReviewContrast ("Review contrast", Float) = 0.88
        _ReviewPivot ("Review contrast pivot", Float) = 0.08
'''
variables='''
                float _ReviewMuted;
                float _ReviewSaturation;
                float _ReviewContrast;
                float _ReviewPivot;
'''
grade='''
            half4 ReviewBackground(half4 color)
            {
                if (_ReviewMuted < 0.5) return color;
                half luminance = dot(color.rgb, half3(0.2126, 0.7152, 0.0722));
                color.rgb = lerp(luminance.xxx, color.rgb, _ReviewSaturation);
                half pivot = _ReviewPivot * color.a;
                color.rgb = max(0, (color.rgb - pivot) * _ReviewContrast + pivot);
                return color;
            }
'''
entries=[]
for name,source in [('Planet',SKY/'Planets/Planet.shader'),('Nebula',SKY/'Nebula.shader')]:
    original=source.read_text()
    text=original.replace('Shader "Locales/Planet"','Shader "Review/Verdant/Planet"').replace('Shader "Custom/Nebula"','Shader "Review/Verdant/Nebula"')
    text=text.replace('    Properties\n    {','    Properties\n    {'+properties,1)
    text=text.replace('CBUFFER_START(UnityPerMaterial)','CBUFFER_START(UnityPerMaterial)'+variables,1)
    text=text.replace('#include "../SkyCommon.hlsl"','#include "Assets/Visuals/Locales/Sky/SkyCommon.hlsl"')
    text=text.replace('#include "SkyCommon.hlsl"','#include "Assets/Visuals/Locales/Sky/SkyCommon.hlsl"')
    needle='            half4 Frag(Varyings input) : SV_Target'
    assert text.count(needle)==1
    text=text.replace(needle,grade+'\n'+needle,1)
    if name=='Planet':
        old='return half4(lerp(atmosphere * haloAlpha, body, coverage), lerp(haloAlpha, 1, coverage));'
        assert old in text
        text=text.replace(old,'return ReviewBackground(half4(lerp(atmosphere * haloAlpha, body, coverage), lerp(haloAlpha, 1, coverage)));')
    else:
        old='return CloudBankFromTile(position + coordinates.cameraPosition * _NebulaParallax);'
        assert old in text
        text=text.replace(old,'return ReviewBackground(CloudBankFromTile(position + coordinates.cameraPosition * _NebulaParallax));')
        text=text.replace('return half4(Nebula(position, coordinates.cameraPosition), 0);','return ReviewBackground(half4(Nebula(position, coordinates.cameraPosition), 0));')
        assert text.split('Name "CloudBankBake"',1)[1]==original.split('Name "CloudBankBake"',1)[1]
    dest=OUT/(name+'Review.shader');dest.write_text(text)
    entries.append({'original':source.relative_to(REPO).as_posix(),'original_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'review':dest.relative_to(REPO).as_posix(),'review_sha256':hashlib.sha256(dest.read_bytes()).hexdigest()})
(ROOT/'shader-provenance.json').write_text(json.dumps({'background_A':'Unmodified original fragment result; private clones freeze motion at time zero','background_B':{'saturation':.82,'contrast':.88,'linear_pivot':.08,'alpha':'Unchanged'},'cloud_bake_pass':'Byte-identical from pass name onward','shaders':entries},indent=2))
print('REVIEW_SHADERS='+str(OUT))
