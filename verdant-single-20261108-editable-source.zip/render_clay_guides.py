"""Render lighting-only geometric references at the frozen paint-projection cameras."""
from pathlib import Path
import bpy,json
from mathutils import Matrix
ROOT=Path(__file__).resolve().parent
meta=json.loads((ROOT/'guides/projection-metadata.json').read_text())
bpy.ops.wm.open_mainfile(filepath=str(ROOT/'model/verdant-projection-source.blend'))
scene=bpy.context.scene
clay=bpy.data.materials.new('Review clay');clay.use_nodes=True
p=clay.node_tree.nodes.get('Principled BSDF')
p.inputs['Base Color'].default_value=(.32,.34,.36,1)
p.inputs['Roughness'].default_value=.93
bpy.context.view_layer.material_override=clay
for view in meta['views']:
    scene.camera.matrix_world=Matrix(view['camera_matrix_world'])
    scene.camera.data.ortho_scale=view['orthographic_scale']
    scene.render.filepath=str(ROOT/'guides'/(view['name']+'-clay.png'))
    bpy.ops.render.render(write_still=True)
    print('CLAY_GUIDE='+scene.render.filepath,flush=True)
