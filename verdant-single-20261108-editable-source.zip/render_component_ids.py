"""Render exact visible object IDs for each frozen paint camera, without antialiased ID mixing."""
from pathlib import Path
import bpy,json
from mathutils import Matrix
ROOT=Path(__file__).resolve().parent
meta=json.loads((ROOT/'guides/projection-metadata.json').read_text())
bpy.ops.wm.open_mainfile(filepath=str(ROOT/'model/verdant-projection-source.blend'))
scene=bpy.context.scene;scene.cycles.samples=1
for index,item in enumerate(meta['objects']):bpy.data.objects[item['name']].pass_index=index+1
bpy.context.view_layer.use_pass_object_index=True
group=bpy.data.node_groups.new('Exact component ID output','CompositorNodeTree')
group.interface.new_socket(name='Image',in_out='OUTPUT',socket_type='NodeSocketColor')
scene.compositing_node_group=group;nodes=group.nodes
layer=nodes.new('CompositorNodeRLayers');divide=nodes.new('ShaderNodeMath');divide.operation='DIVIDE';divide.inputs[1].default_value=16
output=nodes.new('NodeGroupOutput');group.links.new(layer.outputs['Object Index'],divide.inputs[0]);group.links.new(divide.outputs[0],output.inputs['Image'])
scene.render.image_settings.file_format='OPEN_EXR';scene.render.image_settings.color_mode='RGBA';scene.render.image_settings.color_depth='32';scene.render.image_settings.exr_codec='ZIP'
for view in meta['views']:
    scene.camera.matrix_world=Matrix(view['camera_matrix_world']);scene.camera.data.ortho_scale=view['orthographic_scale']
    scene.render.filepath=str(ROOT/'guides'/(view['name']+'-component-ids.exr'));bpy.ops.render.render(write_still=True)
(ROOT/'guides/component-ids.json').write_text(json.dumps({'encoding':'Exact Object Index pass divided by16, linear EXR, no antialias mixing','objects':{item['name']:(i+1)/16 for i,item in enumerate(meta['objects'])}},indent=2))
