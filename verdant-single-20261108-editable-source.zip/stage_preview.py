"""Stage declared review export files into this pooled checkout's private review asset folder."""
from pathlib import Path
import json,shutil,hashlib
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[2]
DEST=REPO/'src/Asteroids3D/Assets/Visuals/Environment/Asteroids/VerdantSingleReview'
catalog=json.loads((ROOT/'export/export-catalog.json').read_text())
paths=['export-catalog.json',catalog['orientation_basis']]+[m['fbx'] for m in catalog['models']]+[m['paint_path'] for m in catalog['materials'] if m['paint_path']]
files=[]
for rel in paths:
    source=ROOT/'export'/rel;target=DEST/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
    files.append({'path':target.relative_to(REPO).as_posix(),'sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
scenario=REPO/'scratch/capture/VerdantSingleBackgroundScenario.cs'
scenario.parent.mkdir(parents=True,exist_ok=True)
shutil.copy2(ROOT/'capture'/scenario.name,scenario)
(ROOT/'staged-preview.json').write_text(json.dumps({'assets':DEST.relative_to(REPO).as_posix(),'scenario':scenario.relative_to(REPO).as_posix(),'result_index':'results/capture/verdant-single-background-index.json','files':files},indent=2))
print('CAPTURE_READY='+str(DEST))
