"""One material-separated Violet volume study. No UVs or texture painting."""
import bpy,bmesh,math,json
from pathlib import Path
from mathutils import Vector,Euler
from mathutils.bvhtree import BVHTree

OUT=Path(__file__).resolve().parent
OUT.mkdir(parents=True,exist_ok=True)
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.context.preferences.filepaths.save_version=0
scene=bpy.context.scene
visible=bpy.data.collections.new('Violet visible components');scene.collection.children.link(visible)
author=bpy.data.collections.new('Host construction volumes');scene.collection.children.link(author)
author.hide_render=True
preview=bpy.data.collections.new('Review cameras and lights');scene.collection.children.link(preview)
root=bpy.data.objects.new('Asteroid_Violet_Prototype',None);visible.objects.link(root)

def material(name,color,roughness=.9):
    mat=bpy.data.materials.new(name);mat.use_nodes=True
    bsdf=mat.node_tree.nodes['Principled BSDF'];bsdf.inputs['Base Color'].default_value=(*color,1);bsdf.inputs['Roughness'].default_value=roughness;bsdf.inputs['Specular IOR Level'].default_value=.12
    return mat
host_mat=material('Rock host - slate',(.115,.102,.155))
fracture_mat=material('Fresh rock fracture',(.115,.102,.155))
gem_mat=material('Amethyst mineral',(.34,.16,.51),.62)
gem_break=material('Amethyst broken faces',(.34,.16,.51),.62)
deposit_mat=material('Warm mineral seam',(.35,.25,.14))
clay=material('Neutral clay review',(.36,.37,.39),.95)

def mesh_object(name,vertices,faces,collection=author,materials=(host_mat,fracture_mat)):
    mesh=bpy.data.meshes.new(name+'Mesh');mesh.from_pydata(vertices,[],faces);mesh.update()
    for mat in materials:mesh.materials.append(mat)
    bm=bmesh.new();bm.from_mesh(mesh);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(mesh);bm.free()
    obj=bpy.data.objects.new(name,mesh);collection.objects.link(obj)
    return obj

def ring_volume(name,lower,upper):
    n=len(lower)
    faces=[tuple(range(n-1,-1,-1)),tuple(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
    return mesh_object(name,lower+upper,faces)

core=ring_volume('Host_Core',[
 (-1.70,-.41,-.59),(-1.41,-.83,-.73),(-.55,-.96,-.78),(.78,-.94,-.73),(1.58,-.34,-.54),(1.70,.38,-.47),(1.12,.95,-.41),(-.50,1.03,-.42),(-1.64,.58,-.46)],
 [(-2.04,-.44,.20),(-1.65,-.90,.28),(-.52,-1.0,.25),(.72,-.80,.18),(1.52,-.28,.22),(1.68,.44,.46),(1.05,1.02,.76),(-.50,1.10,.75),(-1.88,.66,.48)])
roof=ring_volume('Host_Roof',[
 (-1.94,-.43,.05),(-1.46,-.86,.11),(-.56,-.93,.29),(.30,-.72,.42),(.95,-.39,.38),(1.17,.08,.52),(.89,.82,.70),(-.35,1.07,.58),(-1.75,.66,.31)],
 [(-2.06,-.44,.36),(-1.52,-.91,.45),(-.56,-.93,.60),(.30,-.72,.76),(.95,-.39,.75),(1.17,.08,.90),(.89,.82,1.04),(-.35,1.07,.92),(-1.75,.66,.65)])
roof_vertices=[tuple(v.co) for v in roof.data.vertices]+[(-.65,.60,1.10),(.15,.65,1.12),(-.95,-.10,.70)]
roof_faces=[tuple(p.vertices) for p in roof.data.polygons if p.index!=1]
roof_faces += [tuple(9+i for i in f) for f in [(0,1,11),(1,2,11),(2,3,10,11),(3,4,5,10),(5,6,10),(6,7,10),(7,8,9,10),(8,0,11,9),(9,11,10)]]
old_mesh=roof.data;roof.data=bpy.data.meshes.new('Host_Roof_FracturedMesh');roof.data.from_pydata(roof_vertices,[],roof_faces);roof.data.update()
for mat in (host_mat,fracture_mat):roof.data.materials.append(mat)
bpy.data.meshes.remove(old_mesh)
jaw=ring_volume('Host_LowerJaw',[
 (-1.27,-.87,-.84),(-.64,-1.21,-.82),(.14,-1.14,-.85),(1.05,-1.03,-.70),(1.72,-.47,-.60),(1.52,.07,-.56),(.34,.17,-.59),(-.89,-.07,-.70)],
 [(-1.19,-.83,-.34),(-.63,-1.18,-.37),(.13,-1.10,-.34),(1.02,-.97,-.28),(1.67,-.43,-.22),(1.48,.04,-.27),(.32,.11,-.36),(-.88,-.10,-.41)])

def resolve_fracture_faces(obj):
    bm=bmesh.new();bm.from_mesh(obj.data)
    bmesh.ops.triangulate(bm,faces=list(bm.faces));bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces))
    bm.to_mesh(obj.data);bm.free()
sheet_specs=[
 ('Stratum_Left',[(-2.10,-.48,.29),(-1.56,-.94,.38),(-1.15,-.09,.73),(-.96,.78,.99),(-1.10,1.08,.94),(-1.62,.77,.77),(-2.13,-.11,.43)]),
 ('Stratum_Central',[(-1.44,-1.00,.42),(-.20,-.79,.64),(.04,-.04,.99),(.31,.66,1.16),(.12,1.16,1.08),(-.42,1.17,1.12),(-1.02,1.01,.95),(-1.28,.17,.77)]),
 ('Stratum_Right',[(-.02,-.36,.85),(.62,-.25,.88),(.79,.08,.98),(1.00,.56,1.06),(.74,1.04,1.00),(.27,.93,1.13),(.16,.18,1.01)])]
sheets=[]
for name,top in sheet_specs:
    thickness=.35 if name=='Stratum_Central' else .28
    bottom=[(x+.04,y+.03,z-thickness) for x,y,z in top]
    sheets.append(ring_volume(name,bottom,top))
for part in (core,roof,jaw,*sheets):resolve_fracture_faces(part)
body=core.copy();body.data=core.data.copy();body.name='Rock_Host';visible.objects.link(body);body.parent=root
bpy.context.view_layer.objects.active=body;body.select_set(True)
for part in (roof,jaw,*sheets):
    mod=body.modifiers.new('Fuse '+part.name,'BOOLEAN');mod.operation='UNION';mod.solver='EXACT';mod.object=part;bpy.ops.object.modifier_apply(modifier=mod.name)

front=[(-.65,-1.60,-.42),(-.30,-1.60,-.53),(.60,-1.60,-.48),(1.89,-1.60,-.26),(2.30,-1.60,.05),(2.28,-1.60,.66),(1.16,-1.60,.75),(.29,-1.60,.64),(-.68,-1.60,.38),(-.98,-1.60,-.05)]
back=[(-.35,.30,-.44),(0,.25,-.50),(.75,.42,-.40),(1.40,.35,-.18),(1.55,.23,.10),(1.30,.30,.51),(.75,.44,.59),(.12,.45,.48),(-.43,.33,.17),(-.48,.20,-.09)]
void=ring_volume('Fracture_Void',front,back)
resolve_fracture_faces(void)
for face in void.data.polygons:face.material_index=1
mod=body.modifiers.new('Open diagonal fracture','BOOLEAN');mod.operation='DIFFERENCE';mod.solver='EXACT';mod.object=void;bpy.ops.object.modifier_apply(modifier=mod.name)

def chip(name,points):
    mesh=bpy.data.meshes.new(name+'Mesh');mesh.from_pydata(points,[],[])
    bm=bmesh.new();bm.from_mesh(mesh);bmesh.ops.convex_hull(bm,input=list(bm.verts));bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(mesh);bm.free()
    for mat in (host_mat,fracture_mat):mesh.materials.append(mat)
    for face in mesh.polygons:face.material_index=1
    tool=bpy.data.objects.new(name,mesh);author.objects.link(tool)
    mod=body.modifiers.new(name,'BOOLEAN');mod.operation='DIFFERENCE';mod.solver='EXACT';mod.object=tool;bpy.ops.object.modifier_apply(modifier=mod.name)

chip('Upper right broken shoulder',[(.89,-.81,.46),(1.48,-.49,.40),(1.43,-.28,1.32),(.86,-.67,1.30),(1.48,-1.10,1.32)])
chip('Left end sheared corner',[(-2.40,-.75,-.95),(-1.59,-1.32,-.94),(-1.99,-.40,-.92),(-2.40,-.75,.78),(-1.74,-1.32,.62),(-2.12,-.30,.48)])
chip('Broken lower jaw end',[(1.07,-1.41,-.92),(1.82,-.74,-.92),(1.28,-.82,-.92),(1.02,-1.38,.08),(1.84,-.73,.03),(1.42,-.76,-.14)])
chip('Rear stratum shear',[(-.77,1.38,.68),(.14,1.32,.79),(-.11,.84,1.08),(-.72,1.29,1.65),(.24,1.28,1.62),(-.07,.72,1.63)])
chip('Roof lip oblique incision',[(-.62,-1.15,.27),(-.45,-.64,.51),(-.17,-1.06,.28),(-.62,-1.15,.87),(-.45,-.64,.68),(-.17,-1.06,.86)])
chip('Rear left slant',[(-1.57,.83,-.57),(-.77,1.03,-.61),(-1.08,.69,.63),(-1.69,1.55,-.65),(-.58,1.49,-.65),(-.84,1.41,1.12)])
chip('Rear right slant',[(.04,.96,-.61),(1.02,.73,-.48),(.50,.77,.47),(-.03,1.57,-.74),(1.29,1.54,-.70),(.62,1.42,.88)])
chip('Left diagonal face',[(-2.24,-.67,-.73),(-1.49,-1.19,-.74),(-1.68,-.68,-.20),(-2.37,-.66,.49),(-1.76,-1.18,.34),(-2.00,-.59,.28)])
chip('Lower sill missing wedge',[(.64,-1.25,-1.0),(1.50,-.82,-1.0),(.98,-.62,-1.0),(.64,-1.25,.10),(1.50,-.82,.20),(.98,-.62,-.21)])
chip('Lower sill stepped neighbor',[(.10,-1.30,-.44),(.64,-1.30,-.48),(.65,-.72,-.43),(.19,-.73,-.40),(.10,-1.30,.05),(.64,-1.30,.05),(.65,-.72,.05),(.19,-.73,.05)])
chip('Left stratum broken end',[(-1.69,-1.12,.25),(-1.16,-1.13,.25),(-1.28,-.68,.40),(-1.69,-1.12,.85),(-1.16,-1.13,.85),(-1.28,-.68,.78)])
chip('Central stratum side fracture',[(-.30,.22,.92),(.13,.27,.92),(.05,.59,1.07),(-.30,.22,1.40),(.13,.27,1.40),(.05,.59,1.40)])
chip('Right stratum end fracture',[(.64,.74,.92),(1.12,.74,.92),(.87,1.11,.90),(.64,.74,1.40),(1.12,.74,1.40),(.87,1.11,1.40)])
body['role']='Connected host with diagonal side fracture and genuine roof overhang'

def crystal(name,center,width,depth,height,angles):
    outline=[(-.53,-.20),(-.21,-.45),(.37,-.35),(.52,.12),(.17,.40),(-.39,.31)]
    top=[Vector((x*width,y*depth,height*.50+.19*x*width+.12*y*depth)) for x,y in outline]
    base=[Vector((x*width*.90+.04,y*depth*.90+.08,-height*.61)) for x,y in outline]
    matrix=Euler(angles).to_matrix()
    vertices=[tuple(matrix@v+Vector(center)) for v in base+top]
    faces=[tuple(range(5,-1,-1)),tuple(range(6,12))]+[(i,(i+1)%6,(i+1)%6+6,i+6) for i in range(6)]
    obj=mesh_object(name,vertices,faces,visible,(gem_mat,gem_break));obj.parent=root
    for face in obj.data.polygons:face.material_index=1 if face.index==1 else 0
    if name=='Crystal_Main':
        bm=bmesh.new();bm.from_mesh(obj.data)
        plane_co=matrix@Vector((width*.30,-depth*.28,height*.42))+Vector(center)
        plane_no=matrix@Vector((1,-.20,1)).normalized()
        cut=bmesh.ops.bisect_plane(bm,geom=list(bm.verts)+list(bm.edges)+list(bm.faces),dist=.000001,plane_co=plane_co,plane_no=plane_no,clear_outer=True)
        boundary=[e for e in cut['geom_cut'] if isinstance(e,bmesh.types.BMEdge) and e.is_boundary]
        bmesh.ops.holes_fill(bm,edges=boundary,sides=0);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(obj.data);bm.free()
    obj['role']='Raw broken crystal with buried root and short exposed prism'
    return obj
crystals=[
 crystal('Crystal_Main',(.34,-.56,.005),1.05,.90,1.12,(.40,-.15,-.12)),
 crystal('Crystal_Left',(-.27,-.76,-.20),.86,.76,.61,(.58,.25,.31)),
 crystal('Crystal_Right',(.99,-.28,-.15),.67,.74,.79,(-.18,-.22,-.57)),
 crystal('Crystal_UpperFragment',(1.19,-.02,.07),.42,.55,.54,(.23,.30,.26))]

tree=BVHTree.FromObject(body,bpy.context.evaluated_depsgraph_get())
def deposit(name,anchors):
    top=[];bottom=[]
    for anchor in anchors:
        hit,normal,_,_=tree.find_nearest(Vector(anchor))
        top.append(hit+normal*.012);bottom.append(hit-normal*.026)
    count=len(top)
    faces=[tuple(range(count)),tuple(range(2*count-1,count-1,-1))]+[(i,(i+1)%count,(i+1)%count+count,i+count) for i in range(count)]
    obj=mesh_object(name,[tuple(v) for v in top+bottom],faces,visible,(deposit_mat,));obj.parent=root;obj['role']='Separate embedded mineral patch'
deposit('Mineral_Patch_Left',[(-1.43,-.62,.54),(-1.24,-.68,.56),(-1.13,-.60,.59),(-1.19,-.48,.62),(-1.32,-.46,.61),(-1.46,-.52,.58)])
deposit('Mineral_Patch_Right',[(.56,-.36,.81),(.77,-.27,.86),(.88,-.12,.90),(.79,-.03,.92),(.66,-.13,.88),(.61,-.20,.85)])
deposit('Mineral_Patch_Lower',[(-.43,-1.11,-.39),(-.26,-1.12,-.36),(-.16,-1.06,-.34),(-.24,-.99,-.32),(-.38,-1.01,-.34),(-.47,-1.06,-.37)])
for obj in visible.objects:
    if obj.type=='MESH':
        for vertex in obj.data.vertices:
            vertex.co.x*=1.08
            vertex.co.y*=.88
            vertex.co.z=vertex.co.z*.78+vertex.co.x*.06
for obj in author.objects:
    if obj.type=='MESH':
        for vertex in obj.data.vertices:
            vertex.co.x*=1.08
            vertex.co.y*=.88
            vertex.co.z=vertex.co.z*.78+vertex.co.x*.06

for obj in author.objects:obj.hide_render=True;obj.hide_set(True)
author.hide_viewport=True
scene.render.engine='CYCLES';scene.cycles.samples=48;scene.cycles.use_denoising=True
scene.render.resolution_x=1000;scene.render.resolution_y=800;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG';scene.render.image_settings.color_mode='RGBA';scene.render.film_transparent=True
scene.world=bpy.data.worlds.new('Neutral studio');scene.world.use_nodes=True
scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.20,.23,.28,1);scene.world.node_tree.nodes['Background'].inputs[1].default_value=.45
scene.view_settings.view_transform='AgX';scene.view_settings.look='AgX - Medium High Contrast'
for name,location,power,size in [('Key',(-3,-4,7),900,3.5),('Fill',(4,-2,3),240,5),('Rim',(2,4,5),500,4)]:
    data=bpy.data.lights.new(name,'AREA');data.energy=power;data.shape='DISK';data.size=size
    light=bpy.data.objects.new(name,data);preview.objects.link(light);light.location=location;light.rotation_euler=(-light.location).to_track_quat('-Z','Y').to_euler()
data=bpy.data.cameras.new('ReviewCamera');data.type='ORTHO';data.ortho_scale=5.4
camera=bpy.data.objects.new('ReviewCamera',data);preview.objects.link(camera);scene.camera=camera
views={'hero':(-3.0,-8.0,4.3),'reverse':(3.5,7,4.0),'side':(6.8,-3.5,3.4)}
camera.location=views['hero'];camera.rotation_euler=(Vector((0,0,.12))-camera.location).to_track_quat('-Z','Y').to_euler()
scene.render.use_freestyle=True
settings=bpy.context.view_layer.freestyle_settings
for line in list(settings.linesets):settings.linesets.remove(line)
line=settings.linesets.new('Outer drawn contour')
for prop in ('select_silhouette','select_border','select_crease','select_edge_mark','select_material_boundary','select_contour','select_suggestive_contour','select_ridge_valley'):setattr(line,prop,False)
line.select_external_contour=True;line.linestyle.color=(.003,.004,.009);line.linestyle.thickness=6;line.linestyle.caps='ROUND'
noise=line.linestyle.thickness_modifiers.new('Hand pressure','NOISE');noise.amplitude=1.1;noise.period=35;noise.seed=7
scene['proof_stage']='One Violet component geometry study. No UVs or textures. Clay overrides all component colors; material mode includes Blender outer contour.'
for screen in bpy.data.screens:
    for area in screen.areas:
        if area.type=='VIEW_3D':
            area.spaces.active.region_3d.view_perspective='CAMERA'
            area.spaces.active.shading.type='MATERIAL'
            area.spaces.active.shading.use_scene_world=True
            area.spaces.active.shading.use_scene_lights=True
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'violet-components.blend'),relative_remap=False)
for mode in ('clay','material'):
    bpy.context.view_layer.material_override=clay if mode=='clay' else None
    scene.render.use_freestyle=mode=='material'
    for label,position in views.items():
        camera.location=position;camera.rotation_euler=(Vector((0,0,.12))-camera.location).to_track_quat('-Z','Y').to_euler()
        scene.render.filepath=str(OUT/('violet-'+mode+'-'+label+'.png'));bpy.ops.render.render(write_still=True)
        print('RENDER='+scene.render.filepath,flush=True)
print('SOURCE='+str(OUT/'violet-components.blend'),flush=True)
