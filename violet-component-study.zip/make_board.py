from pathlib import Path
from PIL import Image,ImageDraw,ImageFont

root=Path(__file__).resolve().parent
concept=Image.open(root/'reference-asteroids-by-locale.png').convert('RGB').crop((407,314,696,483))
board=Image.new('RGB',(1500,1190),(37,44,57))
draw=ImageDraw.Draw(board)
font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',24)
small=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',20)
draw.text((28,20),'Violet, separate component geometry study',font=font,fill=(238,228,207))
draw.text((28,52),'Blender clay and plain materials, no textures, geometry for review',font=small,fill=(187,196,210))

def cell(image,box,title,transparent=False):
    x,y,w,h=box
    draw.text((x,y),title,font=font,fill=(238,228,207))
    if transparent:
        image=image.convert('RGBA');image=image.crop(image.getchannel('A').getbbox())
    scale=min((w-30)/image.width,(h-52)/image.height)
    image=image.resize((round(image.width*scale),round(image.height*scale)),Image.Resampling.LANCZOS)
    p=(x+(w-image.width)//2,y+44+(h-52-image.height)//2)
    board.paste(image,p,image if transparent else None)

cell(concept,(20,96,470,380),'Original approved concept')
cell(Image.open(root/'violet-clay-hero.png'),(510,96,470,380),'Clay, front fracture',True)
cell(Image.open(root/'violet-material-hero.png'),(1000,96,470,380),'Plain component materials',True)
cell(Image.open(root/'violet-clay-reverse.png'),(20,540,470,380),'Clay, rear volume',True)
cell(Image.open(root/'violet-clay-side.png'),(510,540,470,380),'Clay, side and crystal roots',True)
cell(Image.open(root/'violet-isolated-host.png'),(1000,510,470,210),'Separate host',True)
cell(Image.open(root/'violet-isolated-crystals.png'),(1000,728,470,170),'Four separate crystal meshes',True)
cell(Image.open(root/'violet-isolated-minerals.png'),(1000,905,470,95),'Three mineral patches',True)
draw.line((25,1015,1475,1015),fill=(91,103,123),width=1)
draw.text((28,1030),'Small-size comparison, each image resized to 150 px width',font=small,fill=(204,210,222))
for x,item in [(255,concept),(745,Image.open(root/'violet-clay-hero.png')),(1235,Image.open(root/'violet-material-hero.png'))]:
    item=item.convert('RGBA')
    if item.getextrema()[3][0]==0:item=item.crop(item.getchannel('A').getbbox())
    item=item.resize((150,round(item.height*150/item.width)),Image.Resampling.LANCZOS)
    board.paste(item,(x-75,1070),item)
board.save(root/'violet-clay-board.png')
