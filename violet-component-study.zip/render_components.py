import bpy
from pathlib import Path

root=Path(__file__).resolve().parent
bpy.ops.wm.open_mainfile(filepath=str(root/'violet-components.blend'))
scene=bpy.context.scene
scene.render.use_freestyle=False
for group,predicate in [('host',lambda obj:obj.name=='Rock_Host'),('crystals',lambda obj:obj.name.startswith('Crystal_')),('minerals',lambda obj:obj.name.startswith('Mineral_'))]:
    for obj in bpy.data.collections['Violet visible components'].objects:
        if obj.type=='MESH':obj.hide_render=not predicate(obj)
    scene.render.filepath=str(root/('violet-isolated-'+group+'.png'))
    bpy.ops.render.render(write_still=True)
