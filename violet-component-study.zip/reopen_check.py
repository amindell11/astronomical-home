import bpy,bmesh,json,hashlib
from pathlib import Path

root=Path(__file__).resolve().parent
source=root/'violet-components.blend'
bpy.ops.wm.open_mainfile(filepath=str(source))
report={'stage':'Untextured Violet component geometry study, visual approval pending','source':source.name,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'components':[]}
for obj in bpy.data.collections['Violet visible components'].objects:
    if obj.type!='MESH':continue
    bm=bmesh.new();bm.from_mesh(obj.data)
    report['components'].append({'name':obj.name,'parent':obj.parent.name,'vertices':len(bm.verts),'faces':len(bm.faces),'boundary_edges':sum(e.is_boundary for e in bm.edges),'nonmanifold_edges':sum(not e.is_manifold for e in bm.edges),'materials':[m.name for m in obj.data.materials]})
    bm.free()
author=bpy.data.collections['Host construction volumes']
report['hidden_editable_host_construction']={'count':len(author.objects),'hidden_from_render':author.hide_render,'objects':[o.name for o in author.objects]}
report['image_textures']=[i.name for i in bpy.data.images if i.source=='FILE']
report['saved_hero_camera']={'name':bpy.context.scene.camera.name,'location':list(bpy.context.scene.camera.location)}
report['saved_viewports']=[{'view':a.spaces.active.region_3d.view_perspective,'shading':a.spaces.active.shading.type} for s in bpy.data.screens for a in s.areas if a.type=='VIEW_3D']
report['outer_contour']='Blender Freestyle in plain-material mode; no ink in clay mode'
report['exports']='Not produced at geometry-review stage'
(root/'reopen-check.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
