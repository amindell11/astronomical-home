import bpy,bmesh,math
from pathlib import Path
from mathutils import Vector,Euler
from mathutils.bvhtree import BVHTree
from mathutils.geometry import closest_point_on_tri

OUT=Path(__file__).resolve().parent
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.context.preferences.filepaths.save_version=0
scene=bpy.context.scene
visible=bpy.data.collections.new('Violet visible components');scene.collection.children.link(visible)
author=bpy.data.collections.new('Editable host construction');scene.collection.children.link(author)
preview=bpy.data.collections.new('Review cameras and lights');scene.collection.children.link(preview)
root=bpy.data.objects.new('Asteroid_Violet_Refinement',None);visible.objects.link(root)

def material(name,color,roughness=.9):
    mat=bpy.data.materials.new(name);mat.use_nodes=True
    shader=mat.node_tree.nodes['Principled BSDF'];shader.inputs['Base Color'].default_value=(*color,1)
    shader.inputs['Roughness'].default_value=roughness;shader.inputs['Specular IOR Level'].default_value=.12
    return mat
stone=material('Rock host, slate',(.115,.102,.155))
fracture=material('Fresh fracture',(.115,.102,.155))
amethyst=material('Amethyst, side planes',(.34,.16,.51),.62)
terminal=material('Amethyst, broken termination',(.34,.16,.51),.62)
mineral=material('Warm mineral deposits',(.40,.24,.10))
clay=material('Neutral clay',(.36,.37,.39),.95)

def mesh(name,vertices,faces,collection=author,materials=(stone,fracture)):
    data=bpy.data.meshes.new(name+'Mesh');data.from_pydata(vertices,[],faces);data.update()
    for mat in materials:data.materials.append(mat)
    bm=bmesh.new();bm.from_mesh(data);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(data);bm.free()
    obj=bpy.data.objects.new(name,data);collection.objects.link(obj)
    if collection==visible:obj.parent=root
    return obj

def volume(name,bottom,top,ridges=(),roof_faces=None,side_faces=None):
    n=len(bottom)
    faces=[tuple(range(n-1,-1,-1))]+(side_faces if side_faces is not None else [(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)])
    faces += [tuple(n+i for i in face) for face in roof_faces] if roof_faces else [tuple(range(n,2*n))]
    obj=mesh(name,bottom+top+list(ridges),faces)
    bm=bmesh.new();bm.from_mesh(obj.data);bmesh.ops.triangulate(bm,faces=list(bm.faces));bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(obj.data);bm.free()
    return obj

shoulder=volume('Host_LeftShoulder',[
 (-1.75,-.42,-.12),(-1.18,-.86,-.46),(-.80,-.80,-.64),(-.52,-.24,-.45),(-.67,.67,-.38),(-1.18,1.08,-.48),(-1.70,.68,-.31),(-1.91,-.08,-.04)],
 [(-2.15,-.50,.28),(-1.74,-.88,.36),(-1.03,-.61,.57),(-.53,-.07,.73),(-.65,.82,1.00),(-1.12,1.14,.87),(-1.92,.70,.54),(-2.24,-.03,.34)],
 [(-1.50,-.95,.12),(-1.08,-.86,-.03),(-.68,-.50,.22),(-1.38,.28,.79),(-.80,.60,.90)],
 [(0,1,11),(1,2,3,12,11),(3,4,12),(4,5,12),(5,6,11,12),(6,7,0,11)],
 [(8,9,16),(9,10,17,16),(10,11,18,17),(8,16,17,1,0),(17,18,3,2,1),(18,11,3)]+[(i,(i+1)%8,(i+1)%8+8,i+8) for i in range(3,8)])
spine=volume('Host_RearSpine',[
 (-.83,.08,-.58),(.05,.16,-.69),(.78,.05,-.58),(1.54,.17,-.38),(1.83,.52,-.17),(1.38,1.00,-.31),(.18,1.20,-.42),(-.86,.98,-.39)],
 [(-.65,.34,.64),(.06,.50,.62),(.82,.34,.52),(1.49,.45,.33),(1.67,.64,.35),(1.30,1.01,.62),(.16,1.17,.99),(-.68,.98,1.02)],
 [(-.35,-.02,-.05),(.35,.23,.10),(1.04,.13,-.08)],None,
 [(8,9,16),(9,10,17,16),(10,11,18,17),(8,16,17,1,0),(17,18,3,2,1),(18,11,3)]+[(i,(i+1)%8,(i+1)%8+8,i+8) for i in range(3,8)])
roof=volume('Host_LeftRoofShear',[
 (-1.30,-.35,.35),(-.55,-.31,.47),(.13,.55,.67),(-.03,1.10,.72),(-.89,1.00,.70)],
 [(-1.45,-.36,.64),(-.52,-.31,.77),(.22,.57,1.18),(-.01,1.18,1.10),(-1.00,1.07,1.03)])
roof_right=volume('Host_RightRoofShear',[
 (-.40,.05,.51),(.40,.00,.60),(.98,.30,.59),(.96,.96,.65),(.12,1.18,.70),(-.55,.89,.65)],
 [(-.54,.08,.89),(.43,-.04,.92),(1.04,.27,.85),(.99,1.00,.94),(.10,1.22,1.05),(-.59,.95,1.14)])
lower=volume('Host_RecessedRootBase',[
 (-.94,-.47,-.68),(.04,-.55,-.72),(.84,-.43,-.61),(1.63,-.13,-.43),(1.79,.38,-.29),(.78,.73,-.48),(-.77,.61,-.60)],
 [(-.85,-.41,-.38),(.06,-.46,-.36),(.81,-.33,-.30),(1.57,-.04,-.16),(1.66,.39,-.12),(.76,.66,-.31),(-.72,.54,-.34)])
lower_left=volume('Host_LowerLeftBreak',[
 (-1.13,-.76,-.67),(-.65,-1.10,-.80),(.20,-.94,-.72),(.45,-.50,-.61),(.12,.15,-.55),(-.73,.20,-.60)],
 [(-1.00,-.62,-.32),(-.54,-.95,-.23),(.11,-.82,-.30),(.37,-.44,-.20),(.10,.10,-.32),(-.70,.15,-.35)])
lower_right=volume('Host_LowerRightBreak',[
 (.55,-.52,-.58),(1.10,-.67,-.65),(1.78,-.30,-.43),(1.87,.28,-.28),(1.23,.54,-.37),(.66,.26,-.51)],
 [(.62,-.39,-.29),(1.08,-.52,-.19),(1.71,-.20,-.11),(1.75,.27,-.03),(1.18,.48,-.18),(.65,.21,-.23)])
body=shoulder.copy();body.data=shoulder.data.copy();body.name='Rock_Host';visible.objects.link(body);body.parent=root
bpy.context.view_layer.objects.active=body;body.select_set(True)
for part in (spine,roof,roof_right,lower,lower_left,lower_right):
    mod=body.modifiers.new('Fuse '+part.name,'BOOLEAN');mod.operation='UNION';mod.solver='EXACT';mod.object=part;bpy.ops.object.modifier_apply(modifier=mod.name)
body['construction']='Thick overlapping fracture volumes with explicit shoulder and inner-wall planes; no cavity cutter'
def fracture_plane(name,center,u,v,outward):
    center,u,v,outward=map(Vector,(center,u,v,outward))
    inner=[center-u-v,center+u-v,center+u+v,center-u+v]
    cutter=mesh(name,[tuple(p) for p in inner+[p+outward for p in inner]],[(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)])
    mod=body.modifiers.new(name,'BOOLEAN');mod.operation='DIFFERENCE';mod.solver='EXACT';mod.object=cutter;bpy.ops.object.modifier_apply(modifier=mod.name)
fracture_plane('Fracture_LeftShoulder',(-1.50,-.63,.05),(.65,-.20,.0),(-.10,.02,.60),(-.6,-1.2,.05))
fracture_plane('Fracture_LeftRoofTransition',(-.95,-.25,.50),(.35,.0,.08),(-.12,.10,.45),(0,-1.3,.20))
fracture_plane('Fracture_UpperShear',(-.35,.45,.90),(.78,.0,.10),(.0,.75,.15),(0,0,1.1))
fracture_plane('Fracture_RightOverhang',(.62,.12,.72),(.47,.15,-.06),(.0,.15,.43),(0,-1.3,.10))
fracture_plane('Fracture_Rear',(.45,1.02,.05),(.50,-.06,.08),(.13,-.16,.55),(0,1.2,.10))
fracture_plane('Fracture_LowerRight',(1.66,.24,-.25),(.04,.55,0),(.05,0,.50),(1.2,0,-.05))
def host_point(point):return Vector((point[0]*1.12,point[1]*.85,point[2]*.83))
for obj in [body]+list(author.objects):
    for vertex in obj.data.vertices:vertex.co=host_point(vertex.co)

def crystal(name,center,width,depth,height,angles,break_corner=False):
    center=host_point(center)
    outline=[(-.53,-.17),(-.22,-.43),(.35,-.34),(.51,.13),(.13,.40),(-.39,.29)]
    bottom=[Vector((x*width*.70+.04,y*depth*.70+.06,-height*.61)) for x,y in outline]
    if name=='Crystal_Main':bottom=[v+Vector((0,.24,.16)) for v in bottom]
    shoulder=[Vector((x*width,y*depth,height*.04+.09*x*width)) for x,y in outline]
    top=[Vector((x*width*.77-.03,y*depth*.77+.025,height*.49+.20*x*width-.09*y*depth)) for x,y in outline]
    matrix=Euler(angles).to_matrix()
    obj=mesh(name,[tuple(matrix@v+Vector(center)) for v in bottom+shoulder+top],
        [tuple(range(5,-1,-1)),tuple(range(12,18))]+[(j+i,j+(i+1)%6,j+(i+1)%6+6,j+i+6) for j in (0,6) for i in range(6)],visible,(amethyst,terminal))
    obj.data.polygons[1].material_index=1
    if break_corner:
        bm=bmesh.new();bm.from_mesh(obj.data)
        cut=bmesh.ops.bisect_plane(bm,geom=list(bm.verts)+list(bm.edges)+list(bm.faces),dist=.000001,
            plane_co=matrix@Vector((width*.19,-depth*.24,height*.39))+Vector(center),plane_no=matrix@Vector((1,-.25,1)).normalized(),clear_outer=True)
        bmesh.ops.holes_fill(bm,edges=[e for e in cut['geom_cut'] if isinstance(e,bmesh.types.BMEdge) and e.is_boundary],sides=0)
        bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(obj.data);bm.free()
    return obj
crystals=[
 crystal('Crystal_Main',(.19,-.52,-.015),.86,.62,1.03,(.06,-.10,.22),True),
 crystal('Crystal_Left',(-.42,-.72,-.25),.76,.55,.63,(.28,.35,-.31),True),
 crystal('Crystal_Right',(.84,-.17,-.19),.66,.52,.72,(-.13,-.24,-.37),False),
 crystal('Crystal_Fragment',(1.08,.08,.075),.39,.37,.40,(.10,.23,.34),False)]

tree=BVHTree.FromObject(body,bpy.context.evaluated_depsgraph_get())
used_deposit_edges=set()
def deposit(name,anchors,width):
    anchor=sum((host_point(p) for p in anchors),Vector())/len(anchors)
    body.data.calc_loop_triangles()
    adjacent={tuple(sorted(e.vertices)):[] for e in body.data.edges}
    for face in body.data.polygons:
        ids=list(face.vertices)
        for a,b in zip(ids,ids[1:]+ids[:1]):adjacent[tuple(sorted((a,b)))].append(face)
    candidates=[]
    for edge in body.data.edges:
        key=tuple(sorted(edge.vertices));faces=adjacent[key]
        if key in used_deposit_edges or len(faces)!=2:continue
        a,b=[body.data.vertices[i].co.copy() for i in edge.vertices];length=(b-a).length;middle=(a+b)*.5
        if length<.36 or not (.35<middle.z<.95 and middle.y<.55):continue
        if faces[0].normal.angle(faces[1].normal)<math.radians(22):continue
        for face in faces:
            if face.normal.z<.45:continue
            for triangle in body.data.loop_triangles:
                if triangle.polygon_index!=face.index or not set(key).issubset(triangle.vertices):continue
                c=body.data.vertices[next(i for i in triangle.vertices if i not in key)].co.copy()
                altitude=(c-a).cross((b-a).normalized()).length
                if altitude>.24:candidates.append(((middle-anchor).length_squared,key,a,b,c,face.normal.copy(),altitude))
    _,key,a,b,c,normal,altitude=min(candidates,key=lambda item:item[0]);used_deposit_edges.add(key)
    profile=[(.12,.04),(.30,.015),(.47,.035),(.68,.01),(.88,.04),(.81,.65),(.67,1.05),(.51,.72),(.36,1.12),(.20,.58)]
    points=[]
    for along,depth in profile:
        edge_point=a.lerp(b,along);fraction=width*depth/altitude
        points.append(edge_point.lerp(c,fraction))
    upper=[p+normal*.0015 for p in points];lower=[p-normal*.015 for p in points]
    n=len(upper)
    return mesh(name,[tuple(v) for v in upper+lower],[tuple(range(n)),tuple(range(2*n-1,n-1,-1))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)],visible,(mineral,))
deposits=[
 deposit('Mineral_Patch_RoofLeft',[(-.55,-.05,.73)],.10),
 deposit('Mineral_Patch_RoofCenter',[(.22,.05,.78)],.07),
 deposit('Mineral_Patch_RoofRight',[(.80,.24,.74)],.085)]
for obj in author.objects:obj.hide_render=True;obj.hide_set(True)
author.hide_render=True;author.hide_viewport=True

scene.render.engine='CYCLES';scene.cycles.samples=48;scene.cycles.use_denoising=True
scene.render.resolution_x=1000;scene.render.resolution_y=800;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG';scene.render.image_settings.color_mode='RGBA';scene.render.film_transparent=True
scene.world=bpy.data.worlds.new('Neutral studio');scene.world.use_nodes=True
scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.20,.23,.28,1);scene.world.node_tree.nodes['Background'].inputs[1].default_value=.45
scene.view_settings.view_transform='AgX';scene.view_settings.look='AgX - Medium High Contrast'
for name,location,power,size in [('Key',(-3,-4,7),900,3.5),('Fill',(4,-2,3),240,5),('Rim',(2,4,5),500,4)]:
    data=bpy.data.lights.new(name,'AREA');data.energy=power;data.shape='DISK';data.size=size
    light=bpy.data.objects.new(name,data);preview.objects.link(light);light.location=location;light.rotation_euler=(-light.location).to_track_quat('-Z','Y').to_euler()
data=bpy.data.cameras.new('ReviewCamera');data.type='ORTHO';data.ortho_scale=5.4
camera=bpy.data.objects.new('ReviewCamera',data);preview.objects.link(camera);scene.camera=camera
views={'hero':(-3.0,-8.0,4.3),'reverse':(3.5,7,4.0),'side':(6.8,-3.5,3.4)}
def aim(position):
    camera.location=position;camera.rotation_euler=(Vector((0,0,.12))-camera.location).to_track_quat('-Z','Y').to_euler()
aim(views['hero'])
scene.render.use_freestyle=True
settings=bpy.context.view_layer.freestyle_settings
for line in list(settings.linesets):settings.linesets.remove(line)
line=settings.linesets.new('Outer drawn contour')
for prop in ('select_silhouette','select_border','select_crease','select_edge_mark','select_material_boundary','select_contour','select_suggestive_contour','select_ridge_valley'):setattr(line,prop,False)
line.select_external_contour=True;line.linestyle.color=(.003,.004,.009);line.linestyle.thickness=6;line.linestyle.caps='ROUND'
noise=line.linestyle.thickness_modifiers.new('Hand pressure','NOISE');noise.amplitude=1.1;noise.period=35;noise.seed=7
for screen in bpy.data.screens:
    for area in screen.areas:
        if area.type=='VIEW_3D':
            area.spaces.active.region_3d.view_perspective='CAMERA';area.spaces.active.shading.type='MATERIAL'
            area.spaces.active.shading.use_scene_world=True;area.spaces.active.shading.use_scene_lights=True
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'violet-refine.blend'),relative_remap=False)
bpy.context.view_layer.material_override=clay;scene.render.use_freestyle=False
for obj in crystals+deposits:obj.hide_render=True
scene.render.filepath=str(OUT/'violet-clay-host.png');bpy.ops.render.render(write_still=True);print('HOST='+scene.render.filepath,flush=True)
for obj in crystals+deposits:obj.hide_render=False
for mode in ('clay','material'):
    bpy.context.view_layer.material_override=clay if mode=='clay' else None;scene.render.use_freestyle=mode=='material'
    for obj in deposits:obj.hide_render=mode=='clay'
    for label,position in views.items():
        aim(position);scene.render.filepath=str(OUT/('violet-'+mode+'-'+label+'.png'));bpy.ops.render.render(write_still=True)
        print('RENDER='+scene.render.filepath,flush=True)
