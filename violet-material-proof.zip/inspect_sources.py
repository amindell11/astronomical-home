import bpy,bmesh,json,hashlib
from pathlib import Path

root=Path(__file__).resolve().parent
report={'stage':'One Violet geometry and mapped-material proof, not production acceptance','sources':[]}
for filename in ('violet-refine.blend','violet-painted.blend'):
    path=root/filename;bpy.ops.wm.open_mainfile(filepath=str(path))
    entry={'file':filename,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'meshes':[]}
    for obj in bpy.data.collections['Violet visible components'].objects:
        if obj.type!='MESH':continue
        bm=bmesh.new();bm.from_mesh(obj.data)
        pending=set(bm.verts);components=[]
        while pending:
            stack=[pending.pop()];found=set(stack)
            while stack:
                for edge in stack.pop().link_edges:
                    for vertex in edge.verts:
                        if vertex in pending:pending.remove(vertex);found.add(vertex);stack.append(vertex)
            faces={face for vertex in found for face in vertex.link_faces}
            components.append({'vertices':len(found),'faces':len(faces),'surface_area':sum(face.calc_area() for face in faces),'bounds':[[min(v.co[i] for v in found),max(v.co[i] for v in found)] for i in range(3)]})
        entry['meshes'].append({'name':obj.name,'parent':obj.parent.name if obj.parent else None,'vertices':len(bm.verts),'faces':len(bm.faces),'boundary_edges':sum(edge.is_boundary for edge in bm.edges),'nonmanifold_edges':sum(not edge.is_manifold for edge in bm.edges),'connected_components':components,'uv_layers':[uv.name for uv in obj.data.uv_layers],'materials':[m.name for m in obj.data.materials],'role':'Open tapered paint accent' if 'PaleAccent' in obj.name else 'Solid material component'})
        bm.free()
    entry['images']=[{'name':i.name,'path':i.filepath,'packed':bool(i.packed_file),'dimensions':list(i.size)} for i in bpy.data.images if i.source=='FILE']
    entry['hidden_construction_objects']=len(bpy.data.collections['Editable host construction'].objects)
    entry['camera']=list(bpy.context.scene.camera.location)
    report['sources'].append(entry)
report['paint_sources']=[{'file':'paint/'+p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in (root/'paint').glob('*.png')]
report['contour_note']='Freestyle outer contours and selected fracture strokes are Blender render effects. Pale accents are separate open paint ribbons.'
(root/'source-check.json').write_text(json.dumps(report,indent=2))
for source in report['sources']:
    print(source['file'])
    for mesh in source['meshes']:print(mesh['name'],'components',len(mesh['connected_components']),'boundary',mesh['boundary_edges'],'nonmanifold',mesh['nonmanifold_edges'])
    print('IMAGES',source['images'])
