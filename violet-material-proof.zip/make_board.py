from pathlib import Path
from PIL import Image,ImageDraw,ImageFont

root=Path(__file__).resolve().parent
board=Image.new('RGB',(1800,1050),(37,44,57))
draw=ImageDraw.Draw(board)
font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',23)
small=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',20)
draw.text((25,20),'Violet geometry refinement, untextured Blender study',font=font,fill=(238,228,207))
draw.text((25,52),'Matched camera and lighting, clay without ink, plain material with outer contour',font=small,fill=(187,196,210))

def content(path):
    image=Image.open(path).convert('RGBA')
    if image.getextrema()[3][0]==0:image=image.crop(image.getchannel('A').getbbox())
    return image

def place(path,x,y,title,width=420,height=320):
    draw.text((x,y),title,font=font,fill=(238,228,207))
    item=content(path);scale=min(width/item.width,(height-40)/item.height)
    item=item.resize((round(item.width*scale),round(item.height*scale)),Image.Resampling.LANCZOS)
    board.paste(item,(x+(width-item.width)//2,y+40+(height-40-item.height)//2),item)

top=[('reference-violet.png','Original approved concept'),('violet-clay-host.png','Host only, clay'),('violet-clay-hero.png','Host and crystals, clay'),('violet-material-hero.png','Plain component materials')]
for i,(name,title) in enumerate(top):place(root/name,25+i*450,108,title)
place(root/'violet-clay-reverse.png',25,492,'Rear volume, clay')
place(root/'violet-clay-side.png',475,492,'Side volume, clay')
place(root/'previous-violet-clay.png',925,492,'Previous study, clay')
place(root/'violet-material-reverse.png',1375,492,'Rear, plain materials')
draw.line((25,850,1775,850),fill=(91,103,123),width=1)
draw.text((25,868),'Small-size comparison, each image resized to 150 px width',font=small,fill=(204,210,222))
for i,(name,_) in enumerate(top):
    item=content(root/name);item=item.resize((150,round(item.height*150/item.width)),Image.Resampling.LANCZOS)
    board.paste(item,(160+i*450,915),item)
board.save(root/'violet-refine-board.png')
