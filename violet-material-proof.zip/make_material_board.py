from pathlib import Path
from PIL import Image,ImageDraw,ImageFont

root=Path(__file__).resolve().parent
board=Image.new('RGB',(1500,1110),(37,44,57));draw=ImageDraw.Draw(board)
font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',24);small=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',20)
draw.text((25,20),'Violet, geometry and mapped-material proof',font=font,fill=(238,228,207))
draw.text((25,53),'Actual Blender renders, separate rock and crystal paint, geometry still for review',font=small,fill=(187,196,210))
def read(name):
    item=Image.open(root/name).convert('RGBA')
    if item.getextrema()[3][0]==0:item=item.crop(item.getchannel('A').getbbox())
    return item
def place(name,x,y,title):
    draw.text((x,y),title,font=font,fill=(238,228,207))
    item=read(name);scale=min(450/item.width,300/item.height)
    item=item.resize((round(item.width*scale),round(item.height*scale)),Image.Resampling.LANCZOS)
    board.paste(item,(x+(450-item.width)//2,y+45+(300-item.height)//2),item)
place('reference-violet.png',25,110,'Original approved concept')
place('violet-clay-hero.png',525,110,'Revised geometry, clay')
place('violet-painted-hero.png',1025,110,'Mapped paint and selected ink')
place('violet-painted-reverse.png',25,520,'Painted rear')
place('violet-painted-side.png',525,520,'Painted side')
place('violet-painted-close.png',1025,520,'Actual crystal and rock close-up')
draw.line((25,900,1475,900),fill=(91,103,123),width=1)
draw.text((25,920),'Small-size comparison, each image resized to 150 px width',font=small,fill=(204,210,222))
for i,name in enumerate(('reference-violet.png','violet-clay-hero.png','violet-painted-hero.png')):
    item=read(name);item=item.resize((150,round(item.height*150/item.width)),Image.Resampling.LANCZOS)
    board.paste(item,(175+i*500,965),item)
board.save(root/'violet-material-proof.png')
