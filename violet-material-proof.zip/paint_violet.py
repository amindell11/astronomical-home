import bpy,math
from pathlib import Path
from mathutils import Vector,Euler

root=Path(__file__).resolve().parent
bpy.ops.wm.open_mainfile(filepath=str(root/'violet-refine.blend'))
bpy.context.preferences.filepaths.save_version=0
scene=bpy.context.scene
ink=bpy.data.collections.new('Ink subject, rock');scene.collection.children.link(ink)
gem_ink=bpy.data.collections.new('Ink subjects, crystals');scene.collection.children.link(gem_ink)
body=bpy.data.objects['Rock_Host']
crystals=[o for o in bpy.data.collections['Violet visible components'].objects if o.name.startswith('Crystal_')]
ink.objects.link(body)
for obj in crystals:gem_ink.objects.link(obj)

def mapped_material(name,filename):
    material=bpy.data.materials.new(name);material.use_nodes=True
    nodes=material.node_tree.nodes;shader=nodes.get('Principled BSDF');shader.inputs['Roughness'].default_value=.9;shader.inputs['Specular IOR Level'].default_value=.12
    image=bpy.data.images.load(str(root/'paint'/filename));image.filepath='//paint/'+filename;image.pack()
    texture=nodes.new('ShaderNodeTexImage');texture.image=image;texture.extension='REPEAT';texture.interpolation='Linear'
    uv=nodes.new('ShaderNodeUVMap');uv.uv_map='DirectionalPaintUV'
    material.node_tree.links.new(uv.outputs['UV'],texture.inputs['Vector']);material.node_tree.links.new(texture.outputs['Color'],shader.inputs['Base Color'])
    if 'slate' in name:
        tone=nodes.new('ShaderNodeHueSaturation');tone.label='Restrained slate tone, source unchanged'
        tone.inputs['Saturation'].default_value=.72;tone.inputs['Value'].default_value=.68
        material.node_tree.links.new(texture.outputs['Color'],tone.inputs['Color']);material.node_tree.links.new(tone.outputs['Color'],shader.inputs['Base Color'])
    return material
rock=mapped_material('Painted slate, source swatch','violet-rock-paint.png')
gem=mapped_material('Painted amethyst, source swatch','violet-crystal-paint.png')

def uv_map(obj,axis,span):
    uv=obj.data.uv_layers.new(name='DirectionalPaintUV');axis=axis.normalized()
    for face in obj.data.polygons:
        normal=face.normal.normalized();grain=axis-normal*axis.dot(normal)
        if grain.length<.1:grain=Vector((1,0,.1))-normal*Vector((1,0,.1)).dot(normal)
        grain.normalize();cross=normal.cross(grain).normalized()
        for index in face.loop_indices:
            point=obj.data.vertices[obj.data.loops[index].vertex_index].co
            across,along=point.dot(cross),point.dot(grain)
            uv.data[index].uv=((across+along)/(span*math.sqrt(2))+.5,(-across+along)/(span*math.sqrt(2))+.5)
    obj['paint_mapping']='Swatch brush diagonal aligned to projected physical fracture/crystal axis per face'
uv_map(body,Vector((.95,1,.35)),4.3)
body.data.materials.clear();body.data.materials.append(rock)
for face in body.data.polygons:face.material_index=0
axes={'Crystal_Main':(.06,-.10,.22),'Crystal_Left':(.28,.35,-.31),'Crystal_Right':(-.13,-.24,-.37),'Crystal_Fragment':(.10,.23,.34)}
for obj in crystals:
    uv_map(obj,Euler(axes[obj.name]).to_matrix()@Vector((0,0,1)),1.8)
    obj.data.materials.clear();obj.data.materials.append(gem)
    for face in obj.data.polygons:face.material_index=0
deposit_material=bpy.data.materials.new('Warm broken mineral paint');deposit_material.use_nodes=True
nodes=deposit_material.node_tree.nodes;shader=nodes.get('Principled BSDF');shader.inputs['Roughness'].default_value=.95
texture=nodes.new('ShaderNodeTexImage');texture.image=bpy.data.images['violet-rock-paint.png'];texture.extension='REPEAT'
coordinates=nodes.new('ShaderNodeUVMap');coordinates.uv_map='DirectionalPaintUV'
tones=nodes.new('ShaderNodeRGBToBW');ramp=nodes.new('ShaderNodeValToRGB')
ramp.color_ramp.elements[0].position=.025;ramp.color_ramp.elements[0].color=(.19,.085,.025,1)
ramp.color_ramp.elements[1].position=.20;ramp.color_ramp.elements[1].color=(.55,.34,.14,1)
deposit_material.node_tree.links.new(coordinates.outputs['UV'],texture.inputs['Vector']);deposit_material.node_tree.links.new(texture.outputs['Color'],tones.inputs[0]);deposit_material.node_tree.links.new(tones.outputs[0],ramp.inputs[0]);deposit_material.node_tree.links.new(ramp.outputs[0],shader.inputs['Base Color'])
for obj in bpy.data.collections['Violet visible components'].objects:
    if obj.name.startswith('Mineral_'):
        uv_map(obj,Vector((.95,1,.35)),4.3);obj.data.materials.clear();obj.data.materials.append(deposit_material)

def structural_marks(obj,is_crystal):
    marks=obj.data.attributes.new(name='freestyle_edge',type='BOOLEAN',domain='EDGE')
    adjacent={tuple(sorted(edge.vertices)):[] for edge in obj.data.edges}
    for face in obj.data.polygons:
        ids=list(face.vertices)
        for a,b in zip(ids,ids[1:]+ids[:1]):adjacent[tuple(sorted((a,b)))].append(face)
    count=0;candidates=[]
    for edge in obj.data.edges:
        faces=adjacent[tuple(sorted(edge.vertices))]
        marks.data[edge.index].value=False
        if len(faces)!=2:continue
        a,b=[obj.data.vertices[i].co for i in edge.vertices];mid=(a+b)*.5;length=(a-b).length
        angle=math.degrees(faces[0].normal.angle(faces[1].normal))
        if is_crystal:
            middle=sum((v.co for v in obj.data.vertices),Vector())/len(obj.data.vertices)
            marked=length>.22 and angle>30 and abs((b-a).normalized().z)>.65 and mid.y<middle.y and mid.z>middle.z
        else:
            marked=(mid.x>-.9 and mid.x<1.2 and mid.y<.28 and .20<mid.z<.85 and length>.30 and angle>43) or (-1.30<mid.x<-.5 and mid.y<.1 and -.4<mid.z<.4 and length>.45 and angle>52) or (-.5<mid.x<1.5 and mid.z<-.18 and mid.y<-.20 and length>.35 and angle>57) or (mid.z>.5 and mid.y>.15 and length>.60 and angle>37)
        marks.data[edge.index].value=marked
        if is_crystal and marked:candidates.append((mid.y,edge.index))
        count+=int(marked)
    if is_crystal:
        keep={index for _,index in sorted(candidates)[:1]}
        for edge in obj.data.edges:marks.data[edge.index].value=edge.index in keep
        count=len(keep)
    print('MARKED',obj.name,count,flush=True)
structural_marks(body,False)
for obj in crystals:structural_marks(obj,True)

settings=bpy.context.view_layer.freestyle_settings
for line in settings.linesets:
    line.select_by_collection=True;line.collection=ink;line.collection_negation='INCLUSIVE'
def line_set(name,collection,external,color,thickness):
    line=settings.linesets.new(name)
    for prop in ('select_silhouette','select_border','select_crease','select_material_boundary','select_contour','select_suggestive_contour','select_ridge_valley','select_external_contour','select_edge_mark'):setattr(line,prop,False)
    line.select_external_contour=external;line.select_edge_mark=not external
    line.select_by_collection=True;line.collection=collection;line.collection_negation='INCLUSIVE'
    line.linestyle.color=color;line.linestyle.thickness=thickness;line.linestyle.caps='ROUND'
    noise=line.linestyle.thickness_modifiers.new('Hand pressure','NOISE');noise.amplitude=thickness*.2;noise.period=24;noise.seed=13
    return line
line_set('Selected rock fractures',ink,False,(.035,.025,.055),1.5)
line_set('Soft crystal silhouette',gem_ink,True,(.12,.055,.21),2.0)

accent=bpy.data.materials.new('Painted pale lavender edge accents');accent.use_nodes=True
shader=accent.node_tree.nodes['Principled BSDF'];shader.inputs['Base Color'].default_value=(.65,.4,.85,1);shader.inputs['Roughness'].default_value=.9
for object_name,number in [('Crystal_Main',2),('Crystal_Left',1)]:
    obj=bpy.data.objects[object_name]
    upper=max((p for p in obj.data.polygons if p.normal.z>.35),key=lambda p:p.center.z)
    ids=list(upper.vertices);edges=[]
    for a,b in zip(ids,ids[1:]+ids[:1]):
        first,last=obj.data.vertices[a].co.copy(),obj.data.vertices[b].co.copy()
        edges.append(((last-first).length,first,last))
    for i,(_,first,last) in enumerate(sorted(edges,key=lambda e:e[0],reverse=True)[:number]):
        tangent=(last-first).normalized();middle=(first+last)*.5
        inward=upper.center-middle;inward-=tangent*inward.dot(tangent);inward.normalize()
        normal=upper.normal.normalized();center=middle+inward*.015+normal*.002
        half=(last-first).length*.30;side=normal.cross(tangent).normalized()
        vertices=[center-tangent*half,center-side*.006,center+tangent*half,center+side*.006]
        data=bpy.data.meshes.new(object_name+'AccentMesh');data.from_pydata([tuple(v) for v in vertices],[],[(0,1,3),(1,2,3)]);data.materials.append(accent)
        stroke=bpy.data.objects.new(object_name+'_PaleAccent_'+str(i+1),data);bpy.data.collections['Violet visible components'].objects.link(stroke);stroke.parent=obj.parent
scene['material_proof']='Separate mesh swatches with directional UVs; Freestyle outer contour and selected structural edges are render-only'
bpy.ops.wm.save_as_mainfile(filepath=str(root/'violet-painted.blend'),relative_remap=False)

def render(name,target,scale,view=(-3,-8,4.18)):
    camera=scene.camera;camera.data.ortho_scale=scale
    direction=Vector(view).normalized();camera.location=Vector(target)+direction*9
    camera.rotation_euler=(Vector(target)-camera.location).to_track_quat('-Z','Y').to_euler()
    scene.render.filepath=str(root/name);bpy.ops.render.render(write_still=True)
    print('RENDER='+scene.render.filepath,flush=True)
render('violet-painted-hero.png',(0,0,.12),5.4)
render('violet-painted-close.png',(.10,-.20,.10),3.0)
render('violet-painted-reverse.png',(0,0,.12),5.4,(3.5,7,3.88))
render('violet-painted-side.png',(0,0,.12),5.4,(6.8,-3.5,3.28))
for obj in list(bpy.data.collections['Violet visible components'].objects):
    if obj.name.startswith('Crystal_'):obj.hide_render=True
for line in list(settings.linesets):
    if line.collection==gem_ink:line.show_render=False
render('violet-painted-host.png',(0,0,.12),5.4)
