const fs=require('fs'),path=require('path');
const root=__dirname, rad=Math.PI/180, angle=40, thickness=5.2;
const d=[Math.cos(angle*rad),-Math.sin(angle*rad)];
const slash=(cx,cy,length)=>{const dx=d[0]*length/2,dy=d[1]*length/2,w=thickness/Math.sin(angle*rad)/2;return [[cx-dx-w,cy-dy],[cx-dx+w,cy-dy],[cx+dx+w,cy+dy],[cx+dx-w,cy+dy]];};
const segment=(a,b)=>slash(d[0]*(a+b)/2,d[1]*(a+b)/2,b-a);
const rotate=(pts,degrees)=>pts.map(([x,y])=>[x*Math.cos(degrees*rad)-y*Math.sin(degrees*rad),x*Math.sin(degrees*rad)+y*Math.cos(degrees*rad)]);
const arc=[-78,-46,-14,18].map(a=>[24*Math.cos(a*rad),24*Math.sin(a*rad)]).concat([18,-14,-46,-78].map(a=>[(24-thickness)*Math.cos(a*rad),(24-thickness)*Math.sin(a*rad)]));
const missile=[ [0,-27],[3.4,-20],[3.4,8],[9,16],[3.4,14],[-3.4,14],[-9,16],[-3.4,8],[-3.4,-20] ];
const glyphs=[
 {id:'lasers',label:'Lasers',polygons:[slash(-6,-2,44),slash(6,2,44)]},
 {id:'turbo-lasers',label:'Turbo Lasers',polygons:[slash(-7,-4,44),slash(0,0,26),slash(7,4,44)]},
 {id:'charge-lasers',label:'Charge Lasers',polygons:[segment(-28,-15),segment(-8,0),segment(7,28)]},
 {id:'railgun',label:'Railgun',polygons:[slash(0,0,56),slash(-10,-7,15),slash(10,7,15)]},
 {id:'missiles',label:'Missiles',polygons:[rotate(missile,50),rotate([[-2.6,20],[2.6,20],[2.6,28],[-2.6,28]],50)]},
 {id:'rippers',label:'Rippers',polygons:[slash(-17,4,15),slash(-2,-12,24),slash(2,12,24),slash(17,-4,15)]},
 {id:'concussion',label:'Concussion',polygons:[arc,rotate(arc,120),rotate(arc,240)]}
];
const n=x=>Number(x.toFixed(5));
const pathData=polys=>polys.map(p=>'M '+p.map(([x,y])=>`${n(x+32)} ${n(y+32)}`).join(' L ')+' Z').join(' ');
fs.mkdirSync(path.join(root,'svg'),{recursive:true});
for(const g of glyphs){g.d=pathData(g.polygons);fs.writeFileSync(path.join(root,'svg',g.id+'.svg'),`<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><path fill="#ffffff" d="${g.d}"/></svg>\n`);}
const icon=(g,x,y,size)=>`<svg x="${x}" y="${y}" width="${size}" height="${size}" viewBox="0 0 64 64"><path fill="#f3f2df" d="${g.d}"/></svg>`;
const text=(x,y,t,size=14,color='#b7c4cf')=>`<text x="${x}" y="${y}" font-family="Arial,sans-serif" font-size="${size}" fill="${color}">${t}</text>`;
let board=`<svg xmlns="http://www.w3.org/2000/svg" width="1400" height="820" viewBox="0 0 1400 820"><rect width="1400" height="820" fill="#0a1320"/>${text(40,45,'WEAPON GLYPHS / GEOMETRY REFINEMENT',20,'#f3f2df')}${text(40,72,'40° shared diagonal · filled silhouettes · transparent SVG masters')}`;
glyphs.forEach((g,i)=>{const x=40+i*192;board+=icon(g,x+30,120,112)+text(x+30,265,g.label,16,'#f3f2df');});
board+=text(40,330,'INSTRUMENT-SIZE CHECK / 48 px glyphs, neutral hairline rings');
glyphs.forEach((g,i)=>{const x=126+i*192;board+=`<circle cx="${x}" cy="410" r="53" fill="none" stroke="#718292" stroke-width="1" stroke-dasharray="275 58" transform="rotate(-70 ${x} 410)"/>`+icon(g,x-24,386,48);});
board+=text(40,505,'NATIVE SIZE / no glow or distortion');
[16,24,32,48].forEach((size,row)=>{const y=540+row*56;board+=text(40,y+size/2+5,size+' px');glyphs.forEach((g,i)=>board+=icon(g,100+i*90,y,size));});
board+=text(830,580,'Concussion: identical segment × 3, rotated 120°')+text(830,610,'Missiles: mirrored body and fins, shared diagonal')+text(830,640,'Rippers: four staggered, balanced strokes')+text(830,730,'Geometry preview, not an in-game capture',12);
board+='</svg>';fs.writeFileSync(path.join(root,'weapon-refinement-20261030.svg'),board);
const report={houseAngleDegrees:angle,nominalThickness:thickness,viewBox:'0 0 64 64',fill:'#ffffff',background:'transparent',effects:'none; supplied by game canopy pass',source:'Selected provisional sheet at 70fb351f37063395abf812c1a8e9fa0e31e2a90d; house angle from issue684 comment6492111188',icons:glyphs.map(g=>({id:g.id,pieces:g.polygons.length,bounds:{minX:n(Math.min(...g.polygons.flat().map(p=>p[0]))+32),maxX:n(Math.max(...g.polygons.flat().map(p=>p[0]))+32),minY:n(Math.min(...g.polygons.flat().map(p=>p[1]))+32),maxY:n(Math.max(...g.polygons.flat().map(p=>p[1]))+32)}})),concussion:'Same source polygon rotated 0,120,240 degrees',missiles:'Body mirror symmetry around local longitudinal axis',status:'Prepared SVG sources; Unity import and play-scale approval pending'};
fs.writeFileSync(path.join(root,'geometry-manifest.json'),JSON.stringify(report,null,2));
fs.writeFileSync(path.join(root,'preview.html'),`<!doctype html><html><body style="margin:0;background:#0a1320">${board}</body></html>`);
console.log(JSON.stringify(report));
